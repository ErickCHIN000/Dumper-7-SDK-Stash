#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA50 - 0xA50)
// BlueprintGeneratedClass Bandits_KickWeapon.Bandits_KickWeapon_C
class ABandits_KickWeapon_C : public AGenericNPC_KickWeapon_C
{
public:

	static class UClass* StaticClass();
	static class ABandits_KickWeapon_C* GetDefaultObj();

};

}


