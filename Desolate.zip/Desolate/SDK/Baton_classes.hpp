#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA70 - 0xA70)
// BlueprintGeneratedClass Baton.Baton_C
class ABaton_C : public AGenericMeleeWeapon_C
{
public:

	static class UClass* StaticClass();
	static class ABaton_C* GetDefaultObj();

};

}


