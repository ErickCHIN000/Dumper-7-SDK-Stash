#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x448 - 0x448)
// BlueprintGeneratedClass Barley.Barley_C
class ABarley_C : public AGenericFood_Groats_C
{
public:

	static class UClass* StaticClass();
	static class ABarley_C* GetDefaultObj();

};

}


