#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA58 - 0xA58)
// BlueprintGeneratedClass Bandit_Tank_Jump.Bandit_Tank_Jump_C
class ABandit_Tank_Jump_C : public ASHWeapon_Melee
{
public:

	static class UClass* StaticClass();
	static class ABandit_Tank_Jump_C* GetDefaultObj();

};

}


