#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x448 - 0x448)
// BlueprintGeneratedClass Banana.Banana_C
class ABanana_C : public AGenericFood_Fruits_C
{
public:

	static class UClass* StaticClass();
	static class ABanana_C* GetDefaultObj();

};

}


