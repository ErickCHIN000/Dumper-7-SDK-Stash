#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x480 - 0x480)
// BlueprintGeneratedClass Backpack4.Backpack4_C
class ABackpack4_C : public AGenericBackpack_C
{
public:

	static class UClass* StaticClass();
	static class ABackpack4_C* GetDefaultObj();

};

}


