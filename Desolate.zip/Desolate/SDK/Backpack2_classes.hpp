#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x480 - 0x480)
// BlueprintGeneratedClass Backpack2.Backpack2_C
class ABackpack2_C : public AGenericBackpack_C
{
public:

	static class UClass* StaticClass();
	static class ABackpack2_C* GetDefaultObj();

};

}


