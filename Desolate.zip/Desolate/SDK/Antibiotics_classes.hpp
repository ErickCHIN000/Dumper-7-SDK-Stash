#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x44A - 0x44A)
// BlueprintGeneratedClass Antibiotics.Antibiotics_C
class AAntibiotics_C : public AGenericMedicine_C
{
public:

	static class UClass* StaticClass();
	static class AAntibiotics_C* GetDefaultObj();

};

}


