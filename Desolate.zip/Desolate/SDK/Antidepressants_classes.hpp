#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x44A - 0x44A)
// BlueprintGeneratedClass Antidepressants.Antidepressants_C
class AAntidepressants_C : public AGenericSedative_C
{
public:

	static class UClass* StaticClass();
	static class AAntidepressants_C* GetDefaultObj();

};

}


