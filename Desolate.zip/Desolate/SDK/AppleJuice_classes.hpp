#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x430 - 0x430)
// BlueprintGeneratedClass AppleJuice.AppleJuice_C
class AAppleJuice_C : public AGenericWater_C
{
public:

	static class UClass* StaticClass();
	static class AAppleJuice_C* GetDefaultObj();

};

}


