#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x428 - 0x428)
// BlueprintGeneratedClass Barbwire.Barbwire_C
class ABarbwire_C : public AGenericCraftable_C
{
public:

	static class UClass* StaticClass();
	static class ABarbwire_C* GetDefaultObj();

};

}


