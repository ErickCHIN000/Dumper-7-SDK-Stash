#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x44A - 0x44A)
// BlueprintGeneratedClass Bandage_Crafted.Bandage_Crafted_C
class ABandage_Crafted_C : public AGenericBandage_C
{
public:

	static class UClass* StaticClass();
	static class ABandage_Crafted_C* GetDefaultObj();

};

}


