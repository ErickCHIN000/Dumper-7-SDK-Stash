#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA58 - 0xA58)
// BlueprintGeneratedClass BaseAiMeleeWeapon.BaseAiMeleeWeapon_C
class ABaseAiMeleeWeapon_C : public ASHWeapon_Melee
{
public:

	static class UClass* StaticClass();
	static class ABaseAiMeleeWeapon_C* GetDefaultObj();

};

}


