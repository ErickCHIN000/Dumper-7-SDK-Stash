#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x448 - 0x448)
// BlueprintGeneratedClass Apple.Apple_C
class AApple_C : public AGenericFood_Fruits_C
{
public:

	static class UClass* StaticClass();
	static class AApple_C* GetDefaultObj();

};

}


