#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x448 - 0x448)
// BlueprintGeneratedClass Ansora-stylePasta.Ansora-stylePasta_C
class AAnsoraMinusstylePasta_C : public AGenericFood_C
{
public:

	static class UClass* StaticClass();
	static class AAnsoraMinusstylePasta_C* GetDefaultObj();

};

}


