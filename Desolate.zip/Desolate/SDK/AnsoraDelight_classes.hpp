#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x448 - 0x448)
// BlueprintGeneratedClass AnsoraDelight.AnsoraDelight_C
class AAnsoraDelight_C : public AGenericFood_C
{
public:

	static class UClass* StaticClass();
	static class AAnsoraDelight_C* GetDefaultObj();

};

}


