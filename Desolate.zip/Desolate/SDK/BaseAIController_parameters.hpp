#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x1 (0x1 - 0x0)
// Function BaseAIController.BaseAIController_C.UserConstructionScript
struct ABaseAIController_C_UserConstructionScript_Params
{
public:
	bool                                         CallFunc_RunBehaviorTree_ReturnValue;              // 0x0(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
};

}
}


