#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x429 - 0x429)
// BlueprintGeneratedClass Bandit_ThrowItem.Bandit_ThrowItem_C
class ABandit_ThrowItem_C : public AGenericNPC_ThrowItem_C
{
public:

	static class UClass* StaticClass();
	static class ABandit_ThrowItem_C* GetDefaultObj();

};

}


