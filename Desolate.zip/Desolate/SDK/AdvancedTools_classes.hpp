#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x430 - 0x430)
// BlueprintGeneratedClass AdvancedTools.AdvancedTools_C
class AAdvancedTools_C : public ABasicTools_C
{
public:

	static class UClass* StaticClass();
	static class AAdvancedTools_C* GetDefaultObj();

};

}


