#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x430 - 0x430)
// BlueprintGeneratedClass AppleMix.AppleMix_C
class AAppleMix_C : public AGenericWater_C
{
public:

	static class UClass* StaticClass();
	static class AAppleMix_C* GetDefaultObj();

};

}


