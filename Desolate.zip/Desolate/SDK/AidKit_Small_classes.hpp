#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x44A - 0x44A)
// BlueprintGeneratedClass AidKit_Small.AidKit_Small_C
class AAidKit_Small_C : public AGenericMedicine_C
{
public:

	static class UClass* StaticClass();
	static class AAidKit_Small_C* GetDefaultObj();

};

}


