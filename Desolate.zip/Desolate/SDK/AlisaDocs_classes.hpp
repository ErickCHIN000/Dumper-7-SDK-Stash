#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x420 - 0x420)
// BlueprintGeneratedClass AlisaDocs.AlisaDocs_C
class AAlisaDocs_C : public AGenericQuestItem_C
{
public:

	static class UClass* StaticClass();
	static class AAlisaDocs_C* GetDefaultObj();

};

}


