#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA70 - 0xA70)
// BlueprintGeneratedClass Bandit_MeleeWeapon_Dodger.Bandit_MeleeWeapon_Dodger_C
class ABandit_MeleeWeapon_Dodger_C : public ABandit_MeleeWeapon_C
{
public:

	static class UClass* StaticClass();
	static class ABandit_MeleeWeapon_Dodger_C* GetDefaultObj();

};

}


