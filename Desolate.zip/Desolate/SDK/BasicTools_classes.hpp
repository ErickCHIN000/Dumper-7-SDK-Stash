#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x430 - 0x430)
// BlueprintGeneratedClass BasicTools.BasicTools_C
class ABasicTools_C : public AGenericCraftingTool_C
{
public:

	static class UClass* StaticClass();
	static class ABasicTools_C* GetDefaultObj();

};

}


