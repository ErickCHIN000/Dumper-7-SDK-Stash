#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x448 - 0x448)
// BlueprintGeneratedClass BachelorDinner.BachelorDinner_C
class ABachelorDinner_C : public AGenericFood_C
{
public:

	static class UClass* StaticClass();
	static class ABachelorDinner_C* GetDefaultObj();

};

}


