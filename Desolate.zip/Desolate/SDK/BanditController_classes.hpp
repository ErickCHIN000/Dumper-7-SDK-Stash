#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x330 - 0x330)
// BlueprintGeneratedClass BanditController.BanditController_C
class ABanditController_C : public AGenericNPC_Controller_C
{
public:

	static class UClass* StaticClass();
	static class ABanditController_C* GetDefaultObj();

};

}


