#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x480 - 0x480)
// BlueprintGeneratedClass Backpack5.Backpack5_C
class ABackpack5_C : public AGenericBackpack_C
{
public:

	static class UClass* StaticClass();
	static class ABackpack5_C* GetDefaultObj();

};

}


