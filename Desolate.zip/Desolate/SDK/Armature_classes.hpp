#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA70 - 0xA70)
// BlueprintGeneratedClass Armature.Armature_C
class AArmature_C : public AGenericMeleeWeaponHeavy_C
{
public:

	static class UClass* StaticClass();
	static class AArmature_C* GetDefaultObj();

};

}


