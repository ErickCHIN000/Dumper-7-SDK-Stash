#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA70 - 0xA70)
// BlueprintGeneratedClass Bandit_MeleeWeapon_Maniac.Bandit_MeleeWeapon_Maniac_C
class ABandit_MeleeWeapon_Maniac_C : public ABandit_MeleeWeapon_C
{
public:

	static class UClass* StaticClass();
	static class ABandit_MeleeWeapon_Maniac_C* GetDefaultObj();

};

}


