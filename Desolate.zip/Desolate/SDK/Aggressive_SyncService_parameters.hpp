#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0xC (0xC - 0x0)
// Function Aggressive_SyncService.Aggressive_SyncService_C.SS_SetAggroPOI
struct UAggressive_SyncService_C_SS_SetAggroPOI_Params
{
public:
	struct FVector                               POI;                                               // 0x0(0xC)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x8 (0x8 - 0x0)
// Function Aggressive_SyncService.Aggressive_SyncService_C.SS_SetEnemyCharacter
struct UAggressive_SyncService_C_SS_SetEnemyCharacter_Params
{
public:
	class ASHCharacter*                          Character;                                         // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


