#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x6F0 - 0x6F0)
// BlueprintGeneratedClass Bandit_RangedWeapon.Bandit_RangedWeapon_C
class ABandit_RangedWeapon_C : public AGenericNPC_RangedWeapon_C
{
public:

	static class UClass* StaticClass();
	static class ABandit_RangedWeapon_C* GetDefaultObj();

};

}


