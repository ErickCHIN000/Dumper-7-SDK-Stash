#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x460 - 0x460)
// BlueprintGeneratedClass Alcohol.Alcohol_C
class AAlcohol_C : public AGenericAlcoholCraft_C
{
public:

	static class UClass* StaticClass();
	static class AAlcohol_C* GetDefaultObj();

};

}


