#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x48 - 0x48)
// BlueprintGeneratedClass AnomalyNavArea.AnomalyNavArea_C
class UAnomalyNavArea_C : public UNavArea
{
public:

	static class UClass* StaticClass();
	static class UAnomalyNavArea_C* GetDefaultObj();

};

}


