#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA70 - 0xA70)
// BlueprintGeneratedClass Bandit_MeleeWeapon.Bandit_MeleeWeapon_C
class ABandit_MeleeWeapon_C : public AGenericNPC_MeleeWeapon_C
{
public:

	static class UClass* StaticClass();
	static class ABandit_MeleeWeapon_C* GetDefaultObj();

};

}


