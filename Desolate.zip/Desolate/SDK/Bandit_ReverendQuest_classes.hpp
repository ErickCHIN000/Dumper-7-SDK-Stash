#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1400 - 0x1400)
// BlueprintGeneratedClass Bandit_ReverendQuest.Bandit_ReverendQuest_C
class ABandit_ReverendQuest_C : public ABandit_BaseCharacter_C
{
public:

	static class UClass* StaticClass();
	static class ABandit_ReverendQuest_C* GetDefaultObj();

};

}


