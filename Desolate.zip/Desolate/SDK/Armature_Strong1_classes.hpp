#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0xA80 - 0xA70)
// BlueprintGeneratedClass Armature_Strong1.Armature_Strong1_C
class AArmature_Strong1_C : public AArmature_C
{
public:
	class UStaticMeshComponent*                  StaticMesh1;                                       // 0xA70(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)
	class UStaticMeshComponent*                  StaticMesh;                                        // 0xA78(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class AArmature_Strong1_C* GetDefaultObj();

};

}


