#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x48 - 0x48)
// BlueprintGeneratedClass Avoid_AnomalyNavArea.Avoid_AnomalyNavArea_C
class UAvoid_AnomalyNavArea_C : public UNavigationQueryFilter
{
public:

	static class UClass* StaticClass();
	static class UAvoid_AnomalyNavArea_C* GetDefaultObj();

};

}


