#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x60 - 0x60)
// BlueprintGeneratedClass BP_Sprint_Item.BP_Sprint_Item_C
class UBP_Sprint_Item_C : public UItem
{
public:

	static class UClass* StaticClass();
	static class UBP_Sprint_Item_C* GetDefaultObj();

};

}


