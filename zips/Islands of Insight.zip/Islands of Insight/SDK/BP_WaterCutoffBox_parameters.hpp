#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x28 (0x28 - 0x0)
// Function BP_WaterCutoffBox.BP_WaterCutoffBox_C.UserConstructionScript
struct ABP_WaterCutoffBox_C_UserConstructionScript_Params
{
public:
	class FString                                CallFunc_Concat_StrStr_ReturnValue;                // 0x0(0x10)(ZeroConstructor, HasGetValueTypeHash)
	class FText                                  CallFunc_Conv_StringToText_ReturnValue;            // 0x10(0x18)(None)
};

// 0x4 (0x4 - 0x0)
// Function BP_WaterCutoffBox.BP_WaterCutoffBox_C.ExecuteUbergraph_BP_WaterCutoffBox
struct ABP_WaterCutoffBox_C_ExecuteUbergraph_BP_WaterCutoffBox_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


