#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x2E8 - 0x2E8)
// WidgetBlueprintGeneratedClass AudioSettingsPage.AudioSettingsPage_C
class UAudioSettingsPage_C : public UBaseWidget
{
public:

	static class UClass* StaticClass();
	static class UAudioSettingsPage_C* GetDefaultObj();

};

}


