#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x228 - 0x228)
// BlueprintGeneratedClass BP_ItemTeleportPortal.BP_ItemTeleportPortal_C
class ABP_ItemTeleportPortal_C : public AItemTeleportPortal
{
public:

	static class UClass* StaticClass();
	static class ABP_ItemTeleportPortal_C* GetDefaultObj();

};

}


