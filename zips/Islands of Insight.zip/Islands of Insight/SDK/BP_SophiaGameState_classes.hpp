#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x4F0 - 0x4E8)
// BlueprintGeneratedClass BP_SophiaGameState.BP_SophiaGameState_C
class ABP_SophiaGameState_C : public ASophiaGameState
{
public:
	class USceneComponent*                       DefaultSceneRoot;                                  // 0x4E8(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABP_SophiaGameState_C* GetDefaultObj();

};

}


