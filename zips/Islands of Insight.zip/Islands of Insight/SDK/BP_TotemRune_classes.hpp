#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x8D0 - 0x8C8)
// BlueprintGeneratedClass BP_TotemRune.BP_TotemRune_C
class ABP_TotemRune_C : public ATotemRune
{
public:
	class UPuzzleBoundsComponent*                PuzzleBounds;                                      // 0x8C8(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABP_TotemRune_C* GetDefaultObj();

};

}


