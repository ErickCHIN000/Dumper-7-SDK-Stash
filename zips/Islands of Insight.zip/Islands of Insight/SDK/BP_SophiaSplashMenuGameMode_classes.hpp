#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x5C8 - 0x5C0)
// BlueprintGeneratedClass BP_SophiaSplashMenuGameMode.BP_SophiaSplashMenuGameMode_C
class ABP_SophiaSplashMenuGameMode_C : public ASophiaGameMode
{
public:
	class USceneComponent*                       DefaultSceneRoot;                                  // 0x5C0(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABP_SophiaSplashMenuGameMode_C* GetDefaultObj();

};

}


