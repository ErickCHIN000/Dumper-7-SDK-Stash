#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x60 - 0x60)
// BlueprintGeneratedClass BP_RichText_InputKeyDecorator_Base.BP_RichText_InputKeyDecorator_Base_C
class UBP_RichText_InputKeyDecorator_Base_C : public URichTextBlockInputKeyDecorator
{
public:

	static class UClass* StaticClass();
	static class UBP_RichText_InputKeyDecorator_Base_C* GetDefaultObj();

};

}


