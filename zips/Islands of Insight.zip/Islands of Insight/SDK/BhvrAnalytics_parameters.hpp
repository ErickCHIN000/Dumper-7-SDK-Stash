#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x8 - 0x0)
// Function BhvrAnalytics.BhvrAnalyticsBlueprintLibrary.RecordBhvrAnalyticsEventAttribute
struct UBhvrAnalyticsBlueprintLibrary_RecordBhvrAnalyticsEventAttribute_Params
{
public:
	class UStruct*                               AnyStruct;                                         // 0x0(0x8)(Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash, NativeAccessSpecifierPublic)
};

}
}


