#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x30 - 0x30)
// BlueprintGeneratedClass BP_Richtext_image_decorator_PC_Button.BP_Richtext_image_decorator_PC_Button_C
class UBP_Richtext_image_decorator_PC_Button_C : public UCustomRichTextBlockImageDecorator
{
public:

	static class UClass* StaticClass();
	static class UBP_Richtext_image_decorator_PC_Button_C* GetDefaultObj();

};

}


