#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x60 - 0x60)
// BlueprintGeneratedClass BP_RichText_InputKeyDecorator_Large.BP_RichText_InputKeyDecorator_Large_C
class UBP_RichText_InputKeyDecorator_Large_C : public UBP_RichText_InputKeyDecorator_Base_C
{
public:

	static class UClass* StaticClass();
	static class UBP_RichText_InputKeyDecorator_Large_C* GetDefaultObj();

};

}


