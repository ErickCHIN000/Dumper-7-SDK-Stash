#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x60 - 0x60)
// BlueprintGeneratedClass BP_HighJump_Item.BP_HighJump_Item_C
class UBP_HighJump_Item_C : public UItem
{
public:

	static class UClass* StaticClass();
	static class UBP_HighJump_Item_C* GetDefaultObj();

};

}


