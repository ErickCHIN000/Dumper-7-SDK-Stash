#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x60 - 0x60)
// BlueprintGeneratedClass BP_MultiJump_Item.BP_MultiJump_Item_C
class UBP_MultiJump_Item_C : public UItem
{
public:

	static class UClass* StaticClass();
	static class UBP_MultiJump_Item_C* GetDefaultObj();

};

}


