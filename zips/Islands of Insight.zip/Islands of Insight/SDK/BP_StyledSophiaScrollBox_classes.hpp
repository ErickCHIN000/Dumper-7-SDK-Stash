#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA28 - 0xA28)
// BlueprintGeneratedClass BP_StyledSophiaScrollBox.BP_StyledSophiaScrollBox_C
class UBP_StyledSophiaScrollBox_C : public USophiaScrollBox
{
public:

	static class UClass* StaticClass();
	static class UBP_StyledSophiaScrollBox_C* GetDefaultObj();

};

}


