#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x328 - 0x320)
// BlueprintGeneratedClass BP_ItemJumpingPad.BP_ItemJumpingPad_C
class ABP_ItemJumpingPad_C : public AItemJumpingPad
{
public:
	class UNiagaraComponent*                     Galaxy_Emitter_System;                             // 0x320(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABP_ItemJumpingPad_C* GetDefaultObj();

};

}


