#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x5B8 - 0x5B0)
// BlueprintGeneratedClass BP_PuzzleTotem.BP_PuzzleTotem_C
class ABP_PuzzleTotem_C : public APuzzleTotem
{
public:
	class UBoxComponent*                         PlayerClick;                                       // 0x5B0(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABP_PuzzleTotem_C* GetDefaultObj();

};

}


