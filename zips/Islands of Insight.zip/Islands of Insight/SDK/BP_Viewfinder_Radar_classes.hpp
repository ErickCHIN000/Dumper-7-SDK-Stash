#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x60 - 0x60)
// BlueprintGeneratedClass BP_Viewfinder_Radar.BP_Viewfinder_Radar_C
class UBP_Viewfinder_Radar_C : public UItem
{
public:

	static class UClass* StaticClass();
	static class UBP_Viewfinder_Radar_C* GetDefaultObj();

};

}


