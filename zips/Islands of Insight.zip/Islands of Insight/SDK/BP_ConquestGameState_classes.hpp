#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x678 - 0x670)
// BlueprintGeneratedClass BP_ConquestGameState.BP_ConquestGameState_C
class ABP_ConquestGameState_C : public AConquestGameState
{
public:
	class USceneComponent*                       DefaultSceneRoot;                                  // 0x670(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABP_ConquestGameState_C* GetDefaultObj();

};

}


