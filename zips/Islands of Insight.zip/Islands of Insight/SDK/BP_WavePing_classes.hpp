#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x280 - 0x280)
// BlueprintGeneratedClass BP_WavePing.BP_WavePing_C
class ABP_WavePing_C : public ABP_EmptyLocationPing_C
{
public:

	static class UClass* StaticClass();
	static class ABP_WavePing_C* GetDefaultObj();

};

}


