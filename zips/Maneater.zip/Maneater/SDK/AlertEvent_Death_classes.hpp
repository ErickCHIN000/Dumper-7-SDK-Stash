#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xA0 - 0xA0)
// BlueprintGeneratedClass AlertEvent_Death.AlertEvent_Death_C
class UAlertEvent_Death_C : public UME_AlertEvent_Witness
{
public:

	static class UClass* StaticClass();
	static class UAlertEvent_Death_C* GetDefaultObj();

};

}


