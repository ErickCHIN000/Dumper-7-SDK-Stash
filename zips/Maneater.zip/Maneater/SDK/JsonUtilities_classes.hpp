#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// Class JsonUtilities.JsonUtilitiesDummyObject
class UJsonUtilitiesDummyObject : public UObject
{
public:

	static class UClass* StaticClass();
	static class UJsonUtilitiesDummyObject* GetDefaultObj();

};

}


