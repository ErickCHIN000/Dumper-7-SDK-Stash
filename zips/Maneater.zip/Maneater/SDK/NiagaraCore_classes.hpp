#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// Class NiagaraCore.NiagaraMergeable
class UNiagaraMergeable : public UObject
{
public:

	static class UClass* StaticClass();
	static class UNiagaraMergeable* GetDefaultObj();

};

// 0x0 (0x28 - 0x28)
// Class NiagaraCore.NiagaraDataInterfaceBase
class UNiagaraDataInterfaceBase : public UNiagaraMergeable
{
public:

	static class UClass* StaticClass();
	static class UNiagaraDataInterfaceBase* GetDefaultObj();

};

}


