#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x40 - 0x40)
// BlueprintGeneratedClass DmgTypeBP_Environmental.DmgTypeBP_Environmental_C
class UDmgTypeBP_Environmental_C : public UDamageType
{
public:

	static class UClass* StaticClass();
	static class UDmgTypeBP_Environmental_C* GetDefaultObj();

};

}


