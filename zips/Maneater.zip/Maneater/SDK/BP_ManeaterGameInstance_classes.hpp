#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x30 (0x568 - 0x538)
// BlueprintGeneratedClass BP_ManeaterGameInstance.BP_ManeaterGameInstance_C
class UBP_ManeaterGameInstance_C : public UME_GameInstance
{
public:
	TSoftObjectPtr<class UObject>                PersistentLevel;                                   // 0x538(0x28)(Edit, BlueprintVisible, DisableEditOnInstance, HasGetValueTypeHash)
	class UObject*                               PersistentLevelObject;                             // 0x560(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class UBP_ManeaterGameInstance_C* GetDefaultObj();

};

}


