#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xC52 - 0xC52)
// BlueprintGeneratedClass BP_ActionableBehaviour_Deployable_LargeDeployable.BP_ActionableBehaviour_Deployable_LargeDeployable_C
class UBP_ActionableBehaviour_Deployable_LargeDeployable_C : public UBP_ActionableBehaviour_DeployableBase_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionableBehaviour_Deployable_LargeDeployable_C* GetDefaultObj();

	void OnDeploy(class ADeployable* SpawnedDeployable, bool CallFunc_IsServer_ReturnValue, bool CallFunc_IsValid_ReturnValue);
};

}


