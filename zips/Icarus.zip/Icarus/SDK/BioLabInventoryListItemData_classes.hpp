#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x1F0 (0x218 - 0x28)
// BlueprintGeneratedClass BioLabInventoryListItemData.BioLabInventoryListItemData_C
class UBioLabInventoryListItemData_C : public UObject
{
public:
	struct FItemData                             ItemData;                                          // 0x28(0x1F0)(Edit, BlueprintVisible, DisableEditOnInstance, ContainsInstancedReference)

	static class UClass* StaticClass();
	static class UBioLabInventoryListItemData_C* GetDefaultObj();

};

}


