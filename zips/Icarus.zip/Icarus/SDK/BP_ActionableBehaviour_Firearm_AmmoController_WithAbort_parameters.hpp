#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x1 (0x1 - 0x0)
// Function BP_ActionableBehaviour_Firearm_AmmoController_WithAbort.BP_ActionableBehaviour_Firearm_AmmoController_WithAbort_C.CanAbortReload
struct UBP_ActionableBehaviour_Firearm_AmmoController_WithAbort_C_CanAbortReload_Params
{
public:
	bool                                         CanAbort;                                          // 0x0(0x1)(Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

}
}


