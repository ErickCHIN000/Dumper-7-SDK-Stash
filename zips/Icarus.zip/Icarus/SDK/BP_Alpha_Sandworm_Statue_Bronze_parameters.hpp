#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x4 (0x4 - 0x0)
// Function BP_Alpha_Sandworm_Statue_Bronze.BP_Alpha_Sandworm_Statue_Bronze_C.ExecuteUbergraph_BP_Alpha_Sandworm_Statue_Bronze
struct ABP_Alpha_Sandworm_Statue_Bronze_C_ExecuteUbergraph_BP_Alpha_Sandworm_Statue_Bronze_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


