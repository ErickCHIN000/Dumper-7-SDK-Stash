#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x540 - 0x540)
// BlueprintGeneratedClass BP_ActionableBehaviour_CurvedSplinePlace_Fuel.BP_ActionableBehaviour_CurvedSplinePlace_Fuel_C
class UBP_ActionableBehaviour_CurvedSplinePlace_Fuel_C : public UBP_ActionableBehaviour_CurvedSplinePlace_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionableBehaviour_CurvedSplinePlace_Fuel_C* GetDefaultObj();

};

}


