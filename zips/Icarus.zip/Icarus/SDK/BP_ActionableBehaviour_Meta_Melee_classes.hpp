#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x3A0 - 0x3A0)
// BlueprintGeneratedClass BP_ActionableBehaviour_Meta_Melee.BP_ActionableBehaviour_Meta_Melee_C
class UBP_ActionableBehaviour_Meta_Melee_C : public UBP_ActionableBehaviour_Generic_Melee_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionableBehaviour_Meta_Melee_C* GetDefaultObj();

};

}


