#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x4 (0x4 - 0x0)
// Function BP_Advanced_Armor_Bench.BP_Advanced_Armor_Bench_C.ExecuteUbergraph_BP_Advanced_Armor_Bench
struct ABP_Advanced_Armor_Bench_C_ExecuteUbergraph_BP_Advanced_Armor_Bench_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


