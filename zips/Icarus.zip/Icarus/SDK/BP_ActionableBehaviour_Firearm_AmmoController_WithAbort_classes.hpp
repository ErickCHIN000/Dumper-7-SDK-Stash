#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xEC0 - 0xEC0)
// BlueprintGeneratedClass BP_ActionableBehaviour_Firearm_AmmoController_WithAbort.BP_ActionableBehaviour_Firearm_AmmoController_WithAbort_C
class UBP_ActionableBehaviour_Firearm_AmmoController_WithAbort_C : public UBP_ActionableBehaviour_Firearm_AmmoController_Base_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionableBehaviour_Firearm_AmmoController_WithAbort_C* GetDefaultObj();

	void CanAbortReload(bool* CanAbort);
};

}


