#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xB14 - 0xB14)
// BlueprintGeneratedClass BP_ActionableBehaviour_FireArm_FireController_SemiAuto.BP_ActionableBehaviour_FireArm_FireController_SemiAuto_C
class UBP_ActionableBehaviour_FireArm_FireController_SemiAuto_C : public UBP_ActionableBehaviour_FireArm_FireController_Base_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionableBehaviour_FireArm_FireController_SemiAuto_C* GetDefaultObj();

	void GetRefireRate(float* RefireRate);
};

}


