#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x3AC - 0x3AC)
// BlueprintGeneratedClass BP_ActionableBehaviour_Scanner_DeepOre.BP_ActionableBehaviour_Scanner_DeepOre_C
class UBP_ActionableBehaviour_Scanner_DeepOre_C : public UBP_ActionableBehaviour_Scanner_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionableBehaviour_Scanner_DeepOre_C* GetDefaultObj();

};

}


