#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x4 (0x4 - 0x0)
// Function Bp_Action_AliveRagdollTimer.Bp_Action_AliveRagdollTimer_C.ExecuteUbergraph_Bp_Action_AliveRagdollTimer
struct UBp_Action_AliveRagdollTimer_C_ExecuteUbergraph_Bp_Action_AliveRagdollTimer_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


