#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x158 - 0x158)
// BlueprintGeneratedClass BP_ActionPairStandby_Petting.BP_ActionPairStandby_Petting_C
class UBP_ActionPairStandby_Petting_C : public UBP_ActionPairStandbyBase_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionPairStandby_Petting_C* GetDefaultObj();

};

}


