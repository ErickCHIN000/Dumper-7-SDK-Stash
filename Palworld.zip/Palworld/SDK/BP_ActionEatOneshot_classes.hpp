#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x168 - 0x168)
// BlueprintGeneratedClass BP_ActionEatOneshot.BP_ActionEatOneshot_C
class UBP_ActionEatOneshot_C : public UBP_ActionSimpleMonoMontage_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionEatOneshot_C* GetDefaultObj();

};

}


