#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x3188 - 0x3188)
// AnimBlueprintGeneratedClass ABP_NPC_Child.ABP_NPC_Child_C
class UABP_NPC_Child_C : public UABP_NPC_Base_C
{
public:

	static class UClass* StaticClass();
	static class UABP_NPC_Child_C* GetDefaultObj();

};

}


