#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x28 - 0x28)
// AnimBlueprintGeneratedClass ALI_PalmiSubFunction.ALI_PalmiSubFunction_C
class IALI_PalmiSubFunction_C : public IAnimLayerInterface
{
public:

	static class UClass* StaticClass();
	static class IALI_PalmiSubFunction_C* GetDefaultObj();

	void LeftHandAttach(const struct FPoseLink& InPose, struct FPoseLink* LeftHandAttach);
};

}


