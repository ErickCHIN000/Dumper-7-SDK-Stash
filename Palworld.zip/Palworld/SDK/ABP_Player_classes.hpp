#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x9418 (0x9A28 - 0x610)
// AnimBlueprintGeneratedClass ABP_Player.ABP_Player_C
class UABP_Player_C : public UPalAnimInstance
{
public:
	struct FPointerToUberGraphFrame              UberGraphFrame;                                    // 0x610(0x8)(ZeroConstructor, Transient, DuplicateTransient)
	struct FAnimBlueprintGeneratedMutableData    __AnimBlueprintMutables;                           // 0x618(0xC0)(HasGetValueTypeHash)
	struct FAnimSubsystemInstance                AnimBlueprintExtension_PropertyAccess;             // 0x6D8(0x8)(None)
	struct FAnimSubsystemInstance                AnimBlueprintExtension_Base;                       // 0x6E0(0x8)(None)
	struct FAnimNode_Root                        AnimGraphNode_Root_7;                              // 0x6E8(0x20)(None)
	struct FAnimNode_LinkedInputPose             AnimGraphNode_LinkedInputPose_6;                   // 0x708(0xC8)(None)
	struct FAnimNode_Root                        AnimGraphNode_Root_6;                              // 0x7D0(0x20)(None)
	struct FAnimNode_LinkedInputPose             AnimGraphNode_LinkedInputPose_5;                   // 0x7F0(0xC8)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_6;             // 0x8B8(0x20)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_6;             // 0x8D8(0x20)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_16;                   // 0x8F8(0x108)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_28;                  // 0xA00(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_41;                    // 0xA48(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_40;                    // 0xA70(0x28)(None)
	uint8                                        Pad_1763[0x8];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FAnimNode_Fabrik                      AnimGraphNode_Fabrik;                              // 0xAA0(0x1F0)(None)
	struct FAnimNode_Root                        AnimGraphNode_Root_5;                              // 0xC90(0x20)(None)
	struct FAnimNode_LinkedInputPose             AnimGraphNode_LinkedInputPose_4;                   // 0xCB0(0xC8)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_18;                       // 0xD78(0x128)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_5;             // 0xEA0(0x20)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_17;                       // 0xEC0(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_16;                       // 0xFE8(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_15;                       // 0x1110(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_14;                       // 0x1238(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_13;                       // 0x1360(0x128)(None)
	uint8                                        Pad_1792[0x8];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FAnimNode_TwoBoneIK                   AnimGraphNode_TwoBoneIK_5;                         // 0x1490(0x270)(None)
	struct FAnimNode_TwoBoneIK                   AnimGraphNode_TwoBoneIK_4;                         // 0x1700(0x270)(None)
	struct FAnimNode_TwoBoneIK                   AnimGraphNode_TwoBoneIK_3;                         // 0x1970(0x270)(None)
	struct FAnimNode_TwoBoneIK                   AnimGraphNode_TwoBoneIK_2;                         // 0x1BE0(0x270)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_15;                   // 0x1E50(0x108)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_39;                    // 0x1F58(0x28)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_27;                  // 0x1F80(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_38;                    // 0x1FC8(0x28)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_5;             // 0x1FF0(0x20)(None)
	struct FAnimNode_Root                        AnimGraphNode_Root_4;                              // 0x2010(0x20)(None)
	struct FAnimNode_LinkedInputPose             AnimGraphNode_LinkedInputPose_3;                   // 0x2030(0xC8)(None)
	uint8                                        Pad_17B5[0x8];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FAnimNode_LookAt                      AnimGraphNode_LookAt;                              // 0x2100(0x250)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_26;                  // 0x2350(0x48)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4;             // 0x2398(0x20)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_14;                   // 0x23B8(0x108)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_37;                    // 0x24C0(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_36;                    // 0x24E8(0x28)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4;             // 0x2510(0x20)(None)
	struct FAnimNode_Root                        AnimGraphNode_Root_3;                              // 0x2530(0x20)(None)
	struct FAnimNode_LinkedInputPose             AnimGraphNode_LinkedInputPose_2;                   // 0x2550(0xC8)(None)
	uint8                                        Pad_17CD[0x8];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FAnimNode_TwoBoneIK                   AnimGraphNode_TwoBoneIK_1;                         // 0x2620(0x270)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;             // 0x2890(0x20)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;             // 0x28B0(0x20)(None)
	struct FAnimNode_TwoBoneIK                   AnimGraphNode_TwoBoneIK;                           // 0x28D0(0x270)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_12;                       // 0x2B40(0x128)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_25;                  // 0x2C68(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_13;                   // 0x2CB0(0x108)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_35;                    // 0x2DB8(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_34;                    // 0x2DE0(0x28)(None)
	struct FAnimNode_Root                        AnimGraphNode_Root_2;                              // 0x2E08(0x20)(None)
	struct FAnimNode_LinkedInputPose             AnimGraphNode_LinkedInputPose_1;                   // 0x2E28(0xC8)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_24;                  // 0x2EF0(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_21;                   // 0x2F38(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_23;                  // 0x2F80(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_20;                   // 0x2FC8(0x48)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_14;                             // 0x3010(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_12;                   // 0x3058(0x108)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_9;                  // 0x3160(0xE0)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_33;                    // 0x3240(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_32;                    // 0x3268(0x28)(None)
	struct FAnimNode_RotationOffsetBlendSpace    AnimGraphNode_RotationOffsetBlendSpace_2;          // 0x3290(0x118)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_31;                    // 0x33A8(0x28)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_22;                  // 0x33D0(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_30;                    // 0x3418(0x28)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_13;                             // 0x3440(0x48)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_12;                             // 0x3488(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_19;                   // 0x34D0(0x48)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_11;                             // 0x3518(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_29;                    // 0x3560(0x28)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;             // 0x3588(0x20)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_11;                       // 0x35A8(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_10;                       // 0x36D0(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_9;                        // 0x37F8(0x128)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;             // 0x3920(0x20)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_10;                             // 0x3940(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_21;                  // 0x3988(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_28;                    // 0x39D0(0x28)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_8;                  // 0x39F8(0xE0)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_9;                              // 0x3AD8(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_11;                   // 0x3B20(0x108)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_18;                   // 0x3C28(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_20;                  // 0x3C70(0x48)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_8;                        // 0x3CB8(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_7;                        // 0x3DE0(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_6;                        // 0x3F08(0x128)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_10;                   // 0x4030(0x108)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_27;                    // 0x4138(0x28)(None)
	struct FAnimNode_TwoWayBlend                 AnimGraphNode_TwoWayBlend_7;                       // 0x4160(0xC8)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_26;                    // 0x4228(0x28)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_19;                  // 0x4250(0x48)(None)
	struct FAnimNode_Root                        AnimGraphNode_Root_1;                              // 0x4298(0x20)(None)
	struct FAnimNode_LinkedInputPose             AnimGraphNode_LinkedInputPose;                     // 0x42B8(0xC8)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_9;                    // 0x4380(0x108)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_7;                  // 0x4488(0xE0)(None)
	struct FAnimNode_RotationOffsetBlendSpace    AnimGraphNode_RotationOffsetBlendSpace_1;          // 0x4568(0x118)(None)
	struct FAnimNode_RotationOffsetBlendSpace    AnimGraphNode_RotationOffsetBlendSpace;            // 0x4680(0x118)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_8;                              // 0x4798(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_8;                    // 0x47E0(0x108)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_7;                    // 0x48E8(0x108)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_1;             // 0x49F0(0x20)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_5;                        // 0x4A10(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_4;                        // 0x4B38(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_3;                        // 0x4C60(0x128)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1;             // 0x4D88(0x20)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;               // 0x4DA8(0x20)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_2;                        // 0x4DC8(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_1;                        // 0x4EF0(0x128)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone;                          // 0x5018(0x128)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;               // 0x5140(0x20)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_6;                    // 0x5160(0x108)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_18;                  // 0x5268(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_17;                  // 0x52B0(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_16;                  // 0x52F8(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_15;                  // 0x5340(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_25;                    // 0x5388(0x28)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_14;                  // 0x53B0(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_5;                    // 0x53F8(0x108)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_24;                    // 0x5500(0x28)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_13;                  // 0x5528(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_23;                    // 0x5570(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_22;                    // 0x5598(0x28)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_7;                              // 0x55C0(0x48)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_6;                              // 0x5608(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_12;                  // 0x5650(0x48)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_6;                  // 0x5698(0xE0)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_21;                    // 0x5778(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_20;                    // 0x57A0(0x28)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_4;                    // 0x57C8(0x108)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_19;                    // 0x58D0(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_18;                    // 0x58F8(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_17;                    // 0x5920(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_16;                    // 0x5948(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_15;                    // 0x5970(0x28)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_11;                  // 0x5998(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_14;                    // 0x59E0(0x28)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_5;                  // 0x5A08(0xE0)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_13;                    // 0x5AE8(0x28)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_5;                              // 0x5B10(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_12;                    // 0x5B58(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_11;                    // 0x5B80(0x28)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_10;                  // 0x5BA8(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_10;                    // 0x5BF0(0x28)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_3;                    // 0x5C18(0x108)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_9;                     // 0x5D20(0x28)(None)
	struct FAnimNode_TwoWayBlend                 AnimGraphNode_TwoWayBlend_6;                       // 0x5D48(0xC8)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_8;                     // 0x5E10(0x28)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_17;                   // 0x5E38(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_2;                    // 0x5E80(0x108)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_9;                   // 0x5F88(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_16;                   // 0x5FD0(0x48)(None)
	struct FAnimNode_TwoWayBlend                 AnimGraphNode_TwoWayBlend_5;                       // 0x6018(0xC8)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_15;                   // 0x60E0(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_14;                   // 0x6128(0x48)(None)
	struct FAnimNode_TwoWayBlend                 AnimGraphNode_TwoWayBlend_4;                       // 0x6170(0xC8)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_7;                     // 0x6238(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_6;                     // 0x6260(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_5;                     // 0x6288(0x28)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_4;                              // 0x62B0(0x48)(None)
	struct FAnimNode_ApplyAdditive               AnimGraphNode_ApplyAdditive;                       // 0x62F8(0xC8)(None)
	struct FAnimNode_RefPose                     AnimGraphNode_IdentityPose;                        // 0x63C0(0x10)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_4;                     // 0x63D0(0x28)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_4;                  // 0x63F8(0xE0)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_8;                   // 0x64D8(0x48)(None)
	struct FAnimNode_Root                        AnimGraphNode_Root;                                // 0x6520(0x20)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_1;                    // 0x6540(0x108)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_3;                     // 0x6648(0x28)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_3;                              // 0x6670(0x48)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_3;                  // 0x66B8(0xE0)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_2;                     // 0x6798(0x28)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_2;                              // 0x67C0(0x48)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_32;                 // 0x6808(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_31;                 // 0x6830(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_30;                 // 0x6858(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_29;                 // 0x6880(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_28;                 // 0x68A8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_27;                 // 0x68D0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_26;                 // 0x68F8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_25;                 // 0x6920(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_24;                 // 0x6948(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_23;                 // 0x6970(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_22;                 // 0x6998(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_21;                 // 0x69C0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_20;                 // 0x69E8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_19;                 // 0x6A10(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_18;                 // 0x6A38(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_17;                 // 0x6A60(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_16;                 // 0x6A88(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_15;                 // 0x6AB0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_14;                 // 0x6AD8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_13;                 // 0x6B00(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_12;                 // 0x6B28(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_11;                 // 0x6B50(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_10;                 // 0x6B78(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_9;                  // 0x6BA0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_8;                  // 0x6BC8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_7;                  // 0x6BF0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_6;                  // 0x6C18(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_5;                  // 0x6C40(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_4;                  // 0x6C68(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_3;                  // 0x6C90(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_2;                  // 0x6CB8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_1;                  // 0x6CE0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult;                    // 0x6D08(0x28)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_10;                 // 0x6D30(0x70)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_11;                      // 0x6DA0(0x20)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_9;                  // 0x6DC0(0x70)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_10;                      // 0x6E30(0x20)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_8;                  // 0x6E50(0x70)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_9;                       // 0x6EC0(0x20)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_13;                   // 0x6EE0(0x48)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_8;                       // 0x6F28(0x20)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_1;                              // 0x6F48(0x48)(None)
	struct FAnimNode_RefPose                     AnimGraphNode_LocalRefPose;                        // 0x6F90(0x10)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_7;                       // 0x6FA0(0x20)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_12;                   // 0x6FC0(0x48)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_6;                       // 0x7008(0x20)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_11;                   // 0x7028(0x48)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_5;                       // 0x7070(0x20)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_7;                   // 0x7090(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_10;                   // 0x70D8(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_9;                    // 0x7120(0x48)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_4;                       // 0x7168(0x20)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_8;                    // 0x7188(0x48)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_2;                  // 0x71D0(0xE0)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_7;                  // 0x72B0(0x70)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_6;                   // 0x7320(0x48)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_6;                  // 0x7368(0x70)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_3;                       // 0x73D8(0x20)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_7;                    // 0x73F8(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_5;                   // 0x7440(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_6;                    // 0x7488(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_5;                    // 0x74D0(0x48)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_1;                  // 0x7518(0xE0)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_4;                    // 0x75F8(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_4;                   // 0x7640(0x48)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_2;                       // 0x7688(0x20)(None)
	struct FAnimNode_TwoWayBlend                 AnimGraphNode_TwoWayBlend_3;                       // 0x76A8(0xC8)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_5;                  // 0x7770(0x70)(None)
	struct FAnimNode_TwoWayBlend                 AnimGraphNode_TwoWayBlend_2;                       // 0x77E0(0xC8)(None)
	struct FAnimNode_TwoWayBlend                 AnimGraphNode_TwoWayBlend_1;                       // 0x78A8(0xC8)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_4;                  // 0x7970(0x70)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_3;                  // 0x79E0(0x70)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_2;                  // 0x7A50(0x70)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_1;                  // 0x7AC0(0x70)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer;                    // 0x7B30(0x70)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_3;                   // 0x7BA0(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_2;                   // 0x7BE8(0x48)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_1;                       // 0x7C30(0x20)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_3;                    // 0x7C50(0x48)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_1;                   // 0x7C98(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_2;                    // 0x7CE0(0x48)(None)
	struct FAnimNode_TwoWayBlend                 AnimGraphNode_TwoWayBlend;                         // 0x7D28(0xC8)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool;                     // 0x7DF0(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_1;                    // 0x7E38(0x48)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer;                      // 0x7E80(0x48)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult;                         // 0x7EC8(0x20)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine;                        // 0x7EE8(0xC8)(None)
	struct FAnimNode_LinkedAnimLayer             AnimGraphNode_LinkedAnimLayer_6;                   // 0x7FB0(0xC8)(None)
	struct FAnimNode_LinkedAnimLayer             AnimGraphNode_LinkedAnimLayer_5;                   // 0x8078(0xC8)(None)
	struct FAnimNode_LinkedAnimLayer             AnimGraphNode_LinkedAnimLayer_4;                   // 0x8140(0xC8)(None)
	struct FAnimNode_LinkedAnimLayer             AnimGraphNode_LinkedAnimLayer_3;                   // 0x8208(0xC8)(None)
	struct FAnimNode_LinkedAnimLayer             AnimGraphNode_LinkedAnimLayer_2;                   // 0x82D0(0xC8)(None)
	struct FAnimNode_LinkedAnimLayer             AnimGraphNode_LinkedAnimLayer_1;                   // 0x8398(0xC8)(None)
	struct FAnimNode_LinkedAnimLayer             AnimGraphNode_LinkedAnimLayer;                     // 0x8460(0xC8)(None)
	struct FAnimNode_ControlRig                  AnimGraphNode_ControlRig;                          // 0x8528(0x470)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot;                                // 0x8998(0x48)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend;                    // 0x89E0(0xE0)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose;                      // 0x8AC0(0x108)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_1;                     // 0x8BC8(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose;                       // 0x8BF0(0x28)(None)
	float                                        K2Node_PropertyAccess_36;                          // 0x8C18(0x4)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_34;                          // 0x8C1C(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1B88[0x3];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FRotator                              K2Node_PropertyAccess_31;                          // 0x8C20(0x18)(ZeroConstructor, IsPlainOldData, NoDestructor)
	float                                        K2Node_PropertyAccess_30;                          // 0x8C38(0x4)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        K2Node_PropertyAccess_29;                          // 0x8C3C(0x4)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               K2Node_PropertyAccess_28;                          // 0x8C40(0x18)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_27;                          // 0x8C58(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1B95[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FRotator                              K2Node_PropertyAccess_25;                          // 0x8C60(0x18)(ZeroConstructor, IsPlainOldData, NoDestructor)
	struct FVector                               K2Node_PropertyAccess_24;                          // 0x8C78(0x18)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               K2Node_PropertyAccess_23;                          // 0x8C90(0x18)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               K2Node_PropertyAccess_22;                          // 0x8CA8(0x18)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_21;                          // 0x8CC0(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_20;                          // 0x8CC1(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_19;                          // 0x8CC2(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_18;                          // 0x8CC3(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_17;                          // 0x8CC4(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_16;                          // 0x8CC5(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	enum class EPalCharacterMovementCustomMode   K2Node_PropertyAccess_15;                          // 0x8CC6(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1BB6[0x1];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FVector                               K2Node_PropertyAccess_14;                          // 0x8CC8(0x18)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FTransform                            K2Node_PropertyAccess_13;                          // 0x8CE0(0x60)(IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_12;                          // 0x8D40(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1BC2[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class APalWeaponBase*                        K2Node_PropertyAccess_11;                          // 0x8D48(0x8)(ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_10;                          // 0x8D50(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_9;                           // 0x8D51(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1BC6[0x6];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class APalWeaponBase*                        K2Node_PropertyAccess_8;                           // 0x8D58(0x8)(ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_7;                           // 0x8D60(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_6;                           // 0x8D61(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_5;                           // 0x8D62(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_PropertyAccess_4;                           // 0x8D63(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1BD6[0x4];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FRidingAnimationInfo                  K2Node_PropertyAccess_3;                           // 0x8D68(0x20)(NoDestructor)
	float                                        K2Node_PropertyAccess_2;                           // 0x8D88(0x4)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1BE0[0x4];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FWeaponAnimationInfo                  K2Node_PropertyAccess_1;                           // 0x8D90(0x258)(None)
	struct FWeaponAnimationInfo                  K2Node_PropertyAccess;                             // 0x8FE8(0x258)(None)
	float                                        __CustomProperty_ClavicleAdjustFloat_3EAAD7D248100B118DCFE280A191AF83; // 0x9240(0x4)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1BE9[0x4];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	double                                       Speed;                                             // 0x9248(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsAim;                                             // 0x9250(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1BEC[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FVector2D                             VelocityXY;                                        // 0x9258(0x10)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsGliding;                                         // 0x9268(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1BF2[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FRotator                              AimRotatorForSpine;                                // 0x9270(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         IsShooting;                                        // 0x9288(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1BF9[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FRotator                              AimRotatorArm;                                     // 0x9290(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         IsRiding;                                          // 0x92A8(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1C04[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FWeaponAnimationInfo                  WeaponInfo;                                        // 0x92B0(0x258)(Edit, BlueprintVisible, DisableEditOnInstance)
	struct FWeaponAnimationInfo                  PrevWeaponInfo;                                    // 0x9508(0x258)(Edit, BlueprintVisible, DisableEditOnInstance)
	double                                       ChangeWeaponWeight;                                // 0x9760(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	double                                       Right;                                             // 0x9768(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	double                                       Forward;                                           // 0x9770(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	double                                       Pitch;                                             // 0x9778(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	double                                       Yaw;                                               // 0x9780(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsCrouch;                                          // 0x9788(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsAttachLeftHand;                                  // 0x9789(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsSliding;                                         // 0x978A(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsRequestSliding;                                  // 0x978B(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsEnableSkySliding;                                // 0x978C(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsSprint;                                          // 0x978D(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1C2F[0x2];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FRidingAnimationInfo                  RidingAnimationInfo;                               // 0x9790(0x20)(Edit, BlueprintVisible, DisableEditOnInstance, NoDestructor)
	bool                                         HasWeapon;                                         // 0x97B0(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1C39[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	double                                       KawaiiWeight;                                      // 0x97B8(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                              Cloth01_FrontBagRotator;                           // 0x97C0(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         IsReloading;                                       // 0x97D8(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsJumpPreliminary;                                 // 0x97D9(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsEndJump;                                         // 0x97DA(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1C3E[0x5];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FTransform                            LeftHandTransform;                                 // 0x97E0(0x60)(Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsValidSprintAnimation;                            // 0x9840(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1C41[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class AActor*                                RidingActor;                                       // 0x9848(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, NoDestructor, HasGetValueTypeHash)
	bool                                         RiderModelIsBackward;                              // 0x9850(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         UseRidingAO;                                       // 0x9851(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1C52[0x6];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FRotator                              AimRotatorForSpine_Ride_WS;                        // 0x9858(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         IsDead;                                            // 0x9870(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         FootIKEnable;                                      // 0x9871(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsLookatEnable;                                    // 0x9872(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1C5D[0x5];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FVector                               LookAtTarget;                                      // 0x9878(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	double                                       LookatInTime;                                      // 0x9890(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	double                                       LookatOutTime;                                     // 0x9898(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsClimbing;                                        // 0x98A0(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1C6B[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class UAnimSequence*                         UniqueRideAnim;                                    // 0x98A8(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, NoDestructor, HasGetValueTypeHash)
	bool                                         IsUniqueRiding;                                    // 0x98B0(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1C73[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FVector                               Ride_IKPosHandR;                                   // 0x98B8(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               Ride_IKPosHandL;                                   // 0x98D0(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               Ride_IKPosFootR;                                   // 0x98E8(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               Ride_IKPosFootL;                                   // 0x9900(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                              Ride_SpineAddRotate;                               // 0x9918(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	double                                       Ride_HipForwardAdd;                                // 0x9930(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	double                                       Ride_SpineWeight;                                  // 0x9938(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	double                                       UniqueRide_RightHandWeight;                        // 0x9940(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               RideIK_Pole_HandR;                                 // 0x9948(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               RideIK_Pole_HandL;                                 // 0x9960(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               RideIK_Pole_FootR;                                 // 0x9978(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FVector                               RideIK_Pole_FootL;                                 // 0x9990(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsUniqueRideIK;                                    // 0x99A8(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1CCE[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	double                                       UniqueRide_LeftHandWeight;                         // 0x99B0(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UNiagaraComponent*                     FootStepEffect;                                    // 0x99B8(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, InstancedReference, NoDestructor, HasGetValueTypeHash)
	bool                                         IsWalking;                                         // 0x99C0(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1CDB[0x3];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	float                                        ClavicleAdjustDegree;                              // 0x99C4(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UAnimSequence*                         GlidingAS;                                         // 0x99C8(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, NoDestructor, HasGetValueTypeHash)
	double                                       BlendTime_ForEagleGlider;                          // 0x99D0(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsDedicatedServer;                                 // 0x99D8(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_1CEC[0x7];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	class APalCharacter*                         TSCached_OwnerCharacter;                           // 0x99E0(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, NoDestructor, HasGetValueTypeHash)
	class UPalShooterComponent*                  TSCached_ShooterComponent;                         // 0x99E8(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, InstancedReference, NoDestructor, HasGetValueTypeHash)
	class UPalCharacterMovementComponent*        TSCached_MovementComponent;                        // 0x99F0(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, InstancedReference, NoDestructor, HasGetValueTypeHash)
	class UPalLookAtComponent*                   TSCached_LookAtComponent;                          // 0x99F8(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, InstancedReference, NoDestructor, HasGetValueTypeHash)
	class UPalFootIKComponent*                   TSCached_FootIkComponent;                          // 0x9A00(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, InstancedReference, NoDestructor, HasGetValueTypeHash)
	class UPalSkeletalMeshComponent*             TSCached_SkeletalMeshComponent;                    // 0x9A08(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, InstancedReference, NoDestructor, HasGetValueTypeHash)
	struct FRotator                              TSCache_CameraRotator;                             // 0x9A10(0x18)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)

	static class UClass* StaticClass();
	static class UABP_Player_C* GetDefaultObj();

	void ClothLayer(const struct FPoseLink& InPose, struct FPoseLink* ClothLayer);
	void LeftHandAttach(const struct FPoseLink& InPose, struct FPoseLink* LeftHandAttach);
	void UniqueRideFullBodyIK(const struct FPoseLink& InPose_3, struct FPoseLink* UniqueRideFullBodyIK);
	void Lookat(const struct FPoseLink& InPose_2, struct FPoseLink* Lookat);
	void FootIK(const struct FPoseLink& InPose_1, struct FPoseLink* FootIK);
	void RidingOverride(const struct FPoseLink& InPose_0, struct FPoseLink* RidingOverride);
	void WeaponUpperOverride(const struct FPoseLink& InPose, struct FPoseLink* WeaponUpperOverride);
	void AnimGraph(struct FPoseLink* AnimGraph);
	void TempFixLeftHandAttach(bool CallFunc_IsValid_ReturnValue, class APalWeaponBase* CallFunc_GetHasWeapon_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, class APalWeaponBase* CallFunc_GetHasWeapon_ReturnValue_1, bool CallFunc_IsUseLeftHandAttach_ReturnValue, class APalWeaponBase* CallFunc_GetHasWeapon_ReturnValue_2, const struct FTransform& CallFunc_GetLeftHandTransform_ReturnValue, class APalWeaponBase* CallFunc_GetHasWeapon_ReturnValue_3, bool CallFunc_IsUseLeftHandAttach_ReturnValue_1, bool CallFunc_CanLeftHandAttach_ReturnValue, bool CallFunc_BooleanAND_ReturnValue, class APalWeaponBase* CallFunc_GetHasWeapon_ReturnValue_4, bool CallFunc_IsValid_ReturnValue_2);
	void GameThreadUpdate(double DeltaTime, class UPalGameSetting* CallFunc_GetGameSetting_ReturnValue);
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime, double CallFunc_Divide_DoubleDouble_ReturnValue, const struct FRotator& CallFunc_NormalizedDeltaRotator_ReturnValue, const struct FVector& CallFunc_GetRightVector_ReturnValue, bool CallFunc_IsValid_ThreadSafe_ReturnValue, const struct FRotator& CallFunc_RotatorFromAxisAndAngle_ReturnValue, bool CallFunc_IsValid_ThreadSafe_ReturnValue_1, const struct FRotator& CallFunc_MakeRotator_ReturnValue, const struct FRotator& CallFunc_RInterpTo_ReturnValue, float CallFunc_BreakRotator_Roll, float CallFunc_BreakRotator_Pitch, float CallFunc_BreakRotator_Yaw, double CallFunc_ClampAngle_ReturnValue, double CallFunc_ClampAngle_ReturnValue_1, float CallFunc_RotatorFromAxisAndAngle_Angle_ImplicitCast, float CallFunc_MakeRotator_Pitch_ImplicitCast, float CallFunc_MakeRotator_Yaw_ImplicitCast, double CallFunc_ClampAngle_AngleDegrees_ImplicitCast, double CallFunc_ClampAngle_AngleDegrees_ImplicitCast_1);
	void GetFootStepEffectScale(double* Scale, class UPalDatabaseCharacterParameter* CallFunc_GetDatabaseCharacterParameter_ReturnValue, const struct FPalSizeParameterDataRow& CallFunc_FindPalSizeParameter_RowData, bool CallFunc_FindPalSizeParameter_ReturnValue, double K2Node_FunctionResult_Scale_ImplicitCast);
	void CanSpawnFootStepEffect(bool* CanSpawn, class APawn* Owner, class UPalRiderComponent* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_IsRiding_ReturnValue, class UPalDebugSetting* CallFunc_GetPalDebugSetting_ReturnValue, bool CallFunc_IsValid_ReturnValue, class UPalCharacterParameterComponent* CallFunc_GetComponentByClass_ReturnValue_1, enum class EPhysicalSurface CallFunc_GetFloorPhisicalSurface_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, bool K2Node_SwitchEnum_CmpSuccess, bool CallFunc_IsValid_ReturnValue_2, bool CallFunc_HasFloorPhysMaterial_ReturnValue, class APawn* CallFunc_TryGetPawnOwner_ReturnValue, class UPalCharacterMovementComponent* CallFunc_GetComponentByClass_ReturnValue_2, bool CallFunc_IsValid_ReturnValue_3, bool CallFunc_IsEnteredWater_ReturnValue);
	void GetFootStepCharacterSpeed(double* CharacterSpeed, class UPalCharacterMovementComponent* MovementComponent, double CallFunc_Divide_DoubleDouble_ReturnValue, double CallFunc_FClamp_ReturnValue, bool CallFunc_IsValid_ReturnValue, class APawn* CallFunc_TryGetPawnOwner_ReturnValue, class UPalCharacterMovementComponent* CallFunc_GetComponentByClass_ReturnValue, double CallFunc_Divide_DoubleDouble_A_ImplicitCast, double CallFunc_Divide_DoubleDouble_B_ImplicitCast);
	void StopFootStepEffect(bool CallFunc_IsValid_ReturnValue);
	void StartFootStepEffect(double CallFunc_GetFootStepEffectScale_Scale, bool CallFunc_IsValid_ReturnValue, class APawn* CallFunc_TryGetPawnOwner_ReturnValue, class USkeletalMeshComponent* CallFunc_GetMainMeshByActor_ReturnValue, class UNiagaraComponent* CallFunc_SpawnSystemAttached_ReturnValue, float CallFunc_SetVariableFloat_InValue_ImplicitCast);
	void Update_Foot_Step_Effect(double DeltaTime, bool CallFunc_IsDedicatedServer_ReturnValue, bool CallFunc_CanSpawnFootStepEffect_CanSpawn, double CallFunc_GetFootStepCharacterSpeed_CharacterSpeed, bool CallFunc_IsValid_ReturnValue, float CallFunc_SetVariableFloat_InValue_ImplicitCast);
	void PlaySound(class FName SoundId, const struct FVector& OffsetDown, const struct FVector& OffsetUp, const struct FPalSoundOptions& Options, class AActor* Owner, class FName Name_None, const struct FPalSoundOptions& K2Node_MakeStruct_PalSoundOptions, const struct FPalDataTableRowName_SoundID& K2Node_MakeStruct_PalDataTableRowName_SoundID, bool CallFunc_NotEqual_NameName_ReturnValue, class APawn* CallFunc_TryGetPawnOwner_ReturnValue, bool CallFunc_NotEqual_NameName_ReturnValue_1, bool CallFunc_IsValid_ReturnValue, bool CallFunc_BooleanAND_ReturnValue);
	void GetRideIKPos(class FName SocketName, const struct FTransform& ConvTF, class USkeletalMeshComponent* Mesh, struct FVector* IKPos, const struct FTransform& CallFunc_GetSocketTransform_ReturnValue, const struct FTransform& CallFunc_ComposeTransforms_ReturnValue, const struct FVector& CallFunc_BreakTransform_Location, const struct FRotator& CallFunc_BreakTransform_Rotation, const struct FVector& CallFunc_BreakTransform_Scale);
	void RiderComponent_UniqueRideUpdate(class UPalRiderComponent* RiderComponent, class APalCharacter* ThisCharacter, double DeltaTime, const struct FTransform& UniqueRideCoordinateTransform, double Const_MaxDistance, double Distance, const struct FVector& HumanChestPos, class USkeletalMeshComponent* MonsterMesh, class AActor* MonsterActor, bool CallFunc_BooleanOR_ReturnValue, bool CallFunc_CanUniqueRideIK_ReturnValue, class UPalUniqueRideAnimeAssetBase* CallFunc_GetUniqueRideAnimeAsset_ReturnValue, bool CallFunc_IsValid_ReturnValue, bool CallFunc_BooleanOR_ReturnValue_1, const struct FVector& CallFunc_GetRideIKPos_IKPos, const struct FVector& CallFunc_GetRideIKPos_IKPos_1, const struct FVector& CallFunc_GetRideIKPos_IKPos_2, const struct FVector& CallFunc_GetRideIKPos_IKPos_3, class USkeletalMeshComponent* CallFunc_GetMainMeshByActor_ReturnValue, class UPalSkeletalMeshComponent* CallFunc_GetMainMesh_ReturnValue, const struct FTransform& CallFunc_GetRelativeTransform_ReturnValue, class UPalRideMarkerComponent* CallFunc_GetComponentByClass_ReturnValue, class FName CallFunc_GetAttachSocketName_ReturnValue, const struct FTransform& CallFunc_GetRelativeTransform_ReturnValue_1, const struct FTransform& CallFunc_GetSocketTransform_ReturnValue, const struct FTransform& CallFunc_ComposeTransforms_ReturnValue, const struct FTransform& CallFunc_ComposeTransforms_ReturnValue_1, double CallFunc_Multiply_DoubleDouble_ReturnValue, const struct FTransform& CallFunc_InvertTransform_ReturnValue, const struct FVector& CallFunc_Conv_FloatToVector_ReturnValue, double CallFunc_Subtract_DoubleDouble_ReturnValue, double CallFunc_FClamp_ReturnValue, double CallFunc_Vector_Distance_ReturnValue, double CallFunc_Divide_DoubleDouble_ReturnValue, double CallFunc_Lerp_ReturnValue, double CallFunc_FClamp_ReturnValue_1, double CallFunc_Vector_Distance_ReturnValue_1, double CallFunc_FMax_ReturnValue, const struct FVector& CallFunc_K2_GetActorLocation_ReturnValue, const struct FVector& CallFunc_GetActorUpVector_ReturnValue, const struct FVector& CallFunc_Multiply_VectorVector_ReturnValue, class AActor* CallFunc_GetRindingActor_ReturnValue, const struct FVector& CallFunc_Add_VectorVector_ReturnValue);
	void LookatParameterUpdate(bool CallFunc_IsValid_ThreadSafe_ReturnValue, double K2Node_VariableSet_LookatInTime_ImplicitCast, double K2Node_VariableSet_LookatOutTime_ImplicitCast);
	void Cloth01FrontBagRotation(struct FRotator* BagRotator, const struct FQuat& CallFunc_GetBoneRotation_ReturnValue, const struct FQuat& CallFunc_GetBoneRotation_ReturnValue_1, const struct FVector& CallFunc_Vector_Right_ReturnValue, const struct FVector& CallFunc_Vector_Up_ReturnValue, const struct FVector& CallFunc_Multiply_VectorFloat_ReturnValue, const struct FVector& CallFunc_Multiply_VectorFloat_ReturnValue_1, const struct FVector& CallFunc_Vector_Forward_ReturnValue, const struct FVector& CallFunc_Add_VectorVector_ReturnValue, const struct FVector& CallFunc_Quat_RotateVector_ReturnValue, const struct FVector& CallFunc_Normal_ReturnValue, const struct FVector& CallFunc_Quat_RotateVector_ReturnValue_1, double CallFunc_Dot_VectorVector_ReturnValue, double CallFunc_Subtract_DoubleDouble_ReturnValue, double CallFunc_Multiply_DoubleDouble_ReturnValue, double CallFunc_FClamp_ReturnValue, double CallFunc_Lerp_ReturnValue, double CallFunc_Lerp_ReturnValue_1, double CallFunc_Lerp_ReturnValue_2, const struct FRotator& CallFunc_MakeRotator_ReturnValue, float CallFunc_MakeRotator_Roll_ImplicitCast, float CallFunc_MakeRotator_Yaw_ImplicitCast, float CallFunc_MakeRotator_Pitch_ImplicitCast);
	void SerWeaponNum(class UPalShooterComponent* ShooterComponent, int32* WeaponNum, class APalWeaponBase* CallFunc_GetHasWeapon_ReturnValue, const class FString& CallFunc_GetDisplayName_ReturnValue, bool K2Node_SwitchString_CmpSuccess);
	void RiderComponentUpdate(class UPalRiderComponent* PalRiderComponent, bool CallFunc_IsRiding_ReturnValue, const struct FVector2D& CallFunc_MakeVector2D_ReturnValue, class UPalUniqueRideAnimeAssetBase* CallFunc_GetUniqueRideAnimeAsset_ReturnValue, bool CallFunc_IsValid_ReturnValue, class UAnimSequence* CallFunc_GetRideAnimSequence_ReturnValue, class UPalRideMarkerComponent* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_GetRiderModelIsBackward_ReturnValue, bool CallFunc_EqualEqual_ByteByte_ReturnValue, class AActor* CallFunc_GetRindingActor_ReturnValue);
	void PalCharacterMovementComponentUpdate(bool CallFunc_EqualEqual_ByteByte_ReturnValue, double CallFunc_VSize_ReturnValue, double CallFunc_BreakVector_X, double CallFunc_BreakVector_Y, double CallFunc_BreakVector_Z, const struct FRotator& CallFunc_NegateRotator_ReturnValue, float CallFunc_BreakRotator_Roll, float CallFunc_BreakRotator_Pitch, float CallFunc_BreakRotator_Yaw, const struct FRotator& CallFunc_MakeRotator_ReturnValue, const struct FVector& CallFunc_GreaterGreater_VectorRotator_ReturnValue, double CallFunc_BreakVector_X_1, double CallFunc_BreakVector_Y_1, double CallFunc_BreakVector_Z_1, const struct FVector2D& CallFunc_MakeVector2D_ReturnValue);
	void ShooterComponentUpdate(class UPalRiderComponent* RiderComponent, bool CallFunc_IsValid_ThreadSafe_ReturnValue, bool CallFunc_IsValid_ThreadSafe_ReturnValue_1, bool CallFunc_BooleanOR_ReturnValue, const struct FRotator& CallFunc_MakeRotFromX_ReturnValue, float CallFunc_BreakRotator_Roll, float CallFunc_BreakRotator_Pitch, float CallFunc_BreakRotator_Yaw, double CallFunc_Subtract_DoubleDouble_ReturnValue, bool CallFunc_Greater_DoubleDouble_ReturnValue, double CallFunc_Multiply_DoubleDouble_ReturnValue, double CallFunc_SelectFloat_ReturnValue, const struct FRotator& CallFunc_MakeRotator_ReturnValue, double CallFunc_Divide_DoubleDouble_ReturnValue, const struct FRotator& CallFunc_MakeRotator_ReturnValue_1, double K2Node_VariableSet_ChangeWeaponWeight_ImplicitCast, double CallFunc_Subtract_DoubleDouble_B_ImplicitCast, double CallFunc_Multiply_DoubleDouble_A_ImplicitCast, double CallFunc_Greater_DoubleDouble_A_ImplicitCast, float CallFunc_MakeRotator_Roll_ImplicitCast, float CallFunc_MakeRotator_Roll_ImplicitCast_1);
	void UpdateAnimationParameter(class APalCharacter* ThisCharacter, double DeltaTime, bool CallFunc_IsDead_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue, const struct FRotator& CallFunc_Cloth01FrontBagRotation_BagRotator, bool CallFunc_BooleanAND_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue_1, class APalPlayerCharacter* K2Node_DynamicCast_AsPal_Player_Character, bool K2Node_DynamicCast_bSuccess, bool CallFunc_BooleanOR_ReturnValue, const struct FRotator& CallFunc_GetCameraRotator_ReturnValue, class UPalRiderComponent* CallFunc_GetComponentByClass_ReturnValue, bool CallFunc_IsValid_ReturnValue);
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_ControlRig_3EAAD7D248100B118DCFE280A191AF83();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_7838EE814B598C3A344B9F8500E91FA4();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_9CD38A96429EBB43F9FCA4AE888E9D30();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_2BA246414BFB0071817AB1B6C2FBC83F();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_C70243AF44D929CECBC285B95A209F65();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_F8FF710E41ED5F7DA3BA9BAFE633876D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_481DAFEA4AE40C2EFF25618E9C553B35();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_71C911754A5B3DC3A317788B75B519B1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_996FDE544B684CDDFCA6A784C6AE9917();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_261928F6456722BEC96B86A1ADEB4BF2();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_48DAA1E9450D4A5A46AAFDAD0D2AD2B0();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_5E053D1A48F0BBA7E66B278333CAD210();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_RotationOffsetBlendSpace_A05F6A464942E6EC33FA9B8763952574();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_RotationOffsetBlendSpace_3BFF5F7E4AE63A522D3E25878E1FB093();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_137DA5324EFB47824ACFEFBEB5A9345E();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_ModifyBone_6E057CAF466FA7A297375EB70B4C9887();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_ModifyBone_33CE303E429A72504664588F8208C607();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_ModifyBone_402B5DDF4A554B98804CAFBC147C07B1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_4416090C4FED6604161B15843476CF58();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_E76C13FE4F7043059C87EA91999E16ED();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TwoBoneIK_64CC3FAB4A2F8101A3ABCDAB23163E95();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TwoBoneIK_526ABD1A42AD6ADBA987689868DF9ACB();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_E94DA2EA481166A5E285B289F1C37CBD();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_795924014DFB08AE86A92196C6243888();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_ModifyBone_DD28266243FD9E59AD3748AABC4EC94E();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_ModifyBone_71AACF6D4D2B261CA61871BDCE75FA8C();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_ModifyBone_21D9D3ED464D031FBD32AAA417100B21();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_ModifyBone_B70A311E47AEFAEE0A1D709D2E5F6D53();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_ModifyBone_3A5774CC4E383BBEFC920297F7931545();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_E26724CB458B422C7C5E32A0EDC0CCF8();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_A0D7C56C4DB9926E12DA97B72BAE7F9C();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_DE4CD99543A8127206BEFDA34A61B600();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_51630B8C43E034BBFCD4F29091E8C6E3();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_1BDF9D1447DF958038E620AEAF8B3D3D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_F4551B3F4954505485115494503A337D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_ED5C3EC2486FB5B5EA51D8A3B5A970C9();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_655311544FEA15E7245AB58E68400569();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_BC9B02BC4F1BA6E447E80797ACACDD6A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_SequencePlayer_0C4BD33A4A739BB806132999D7790073();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_LayeredBoneBlend_2A54E77148A6C7AEC0F9ED9AE38259A1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_6D1442674165687285F288812FDB1766();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_BlendListByBool_500901BD49D7425200ABDC8BE85C7F25();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_690EA54243E92C4F5F8441A6ACAD0053();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_7BFFAF7F4E48FAADBB3FC4A30EEFAC05();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_DE4B6EE04F5CA7CAF338B8AC885C2C42();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_7791845548B5FB3059EB7DABA1AC82E1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_ADB9F44F417FA3429012D4AC0960FE81();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_819BBAD54A8DC3F5CD5532AB19D034AA();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_BAAF9A3E45024386AB704DA5C92DDA6F();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_7E971E664EA213C4A22D748CAF7084D3();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_BE56BE41476FF7AE05D9CF90C9BEB1A2();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_ACBBE620474D08C7FF2166BE65257A91();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_22357FDA45F4F504502F4D9C2B8DAC0B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_B81AB908417297CD4DEAABAD0C247287();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_8E3C577B4AB26BF954C089A7AE5DB9F4();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_A134763D4D6875423DA3FB8416C19B47();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_1CFB42474BCF26A449A2E3960AF20DC4();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Player_AnimGraphNode_TransitionResult_B11373AF493FD1828F548C9C6DFCE1CF();
	void BlueprintUpdateAnimation(float DeltaTimeX);
	void BlueprintBeginPlay();
	void AnimNotify_Entered_StandIdle();
	void AnimNotify_Entered_Walk();
	void AnimNotify_Entered_Sprint();
	void AnimNotify_Entered_Crouch();
	void AnimNotify_Exit_Crouch();
	void AnimNotify_OnStandIdle();
	void AnimNotify_OnCrouch();
	void AnimNotify_OnCrouchMove();
	void AnimNotify_OnWalk();
	void AnimNotify_OnExitStand();
	void AnimNotify_Start_Climb();
	void ExecuteUbergraph_ABP_Player(int32 EntryPoint, enum class EWeaponAnimationPoseType Temp_byte_Variable, bool CallFunc_BooleanOR_ReturnValue, bool CallFunc_BooleanOR_ReturnValue_1, bool CallFunc_BooleanOR_ReturnValue_2, enum class EWeaponAnimationPoseType Temp_byte_Variable_1, enum class EWeaponAnimationPoseType Temp_byte_Variable_2, enum class EWeaponAnimationPoseType Temp_byte_Variable_3, enum class EWeaponAnimationPoseType Temp_byte_Variable_4, enum class EWeaponAnimationPoseType Temp_byte_Variable_5, enum class EWeaponAnimationPoseType Temp_byte_Variable_6, class UAnimSequence* CallFunc_Map_Find_Value, bool CallFunc_Map_Find_ReturnValue, class UAnimSequence* CallFunc_Map_Find_Value_1, bool CallFunc_Map_Find_ReturnValue_1, bool CallFunc_BooleanOR_ReturnValue_3, enum class EWeaponAnimationPoseType Temp_byte_Variable_7, enum class EWeaponAnimationPoseType Temp_byte_Variable_8, class UAnimSequence* CallFunc_Map_Find_Value_2, bool CallFunc_Map_Find_ReturnValue_2, bool CallFunc_Not_PreBool_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_2, bool CallFunc_BooleanAND_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue_2, double CallFunc_Multiply_DoubleDouble_ReturnValue, const struct FVector& CallFunc_MakeVector_ReturnValue, class UAnimSequence* CallFunc_Map_Find_Value_3, bool CallFunc_Map_Find_ReturnValue_3, const struct FRotator& CallFunc_Multiply_RotatorFloat_ReturnValue, const struct FRotator& CallFunc_Multiply_RotatorFloat_ReturnValue_1, class UPalShooterComponent* CallFunc_GetComponentByClass_ReturnValue, const struct FRotator& CallFunc_Multiply_RotatorFloat_ReturnValue_2, bool CallFunc_Greater_DoubleDouble_ReturnValue, TArray<struct FAkExternalSourceInfo>& Temp_struct_Variable, FDelegateProperty_ Temp_delegate_Variable, const struct FRotator& CallFunc_Multiply_RotatorFloat_ReturnValue_3, const struct FRotator& CallFunc_Multiply_RotatorFloat_ReturnValue_4, class UAnimSequence* CallFunc_Map_Find_Value_4, bool CallFunc_Map_Find_ReturnValue_4, enum class EWeaponAnimationPoseType Temp_byte_Variable_9, enum class EWeaponAnimationPoseType Temp_byte_Variable_10, enum class EWeaponAnimationPoseType Temp_byte_Variable_11, bool CallFunc_BooleanAND_ReturnValue_3, bool CallFunc_Not_PreBool_ReturnValue_3, bool CallFunc_BooleanAND_ReturnValue_4, bool CallFunc_LessEqual_DoubleDouble_ReturnValue, bool CallFunc_BooleanOR_ReturnValue_4, bool CallFunc_BooleanOR_ReturnValue_5, bool CallFunc_Not_PreBool_ReturnValue_4, bool CallFunc_BooleanAND_ReturnValue_5, class UAnimSequence* CallFunc_Map_Find_Value_5, bool CallFunc_Map_Find_ReturnValue_5, float CallFunc_Conv_BoolToFloat_ReturnValue, enum class EPalFootType Temp_byte_Variable_12, bool CallFunc_BooleanOR_ReturnValue_6, float CallFunc_Map_Find_Value_6, bool CallFunc_Map_Find_ReturnValue_6, double CallFunc_Multiply_DoubleDouble_ReturnValue_1, const struct FVector& CallFunc_MakeVector_ReturnValue_1, bool CallFunc_BooleanAND_ReturnValue_6, enum class EPalFootType Temp_byte_Variable_13, float CallFunc_Map_Find_Value_7, bool CallFunc_Map_Find_ReturnValue_7, const struct FVector& CallFunc_MakeVector_ReturnValue_2, bool CallFunc_BooleanOR_ReturnValue_7, bool CallFunc_BooleanOR_ReturnValue_8, double CallFunc_Divide_DoubleDouble_ReturnValue, const struct FRotator& CallFunc_MakeRotator_ReturnValue, bool CallFunc_IsValid_ThreadSafe_ReturnValue, bool CallFunc_Vector_IsZero_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_5, bool CallFunc_Greater_DoubleDouble_ReturnValue_1, bool CallFunc_BooleanOR_ReturnValue_9, double CallFunc_VSizeXYSquared_ReturnValue, bool CallFunc_Greater_DoubleDouble_ReturnValue_2, bool CallFunc_BooleanOR_ReturnValue_10, bool CallFunc_Not_PreBool_ReturnValue_6, bool CallFunc_BooleanAND_ReturnValue_7, bool CallFunc_Not_PreBool_ReturnValue_7, class UAimOffsetBlendSpace* CallFunc_Map_Find_Value_8, bool CallFunc_Map_Find_ReturnValue_8, class UAimOffsetBlendSpace* CallFunc_Map_Find_Value_9, bool CallFunc_Map_Find_ReturnValue_9, double CallFunc_BreakVector_X, double CallFunc_BreakVector_Y, double CallFunc_BreakVector_Z, bool CallFunc_Less_DoubleDouble_ReturnValue, bool CallFunc_BooleanAND_ReturnValue_8, bool CallFunc_Not_PreBool_ReturnValue_8, bool CallFunc_Not_PreBool_ReturnValue_9, bool CallFunc_IsZero2D_ReturnValue, bool CallFunc_BooleanAND_ReturnValue_9, bool CallFunc_Not_PreBool_ReturnValue_10, bool CallFunc_BooleanOR_ReturnValue_11, bool CallFunc_BooleanOR_ReturnValue_12, bool CallFunc_Not_PreBool_ReturnValue_11, bool CallFunc_BooleanAND_ReturnValue_10, bool CallFunc_BooleanAND_ReturnValue_11, bool CallFunc_Greater_DoubleDouble_ReturnValue_3, bool CallFunc_BooleanAND_ReturnValue_12, bool CallFunc_BooleanOR_ReturnValue_13, bool CallFunc_Not_PreBool_ReturnValue_12, bool CallFunc_BooleanAND_ReturnValue_13, bool CallFunc_LessEqual_DoubleDouble_ReturnValue_1, bool CallFunc_BooleanOR_ReturnValue_14, bool CallFunc_Not_PreBool_ReturnValue_13, class UAnimSequence* CallFunc_Map_Find_Value_10, bool CallFunc_Map_Find_ReturnValue_10, bool CallFunc_Greater_DoubleDouble_ReturnValue_4, bool CallFunc_Greater_DoubleDouble_ReturnValue_5, bool CallFunc_BooleanAND_ReturnValue_14, class UAnimSequence* CallFunc_Map_Find_Value_11, bool CallFunc_Map_Find_ReturnValue_11, class UAnimSequence* CallFunc_Map_Find_Value_12, bool CallFunc_Map_Find_ReturnValue_12, class UAnimSequence* CallFunc_Map_Find_Value_13, bool CallFunc_Map_Find_ReturnValue_13, bool CallFunc_Not_PreBool_ReturnValue_14, bool CallFunc_BooleanAND_ReturnValue_15, bool CallFunc_LessEqual_DoubleDouble_ReturnValue_2, bool CallFunc_LessEqual_DoubleDouble_ReturnValue_3, bool CallFunc_Not_PreBool_ReturnValue_15, bool CallFunc_BooleanAND_ReturnValue_16, float CallFunc_GetCurveValue_ReturnValue, double CallFunc_Lerp_ReturnValue, float K2Node_Event_DeltaTimeX, bool CallFunc_Not_PreBool_ReturnValue_16, bool CallFunc_BooleanAND_ReturnValue_17, class APawn* CallFunc_TryGetPawnOwner_ReturnValue, bool CallFunc_BooleanAND_ReturnValue_18, class APalCharacter* K2Node_DynamicCast_AsPal_Character, bool K2Node_DynamicCast_bSuccess, bool CallFunc_IsDedicatedServer_ReturnValue, class APawn* CallFunc_TryGetPawnOwner_ReturnValue_1, class APalCharacter* K2Node_DynamicCast_AsPal_Character_1, bool K2Node_DynamicCast_bSuccess_1, class UPalCharacterMovementComponent* CallFunc_GetComponentByClass_ReturnValue_1, class UPalLookAtComponent* CallFunc_GetComponentByClass_ReturnValue_2, class UPalFootIKComponent* CallFunc_GetComponentByClass_ReturnValue_3, class UPalSkeletalMeshComponent* CallFunc_GetComponentByClass_ReturnValue_4, class APawn* CallFunc_TryGetPawnOwner_ReturnValue_2, int32 CallFunc_PostEvent_ReturnValue, double CallFunc_Greater_DoubleDouble_A_ImplicitCast, float CallFunc_Array_Set_Item_ImplicitCast, float CallFunc_Array_Set_Item_ImplicitCast_1, double CallFunc_LessEqual_DoubleDouble_A_ImplicitCast, double CallFunc_Multiply_DoubleDouble_A_ImplicitCast, double CallFunc_MakeVector_X_ImplicitCast, float CallFunc_MakeRotator_Yaw_ImplicitCast, double CallFunc_Greater_DoubleDouble_A_ImplicitCast_1, float K2Node_StructMemberSet___FloatProperty_12_ImplicitCast, float K2Node_StructMemberSet___FloatProperty_13_ImplicitCast, float K2Node_StructMemberSet___FloatProperty_14_ImplicitCast, float K2Node_StructMemberSet___FloatProperty_15_ImplicitCast, double CallFunc_Greater_DoubleDouble_A_ImplicitCast_2, double CallFunc_LessEqual_DoubleDouble_A_ImplicitCast_1, double CallFunc_Greater_DoubleDouble_A_ImplicitCast_3, double CallFunc_Greater_DoubleDouble_A_ImplicitCast_4, float CallFunc_Array_Set_Item_ImplicitCast_2, float CallFunc_Array_Set_Item_ImplicitCast_3, float CallFunc_Array_Set_Item_ImplicitCast_4, double CallFunc_LessEqual_DoubleDouble_A_ImplicitCast_2, double CallFunc_Lerp_Alpha_ImplicitCast, float K2Node_StructMemberSet_Alpha_ImplicitCast, double CallFunc_UpdateAnimationParameter_DeltaTime_ImplicitCast, double CallFunc_Update_Foot_Step_Effect_DeltaTime_ImplicitCast);
};

}


