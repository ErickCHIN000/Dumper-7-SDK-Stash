#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x158 - 0x158)
// BlueprintGeneratedClass BP_ActionDefenseWait_Wait.BP_ActionDefenseWait_Wait_C
class UBP_ActionDefenseWait_Wait_C : public UBP_ActionDefenseWait_C
{
public:

	static class UClass* StaticClass();
	static class UBP_ActionDefenseWait_Wait_C* GetDefaultObj();

};

}


