#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x20 (0x20 - 0x0)
// Function ALI_PalmiSubFunction.ALI_PalmiSubFunction_C.LeftHandAttach
struct IALI_PalmiSubFunction_C_LeftHandAttach_Params
{
public:
	struct FPoseLink                             InPose;                                            // 0x0(0x10)(BlueprintVisible, BlueprintReadOnly, Parm, NoDestructor)
	struct FPoseLink                             LeftHandAttach;                                    // 0x10(0x10)(Parm, OutParm, NoDestructor)
};

}
}


