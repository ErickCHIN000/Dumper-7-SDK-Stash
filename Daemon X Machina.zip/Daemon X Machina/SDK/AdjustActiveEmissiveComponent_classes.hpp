#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x198 - 0x198)
// BlueprintGeneratedClass AdjustActiveEmissiveComponent.AdjustActiveEmissiveComponent_C
class UAdjustActiveEmissiveComponent_C : public UTTLAdjustActiveEmissiveComponent
{
public:

	static class UClass* StaticClass();
	static class UAdjustActiveEmissiveComponent_C* GetDefaultObj();

};

}


