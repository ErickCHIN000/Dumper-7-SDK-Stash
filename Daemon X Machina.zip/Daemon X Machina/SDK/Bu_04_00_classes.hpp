#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0xB18 - 0xB10)
// BlueprintGeneratedClass Bu_04_00.Bu_04_00_C
class ABu_04_00_C : public AVertMissile_C
{
public:
	class URaderTargetComponent_C*               RaderTargetComponent1;                             // 0xB10(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABu_04_00_C* GetDefaultObj();

	void UserConstructionScript();
};

}


