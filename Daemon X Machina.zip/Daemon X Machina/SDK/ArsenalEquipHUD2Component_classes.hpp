#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x198 - 0x198)
// BlueprintGeneratedClass ArsenalEquipHUD2Component.ArsenalEquipHUD2Component_C
class UArsenalEquipHUD2Component_C : public UTTLArsenalEquipHUD2Component
{
public:

	static class UClass* StaticClass();
	static class UArsenalEquipHUD2Component_C* GetDefaultObj();

};

}


