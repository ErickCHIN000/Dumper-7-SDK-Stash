#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1F0 - 0x1F0)
// BlueprintGeneratedClass CollectedMovement.CollectedMovement_C
class UCollectedMovement_C : public UTTLCollectedCharaComponent
{
public:

	static class UClass* StaticClass();
	static class UCollectedMovement_C* GetDefaultObj();

};

}


