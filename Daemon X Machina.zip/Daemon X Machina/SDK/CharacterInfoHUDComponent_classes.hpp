#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x190 - 0x190)
// BlueprintGeneratedClass CharacterInfoHUDComponent.CharacterInfoHUDComponent_C
class UCharacterInfoHUDComponent_C : public UTTLCharacterInfoHUDComponent
{
public:

	static class UClass* StaticClass();
	static class UCharacterInfoHUDComponent_C* GetDefaultObj();

};

}


