#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x500 - 0x4F8)
// BlueprintGeneratedClass CommonPopUp.CommonPopUp_C
class ACommonPopUp_C : public ATTLCommonPopup
{
public:
	class USceneComponent*                       DefaultSceneRoot;                                  // 0x4F8(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ACommonPopUp_C* GetDefaultObj();

};

}


