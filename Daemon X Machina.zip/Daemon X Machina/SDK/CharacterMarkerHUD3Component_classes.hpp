#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x250 - 0x250)
// BlueprintGeneratedClass CharacterMarkerHUD3Component.CharacterMarkerHUD3Component_C
class UCharacterMarkerHUD3Component_C : public UTTLCharacterMarkerHUD3Component
{
public:

	static class UClass* StaticClass();
	static class UCharacterMarkerHUD3Component_C* GetDefaultObj();

};

}


