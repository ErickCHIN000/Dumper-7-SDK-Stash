#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x1 (0x1 - 0x0)
// Function ArsenalAttachedHUD2Component.ArsenalAttachedHUD2Component_C.ChangeMode
struct UArsenalAttachedHUD2Component_C_ChangeMode_Params
{
public:
	bool                                         IsArsenalMode;                                     // 0x0(0x1)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

}
}


