#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1A8 - 0x1A8)
// BlueprintGeneratedClass ArsenalPickUpHUD2Component.ArsenalPickUpHUD2Component_C
class UArsenalPickUpHUD2Component_C : public UTTLArsenalPickUpHUD2Component
{
public:

	static class UClass* StaticClass();
	static class UArsenalPickUpHUD2Component_C* GetDefaultObj();

};

}


