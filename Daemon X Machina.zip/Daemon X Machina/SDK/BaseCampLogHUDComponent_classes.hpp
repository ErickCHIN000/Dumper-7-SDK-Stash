#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x110 - 0x110)
// BlueprintGeneratedClass BaseCampLogHUDComponent.BaseCampLogHUDComponent_C
class UBaseCampLogHUDComponent_C : public UTTLBaseCampLogHUDComponent
{
public:

	static class UClass* StaticClass();
	static class UBaseCampLogHUDComponent_C* GetDefaultObj();

};

}


