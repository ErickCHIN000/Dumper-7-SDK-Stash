#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x210 - 0x208)
// WidgetBlueprintGeneratedClass AIDebugTextWidget.AIDebugTextWidget_C
class UAIDebugTextWidget_C : public UUserWidget
{
public:
	class UTextBlock*                            TextObject;                                        // 0x208(0x8)(BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData, RepSkip, NoDestructor, PersistentInstance, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class UAIDebugTextWidget_C* GetDefaultObj();

};

}


