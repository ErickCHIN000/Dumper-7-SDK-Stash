#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x1 (0x1 - 0x0)
// Function ArsenalPickUpPartsHUDComponent.ArsenalPickUpPartsHUDComponent_C.TTLCanBeginPlay
struct UArsenalPickUpPartsHUDComponent_C_TTLCanBeginPlay_Params
{
public:
	bool                                         CanBegin;                                          // 0x0(0x1)(Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// 0x4 (0x4 - 0x0)
// Function ArsenalPickUpPartsHUDComponent.ArsenalPickUpPartsHUDComponent_C.ExecuteUbergraph_ArsenalPickUpPartsHUDComponent
struct UArsenalPickUpPartsHUDComponent_C_ExecuteUbergraph_ArsenalPickUpPartsHUDComponent_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


