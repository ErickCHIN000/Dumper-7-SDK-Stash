#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x19 (0x19 - 0x0)
// Function ArsenalItemMarkerHUDComponent.ArsenalItemMarkerHUDComponent_C.GetHUDWidgetDescriptionInAnim
struct UArsenalItemMarkerHUDComponent_C_GetHUDWidgetDescriptionInAnim_Params
{
public:
	class UUserWidget*                           HUD;                                               // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                      ReturnValue;                                       // 0x8(0x8)(Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UMsn_fielditem_top00_C*                K2Node_DynamicCast_AsMsn_Fielditem_Top_00;         // 0x10(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess;                       // 0x18(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
};

// 0x19 (0x19 - 0x0)
// Function ArsenalItemMarkerHUDComponent.ArsenalItemMarkerHUDComponent_C.GetHUDWidgetNoAccessAnim
struct UArsenalItemMarkerHUDComponent_C_GetHUDWidgetNoAccessAnim_Params
{
public:
	class UUserWidget*                           HUD;                                               // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                      ReturnValue;                                       // 0x8(0x8)(Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UMsn_fielditem_top00_C*                K2Node_DynamicCast_AsMsn_Fielditem_Top_00;         // 0x10(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess;                       // 0x18(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
};

// 0x19 (0x19 - 0x0)
// Function ArsenalItemMarkerHUDComponent.ArsenalItemMarkerHUDComponent_C.GetHUDWidgetAccessAnim
struct UArsenalItemMarkerHUDComponent_C_GetHUDWidgetAccessAnim_Params
{
public:
	class UUserWidget*                           HUD;                                               // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UWidgetAnimation*                      ReturnValue;                                       // 0x8(0x8)(Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UMsn_fielditem_top00_C*                K2Node_DynamicCast_AsMsn_Fielditem_Top_00;         // 0x10(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess;                       // 0x18(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
};

// 0x8 (0x8 - 0x0)
// Function ArsenalItemMarkerHUDComponent.ArsenalItemMarkerHUDComponent_C.PlayStartAnimation
struct UArsenalItemMarkerHUDComponent_C_PlayStartAnimation_Params
{
public:
	class UUserWidget*                           HUD;                                               // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x4 (0x4 - 0x0)
// Function ArsenalItemMarkerHUDComponent.ArsenalItemMarkerHUDComponent_C.UpdateHUDBP
struct UArsenalItemMarkerHUDComponent_C_UpdateHUDBP_Params
{
public:
	float                                        DeltaSeconds;                                      // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x8 (0x8 - 0x0)
// Function ArsenalItemMarkerHUDComponent.ArsenalItemMarkerHUDComponent_C.PlayDisableAnimation
struct UArsenalItemMarkerHUDComponent_C_PlayDisableAnimation_Params
{
public:
	class UUserWidget*                           HUD;                                               // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x38 (0x38 - 0x0)
// Function ArsenalItemMarkerHUDComponent.ArsenalItemMarkerHUDComponent_C.ExecuteUbergraph_ArsenalItemMarkerHUDComponent
struct UArsenalItemMarkerHUDComponent_C_ExecuteUbergraph_ArsenalItemMarkerHUDComponent_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_9F[0x4];                                       // Fixing Size After Last Property  [ Dumper-7 ]
	class UUserWidget*                           K2Node_Event_hud;                                  // 0x8(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UUserWidget*                           K2Node_Event_hud1;                                 // 0x10(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UMsn_fielditem_top00_C*                K2Node_DynamicCast_AsMsn_Fielditem_Top_00;         // 0x18(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess;                       // 0x20(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	uint8                                        Pad_A2[0x7];                                       // Fixing Size After Last Property  [ Dumper-7 ]
	class UMsn_fielditem_top00_C*                K2Node_DynamicCast_AsMsn_Fielditem_Top_001;        // 0x28(0x8)(ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_DynamicCast_bSuccess1;                      // 0x30(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                         CallFunc_IsAnimationPlaying_ReturnValue;           // 0x31(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                         CallFunc_IsAnimationPlaying_ReturnValue1;          // 0x32(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	uint8                                        Pad_A8[0x1];                                       // Fixing Size After Last Property  [ Dumper-7 ]
	float                                        K2Node_Event_DeltaSeconds;                         // 0x34(0x4)(ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


