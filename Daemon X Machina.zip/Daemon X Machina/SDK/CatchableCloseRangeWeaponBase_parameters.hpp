#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x2 (0x2 - 0x0)
// Function CatchableCloseRangeWeaponBase.CatchableCloseRangeWeaponBase_C.Equipment_Set
struct ACatchableCloseRangeWeaponBase_C_Equipment_Set_Params
{
public:
	bool                                         Attached;                                          // 0x0(0x1)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                         Temp;                                              // 0x1(0x1)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// 0x6 (0x6 - 0x0)
// Function CatchableCloseRangeWeaponBase.CatchableCloseRangeWeaponBase_C.ExecuteUbergraph_CatchableCloseRangeWeaponBase
struct ACatchableCloseRangeWeaponBase_C_ExecuteUbergraph_CatchableCloseRangeWeaponBase_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         K2Node_Event_attached;                             // 0x4(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
	bool                                         K2Node_Event_temp;                                 // 0x5(0x1)(ZeroConstructor, IsPlainOldData, NoDestructor)
};

}
}


