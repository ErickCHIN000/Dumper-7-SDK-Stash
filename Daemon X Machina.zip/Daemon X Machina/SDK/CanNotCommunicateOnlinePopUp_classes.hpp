#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x500 - 0x500)
// BlueprintGeneratedClass CanNotCommunicateOnlinePopUp.CanNotCommunicateOnlinePopUp_C
class ACanNotCommunicateOnlinePopUp_C : public ACommonPopUp_C
{
public:

	static class UClass* StaticClass();
	static class ACanNotCommunicateOnlinePopUp_C* GetDefaultObj();

};

}


