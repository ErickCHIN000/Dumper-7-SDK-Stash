#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x4F8 - 0x4F0)
// BlueprintGeneratedClass BulletItem.BulletItem_C
class ABulletItem_C : public ATTLFieldBulletItem
{
public:
	class URaderTargetComponent_C*               RaderTargetComponent;                              // 0x4F0(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABulletItem_C* GetDefaultObj();

	void UserConstructionScript();
};

}


