#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xF8 - 0xF8)
// BlueprintGeneratedClass ArsenalAttachedHUD2Component.ArsenalAttachedHUD2Component_C
class UArsenalAttachedHUD2Component_C : public UTTLActorComponent
{
public:

	static class UClass* StaticClass();
	static class UArsenalAttachedHUD2Component_C* GetDefaultObj();

	void ChangeMode(bool IsArsenalMode);
};

}


