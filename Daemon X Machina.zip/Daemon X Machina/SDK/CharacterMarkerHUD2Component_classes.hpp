#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xF8 - 0xF8)
// BlueprintGeneratedClass CharacterMarkerHUD2Component.CharacterMarkerHUD2Component_C
class UCharacterMarkerHUD2Component_C : public UTTLCharacterMarkerHUD2Component
{
public:

	static class UClass* StaticClass();
	static class UCharacterMarkerHUD2Component_C* GetDefaultObj();

};

}


