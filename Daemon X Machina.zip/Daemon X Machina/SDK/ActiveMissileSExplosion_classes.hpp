#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x620 - 0x620)
// BlueprintGeneratedClass ActiveMissileSExplosion.ActiveMissileSExplosion_C
class AActiveMissileSExplosion_C : public ATTLExplosionActor
{
public:

	static class UClass* StaticClass();
	static class AActiveMissileSExplosion_C* GetDefaultObj();

};

}


