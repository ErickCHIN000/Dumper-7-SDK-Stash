#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x340 - 0x340)
// BlueprintGeneratedClass DecalBulletM.DecalBulletM_C
class ADecalBulletM_C : public ATTLDecalActor
{
public:

	static class UClass* StaticClass();
	static class ADecalBulletM_C* GetDefaultObj();

};

}


