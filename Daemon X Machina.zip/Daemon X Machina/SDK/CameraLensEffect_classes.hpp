#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x3E0 - 0x3E0)
// BlueprintGeneratedClass CameraLensEffect.CameraLensEffect_C
class ACameraLensEffect_C : public AEmitterCameraLensEffectBase
{
public:

	static class UClass* StaticClass();
	static class ACameraLensEffect_C* GetDefaultObj();

};

}


