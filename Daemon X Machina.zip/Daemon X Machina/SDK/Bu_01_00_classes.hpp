#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x3D8 - 0x3D8)
// BlueprintGeneratedClass Bu_01_00.Bu_01_00_C
class ABu_01_00_C : public AGrenadeBullet_C
{
public:

	static class UClass* StaticClass();
	static class ABu_01_00_C* GetDefaultObj();

};

}


