#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1C8 - 0x1C8)
// BlueprintGeneratedClass ChaseAutoRunComponent.ChaseAutoRunComponent_C
class UChaseAutoRunComponent_C : public UTTLChaseAutoRunComponent
{
public:

	static class UClass* StaticClass();
	static class UChaseAutoRunComponent_C* GetDefaultObj();

};

}


