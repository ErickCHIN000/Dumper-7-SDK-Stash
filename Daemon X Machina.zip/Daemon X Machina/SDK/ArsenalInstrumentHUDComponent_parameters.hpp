#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x1 (0x1 - 0x0)
// Function ArsenalInstrumentHUDComponent.ArsenalInstrumentHUDComponent_C.TTLCanBeginPlay
struct UArsenalInstrumentHUDComponent_C_TTLCanBeginPlay_Params
{
public:
	bool                                         CanBegin;                                          // 0x0(0x1)(Parm, OutParm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// 0x4 (0x4 - 0x0)
// Function ArsenalInstrumentHUDComponent.ArsenalInstrumentHUDComponent_C.ExecuteUbergraph_ArsenalInstrumentHUDComponent
struct UArsenalInstrumentHUDComponent_C_ExecuteUbergraph_ArsenalInstrumentHUDComponent_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


