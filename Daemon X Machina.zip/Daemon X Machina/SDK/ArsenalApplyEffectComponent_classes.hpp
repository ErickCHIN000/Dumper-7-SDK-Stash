#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xF8 - 0xF8)
// BlueprintGeneratedClass ArsenalApplyEffectComponent.ArsenalApplyEffectComponent_C
class UArsenalApplyEffectComponent_C : public UTTLArsenalApplyEffectComponent
{
public:

	static class UClass* StaticClass();
	static class UArsenalApplyEffectComponent_C* GetDefaultObj();

};

}


