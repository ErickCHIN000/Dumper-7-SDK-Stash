#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x3D8 - 0x3D0)
// BlueprintGeneratedClass CatchAbleWeaponContainer.CatchAbleWeaponContainer_C
class ACatchAbleWeaponContainer_C : public ACatchableActorBase_C
{
public:
	class URaderTargetComponent_C*               RaderTargetComponent;                              // 0x3D0(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ACatchAbleWeaponContainer_C* GetDefaultObj();

	void UserConstructionScript();
};

}


