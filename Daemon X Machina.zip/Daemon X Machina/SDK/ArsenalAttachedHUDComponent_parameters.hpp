#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0x10 - 0x0)
// Function ArsenalAttachedHUDComponent.ArsenalAttachedHUDComponent_C.UpdateChangeWeaponHUD
struct UArsenalAttachedHUDComponent_C_UpdateChangeWeaponHUD_Params
{
public:
	class UUserWidget*                           UI;                                                // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class ABaseCharacter_C*                      OwnerCharacter;                                    // 0x8(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x11 (0x11 - 0x0)
// Function ArsenalAttachedHUDComponent.ArsenalAttachedHUDComponent_C.UpdateReloadHUD
struct UArsenalAttachedHUDComponent_C_UpdateReloadHUD_Params
{
public:
	class UUserWidget*                           UI;                                                // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class ABaseCharacter_C*                      OwnerCharacter;                                    // 0x8(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         IsReload;                                          // 0x10(0x1)(Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// 0x10 (0x10 - 0x0)
// Function ArsenalAttachedHUDComponent.ArsenalAttachedHUDComponent_C.UpdateRightWeaponHUD
struct UArsenalAttachedHUDComponent_C_UpdateRightWeaponHUD_Params
{
public:
	class UUserWidget*                           UI;                                                // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class ABaseCharacter_C*                      OwnerCharacter;                                    // 0x8(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x10 (0x10 - 0x0)
// Function ArsenalAttachedHUDComponent.ArsenalAttachedHUDComponent_C.UpdateLeftWeaponHUD
struct UArsenalAttachedHUDComponent_C_UpdateLeftWeaponHUD_Params
{
public:
	class UUserWidget*                           UI;                                                // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class ABaseCharacter_C*                      OwnerCharacter;                                    // 0x8(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x10 (0x10 - 0x0)
// Function ArsenalAttachedHUDComponent.ArsenalAttachedHUDComponent_C.UpdateFemtoHUD
struct UArsenalAttachedHUDComponent_C_UpdateFemtoHUD_Params
{
public:
	class UUserWidget*                           UI;                                                // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class ABaseCharacter_C*                      OwnerCharacter;                                    // 0x8(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x10 (0x10 - 0x0)
// Function ArsenalAttachedHUDComponent.ArsenalAttachedHUDComponent_C.UpdateTMPHUD
struct UArsenalAttachedHUDComponent_C_UpdateTMPHUD_Params
{
public:
	class UUserWidget*                           UI;                                                // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class ABaseCharacter_C*                      OwnerCharacter;                                    // 0x8(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// 0x10 (0x10 - 0x0)
// Function ArsenalAttachedHUDComponent.ArsenalAttachedHUDComponent_C.UpdateHPHUD
struct UArsenalAttachedHUDComponent_C_UpdateHPHUD_Params
{
public:
	class UUserWidget*                           UI;                                                // 0x0(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class ABaseCharacter_C*                      OwnerCharacter;                                    // 0x8(0x8)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


