#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xB28 - 0xB28)
// BlueprintGeneratedClass Bu_00_03.Bu_00_03_C
class ABu_00_03_C : public AShoulderCannonBullet_C
{
public:

	static class UClass* StaticClass();
	static class ABu_00_03_C* GetDefaultObj();

};

}


