#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x3C8 - 0x3C0)
// BlueprintGeneratedClass ArsenalEquipHUD2.ArsenalEquipHUD2_C
class AArsenalEquipHUD2_C : public ATTLArsenalEquipHUD2
{
public:
	class USceneComponent*                       DefaultSceneRoot;                                  // 0x3C0(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class AArsenalEquipHUD2_C* GetDefaultObj();

};

}


