#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xEC0 - 0xEC0)
// BlueprintGeneratedClass AssultRifle.AssultRifle_C
class AAssultRifle_C : public ALongRangeWeaponCommon_C
{
public:

	static class UClass* StaticClass();
	static class AAssultRifle_C* GetDefaultObj();

	void UserConstructionScript();
};

}


