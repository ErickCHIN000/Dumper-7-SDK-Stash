#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass BaseButterflyNH_R.BaseButterflyNH_R_C
class UBaseButterflyNH_R_C : public USexyVariantSexScene
{
public:

	static class UClass* StaticClass();
	static class UBaseButterflyNH_R_C* GetDefaultObj();

};

}


