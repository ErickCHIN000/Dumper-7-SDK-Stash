#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass AyrshireMilkNN_G.AyrshireMilkNN_G_C
class UAyrshireMilkNN_G_C : public UBaseMilkNN_G_C
{
public:

	static class UClass* StaticClass();
	static class UAyrshireMilkNN_G_C* GetDefaultObj();

};

}


