#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x50 - 0x50)
// BlueprintGeneratedClass AmberMaeSuckJugs_RL.AmberMaeSuckJugs_RL_C
class UAmberMaeSuckJugs_RL_C : public USexyDialogueResponse
{
public:

	static class UClass* StaticClass();
	static class UAmberMaeSuckJugs_RL_C* GetDefaultObj();

};

}


