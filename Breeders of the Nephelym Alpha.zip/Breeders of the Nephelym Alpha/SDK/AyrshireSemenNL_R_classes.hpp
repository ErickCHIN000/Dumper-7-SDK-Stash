#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass AyrshireSemenNL_R.AyrshireSemenNL_R_C
class UAyrshireSemenNL_R_C : public UBaseSemenNL_R_C
{
public:

	static class UClass* StaticClass();
	static class UAyrshireSemenNL_R_C* GetDefaultObj();

};

}


