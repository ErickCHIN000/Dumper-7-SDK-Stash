#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass AyrshireSemenNS_R.AyrshireSemenNS_R_C
class UAyrshireSemenNS_R_C : public UBaseSemenNS_R_C
{
public:

	static class UClass* StaticClass();
	static class UAyrshireSemenNS_R_C* GetDefaultObj();

};

}


