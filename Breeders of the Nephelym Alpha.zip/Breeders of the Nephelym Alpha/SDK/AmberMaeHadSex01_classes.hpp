#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x170 - 0x170)
// BlueprintGeneratedClass AmberMaeHadSex01.AmberMaeHadSex01_C
class UAmberMaeHadSex01_C : public USexyDialogueSession
{
public:

	static class UClass* StaticClass();
	static class UAmberMaeHadSex01_C* GetDefaultObj();

};

}


