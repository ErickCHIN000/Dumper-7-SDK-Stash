#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xF8 - 0xF8)
// BlueprintGeneratedClass AmberMilky.AmberMilky_C
class UAmberMilky_C : public USexyBreedingMontage
{
public:

	static class UClass* StaticClass();
	static class UAmberMilky_C* GetDefaultObj();

};

}


