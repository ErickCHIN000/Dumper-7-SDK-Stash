#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass AyrshireSemenNH_R.AyrshireSemenNH_R_C
class UAyrshireSemenNH_R_C : public UBaseSemenNH_R_C
{
public:

	static class UClass* StaticClass();
	static class UAyrshireSemenNH_R_C* GetDefaultObj();

};

}


