#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x50 - 0x50)
// BlueprintGeneratedClass AmberMaeDungeon_RL.AmberMaeDungeon_RL_C
class UAmberMaeDungeon_RL_C : public USexyDialogueResponse
{
public:

	static class UClass* StaticClass();
	static class UAmberMaeDungeon_RL_C* GetDefaultObj();

};

}


