#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x3630 - 0x3630)
// BlueprintGeneratedClass Alraune.Alraune_C
class UAlraune_C : public USexyCharacterVariant
{
public:

	static class UClass* StaticClass();
	static class UAlraune_C* GetDefaultObj();

};

}


