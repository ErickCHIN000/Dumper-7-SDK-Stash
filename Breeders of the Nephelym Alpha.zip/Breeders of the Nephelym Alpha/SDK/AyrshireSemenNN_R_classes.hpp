#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass AyrshireSemenNN_R.AyrshireSemenNN_R_C
class UAyrshireSemenNN_R_C : public UBaseSemenNN_R_C
{
public:

	static class UClass* StaticClass();
	static class UAyrshireSemenNN_R_C* GetDefaultObj();

};

}


