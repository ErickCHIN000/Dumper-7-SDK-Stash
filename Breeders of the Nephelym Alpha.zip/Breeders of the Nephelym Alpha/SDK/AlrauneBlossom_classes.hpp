#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x3630 - 0x3630)
// BlueprintGeneratedClass AlrauneBlossom.AlrauneBlossom_C
class UAlrauneBlossom_C : public UAlrauneFern_C
{
public:

	static class UClass* StaticClass();
	static class UAlrauneBlossom_C* GetDefaultObj();

};

}


