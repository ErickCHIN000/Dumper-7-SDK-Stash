#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x170 - 0x170)
// BlueprintGeneratedClass AmberMaeSuckJugs_Start.AmberMaeSuckJugs_Start_C
class UAmberMaeSuckJugs_Start_C : public USexyDialogueSession
{
public:

	static class UClass* StaticClass();
	static class UAmberMaeSuckJugs_Start_C* GetDefaultObj();

};

}


