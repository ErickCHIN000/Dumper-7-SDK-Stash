#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xF8 - 0xF8)
// BlueprintGeneratedClass AmberDailyToy_BreederF.AmberDailyToy_BreederF_C
class UAmberDailyToy_BreederF_C : public USexyBreedingMontage
{
public:

	static class UClass* StaticClass();
	static class UAmberDailyToy_BreederF_C* GetDefaultObj();

};

}


