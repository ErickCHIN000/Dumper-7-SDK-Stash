#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass AyrshireSemenNT_R.AyrshireSemenNT_R_C
class UAyrshireSemenNT_R_C : public UBaseSemenNT_R_C
{
public:

	static class UClass* StaticClass();
	static class UAyrshireSemenNT_R_C* GetDefaultObj();

};

}


