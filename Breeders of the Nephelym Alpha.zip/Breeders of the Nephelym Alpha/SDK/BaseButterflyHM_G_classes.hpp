#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass BaseButterflyHM_G.BaseButterflyHM_G_C
class UBaseButterflyHM_G_C : public USexyVariantSexScene
{
public:

	static class UClass* StaticClass();
	static class UBaseButterflyHM_G_C* GetDefaultObj();

};

}


