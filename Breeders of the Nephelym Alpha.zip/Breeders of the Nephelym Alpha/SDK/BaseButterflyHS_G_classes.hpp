#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass BaseButterflyHS_G.BaseButterflyHS_G_C
class UBaseButterflyHS_G_C : public USexyVariantSexScene
{
public:

	static class UClass* StaticClass();
	static class UBaseButterflyHS_G_C* GetDefaultObj();

};

}


