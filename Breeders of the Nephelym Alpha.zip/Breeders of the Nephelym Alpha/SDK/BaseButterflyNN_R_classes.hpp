#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass BaseButterflyNN_R.BaseButterflyNN_R_C
class UBaseButterflyNN_R_C : public USexyVariantSexScene
{
public:

	static class UClass* StaticClass();
	static class UBaseButterflyNN_R_C* GetDefaultObj();

};

}


