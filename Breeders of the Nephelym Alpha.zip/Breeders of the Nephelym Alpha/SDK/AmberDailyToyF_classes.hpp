#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xF8 - 0xF8)
// BlueprintGeneratedClass AmberDailyToyF.AmberDailyToyF_C
class UAmberDailyToyF_C : public USexyBreedingMontage
{
public:

	static class UClass* StaticClass();
	static class UAmberDailyToyF_C* GetDefaultObj();

};

}


