#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x80 - 0x80)
// BlueprintGeneratedClass AmberMaeDialogue.AmberMaeDialogue_C
class UAmberMaeDialogue_C : public USexyDialogueGroup
{
public:

	static class UClass* StaticClass();
	static class UAmberMaeDialogue_C* GetDefaultObj();

};

}


