#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass BaseButterflyTL_R.BaseButterflyTL_R_C
class UBaseButterflyTL_R_C : public USexyVariantSexScene
{
public:

	static class UClass* StaticClass();
	static class UBaseButterflyTL_R_C* GetDefaultObj();

};

}


