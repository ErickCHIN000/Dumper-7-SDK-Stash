#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x3630 - 0x3630)
// BlueprintGeneratedClass AlrauneFern.AlrauneFern_C
class UAlrauneFern_C : public UAlraune_C
{
public:

	static class UClass* StaticClass();
	static class UAlrauneFern_C* GetDefaultObj();

};

}


