#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xF8 - 0xF8)
// BlueprintGeneratedClass AmberDailyToyT.AmberDailyToyT_C
class UAmberDailyToyT_C : public USexyBreedingMontage
{
public:

	static class UClass* StaticClass();
	static class UAmberDailyToyT_C* GetDefaultObj();

};

}


