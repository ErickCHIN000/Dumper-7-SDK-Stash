#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xF8 - 0xF8)
// BlueprintGeneratedClass AmberDailyToy_BreederT.AmberDailyToy_BreederT_C
class UAmberDailyToy_BreederT_C : public USexyBreedingMontage
{
public:

	static class UClass* StaticClass();
	static class UAmberDailyToy_BreederT_C* GetDefaultObj();

};

}


