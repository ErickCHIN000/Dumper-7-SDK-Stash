#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x610 - 0x610)
// BlueprintGeneratedClass AyrshireSemenNM_R.AyrshireSemenNM_R_C
class UAyrshireSemenNM_R_C : public UBaseSemenNM_R_C
{
public:

	static class UClass* StaticClass();
	static class UAyrshireSemenNM_R_C* GetDefaultObj();

};

}


