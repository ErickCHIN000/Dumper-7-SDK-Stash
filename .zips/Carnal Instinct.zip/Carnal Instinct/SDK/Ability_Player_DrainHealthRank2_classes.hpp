#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x348 - 0x348)
// BlueprintGeneratedClass Ability_Player_DrainHealthRank2.Ability_Player_DrainHealthRank2_C
class AAbility_Player_DrainHealthRank2_C : public AAbility_Player_DrainHealth_C
{
public:

	static class UClass* StaticClass();
	static class AAbility_Player_DrainHealthRank2_C* GetDefaultObj();

};

}


