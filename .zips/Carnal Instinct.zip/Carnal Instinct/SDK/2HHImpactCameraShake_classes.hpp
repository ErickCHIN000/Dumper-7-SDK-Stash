#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x180 - 0x180)
// BlueprintGeneratedClass 2HHImpactCameraShake.2HHImpactCameraShake_C
class UTwoHHImpactCameraShake_C : public UMatineeCameraShake
{
public:

	static class UClass* StaticClass();
	static class UTwoHHImpactCameraShake_C* GetDefaultObj();

};

}


