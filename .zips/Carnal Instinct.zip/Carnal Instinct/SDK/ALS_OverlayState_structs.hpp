#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------

enum class EALS_OverlayState : uint8
{
	NewEnumerator0                 = 0,
	NewEnumerator12                = 1,
	NewEnumerator13                = 2,
	NewEnumerator14                = 3,
	NewEnumerator15                = 4,
	NewEnumerator1                 = 5,
	NewEnumerator5                 = 6,
	NewEnumerator10                = 7,
	NewEnumerator6                 = 8,
	NewEnumerator7                 = 9,
	NewEnumerator8                 = 10,
	NewEnumerator9                 = 11,
	NewEnumerator11                = 12,
	ALS_MAX                        = 13,
};


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

}


