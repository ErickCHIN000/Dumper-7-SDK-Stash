#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x2084 (0x233C - 0x2B8)
// AnimBlueprintGeneratedClass ALS_PlayerCameraBehavior.ALS_PlayerCameraBehavior_C
class UALS_PlayerCameraBehavior_C : public UAnimInstance
{
public:
	uint8                                        Pad_1099[0x8];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FPointerToUberGraphFrame              UberGraphFrame;                                    // 0x2C0(0x8)(ZeroConstructor, Transient, DuplicateTransient)
	struct FAnimNode_Root                        AnimGraphNode_Root;                                // 0x2C8(0x30)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_11;                  // 0x2F8(0xB0)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_1;                   // 0x3A8(0xA0)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_4;                    // 0x448(0x158)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_35;                      // 0x5A0(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_34;                      // 0x5F8(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_33;                      // 0x650(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_32;                      // 0x6A8(0x58)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_10;                  // 0x700(0xB0)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_3;                    // 0x7B0(0x158)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_10;                    // 0x908(0x28)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_31;                      // 0x930(0x58)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_9;                     // 0x988(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_2;                  // 0x9B0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_1;                  // 0x9D8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult;                    // 0xA00(0x28)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_30;                      // 0xA28(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_29;                      // 0xA80(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_28;                      // 0xAD8(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_27;                      // 0xB30(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_26;                      // 0xB88(0x58)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_9;                   // 0xBE0(0xB0)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_25;                      // 0xC90(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_24;                      // 0xCE8(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_23;                      // 0xD40(0x58)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_8;                   // 0xD98(0xB0)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_7;                   // 0xE48(0xB0)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_22;                      // 0xEF8(0x58)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_2;                       // 0xF50(0x30)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_21;                      // 0xF80(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_20;                      // 0xFD8(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_19;                      // 0x1030(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_18;                      // 0x1088(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_17;                      // 0x10E0(0x58)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_6;                   // 0x1138(0xB0)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_16;                      // 0x11E8(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_15;                      // 0x1240(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_14;                      // 0x1298(0x58)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_5;                   // 0x12F0(0xB0)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_4;                   // 0x13A0(0xB0)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_13;                      // 0x1450(0x58)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_1;                       // 0x14A8(0x30)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_12;                      // 0x14D8(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_11;                      // 0x1530(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_10;                      // 0x1588(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_9;                       // 0x15E0(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_8;                       // 0x1638(0x58)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_3;                   // 0x1690(0xB0)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_7;                       // 0x1740(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_6;                       // 0x1798(0x58)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_5;                       // 0x17F0(0x58)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_2;                   // 0x1848(0xB0)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum_1;                   // 0x18F8(0xB0)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_4;                       // 0x19A8(0x58)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult;                         // 0x1A00(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine;                        // 0x1A30(0xB0)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_2;                    // 0x1AE0(0x158)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_3;                       // 0x1C38(0x58)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_8;                     // 0x1C90(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_7;                     // 0x1CB8(0x28)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_1;                    // 0x1CE0(0x158)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_6;                     // 0x1E38(0x28)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_2;                       // 0x1E60(0x58)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_5;                     // 0x1EB8(0x28)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve_1;                       // 0x1EE0(0x58)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool;                     // 0x1F38(0xA0)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_4;                     // 0x1FD8(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_3;                     // 0x2000(0x28)(None)
	struct FAnimNode_BlendListByEnum             AnimGraphNode_BlendListByEnum;                     // 0x2028(0xB0)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_2;                     // 0x20D8(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_1;                     // 0x2100(0x28)(None)
	struct FAnimNode_ModifyCurve                 AnimGraphNode_ModifyCurve;                         // 0x2128(0x58)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose;                      // 0x2180(0x158)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose;                       // 0x22D8(0x28)(None)
	class APlayerController*                     PlayerController;                                  // 0x2300(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class APawn*                                 ControlledPawn;                                    // 0x2308(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	enum class EALS_MovementState                MovementState;                                     // 0x2310(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	enum class EALS_MovementAction               MovementAction;                                    // 0x2311(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	enum class EALS_RotationMode                 RotationMode;                                      // 0x2312(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	enum class EALS_Gait                         Gait;                                              // 0x2313(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	enum class EALS_Stance                       Stance;                                            // 0x2314(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	enum class EALS_ViewMode                     ViewMode;                                          // 0x2315(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         RightShoulder;                                     // 0x2316(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         DebugView;                                         // 0x2317(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	float                                        CombatX;                                           // 0x2318(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        AimingOffsetX;                                     // 0x231C(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        AimingOffsetY;                                     // 0x2320(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        AimingOffsetZ;                                     // 0x2324(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        CameraX;                                           // 0x2328(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        CameraY;                                           // 0x232C(0x4)(Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        CameraZ;                                           // 0x2330(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        SprintCameraX;                                     // 0x2334(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        SprintCameraZ;                                     // 0x2338(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class UALS_PlayerCameraBehavior_C* GetDefaultObj();

	void AnimGraph(struct FPoseLink* AnimGraph);
	void UpdateCharacterInfo(bool CallFunc_IsValid_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, TScriptInterface<class IALS_Character_BPI_C> K2Node_DynamicCast_AsALS_Character_BPI, bool K2Node_DynamicCast_bSuccess, TScriptInterface<class IALS_Controller_BPI_C> K2Node_DynamicCast_AsALS_Controller_BPI, bool K2Node_DynamicCast_bSuccess_1, enum class EMovementMode CallFunc_BPI_Get_CurrentStates_PawnMovementMode, enum class EALS_MovementState CallFunc_BPI_Get_CurrentStates_MovementState, enum class EALS_MovementState CallFunc_BPI_Get_CurrentStates_PrevMovementState, enum class EALS_MovementAction CallFunc_BPI_Get_CurrentStates_MovementAction, enum class EALS_RotationMode CallFunc_BPI_Get_CurrentStates_RotationMode, enum class EALS_Gait CallFunc_BPI_Get_CurrentStates_ActualGait, enum class EALS_Stance CallFunc_BPI_Get_CurrentStates_ActualStance, enum class EALS_ViewMode CallFunc_BPI_Get_CurrentStates_ViewMode, enum class EALS_OverlayState CallFunc_BPI_Get_CurrentStates_OverlayState, class ACharacter* CallFunc_BPI_Get_DebugInfo_DebugFocusCharacter, bool CallFunc_BPI_Get_DebugInfo_DebugView, bool CallFunc_BPI_Get_DebugInfo_ShowHUD, bool CallFunc_BPI_Get_DebugInfo_ShowTraces, bool CallFunc_BPI_Get_DebugInfo_ShowDebugShapes, bool CallFunc_BPI_Get_DebugInfo_ShowLayerColors, bool CallFunc_BPI_Get_DebugInfo_Slomo, bool CallFunc_BPI_Get_DebugInfo_ShowCharacterInfo, bool CallFunc_IsValid_ReturnValue_2, TScriptInterface<class IALS_Camera_BPI_C> K2Node_DynamicCast_AsALS_Camera_BPI, bool K2Node_DynamicCast_bSuccess_2, float CallFunc_BPI_Get_CameraParameters_TP_FOV, float CallFunc_BPI_Get_CameraParameters_FP_FOV, bool CallFunc_BPI_Get_CameraParameters_RightShoulder);
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_ModifyCurve_38C2CC2441B7E054743A14AB880FE7C4();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_ModifyCurve_217B04474D0413D948288DAAD61B3502();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_ModifyCurve_440683FE407F1F8A79B7EBA57AC52916();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_ModifyCurve_604284824796763ACBDA5B84202DEDFA();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_ModifyCurve_3EA4CE9D45EE798D7BF11496CAE91FDC();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_TransitionResult_0D30AFC6461B5834DDD33588DB08FD2B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_TransitionResult_12E957984E9E8E18C540A197CA5611D7();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ALS_PlayerCameraBehavior_AnimGraphNode_TransitionResult_C201AD03413A706ECFD533B5BE53C5AD();
	void BlueprintUpdateAnimation(float DeltaTimeX);
	void ExecuteUbergraph_ALS_PlayerCameraBehavior(int32 EntryPoint, bool CallFunc_EqualEqual_ByteByte_ReturnValue, bool CallFunc_EqualEqual_ByteByte_ReturnValue_1, bool CallFunc_EqualEqual_ByteByte_ReturnValue_2, float CallFunc_Add_FloatFloat_ReturnValue, float CallFunc_Add_FloatFloat_ReturnValue_1, float CallFunc_Add_FloatFloat_ReturnValue_2, float K2Node_Event_DeltaTimeX);
};

}


