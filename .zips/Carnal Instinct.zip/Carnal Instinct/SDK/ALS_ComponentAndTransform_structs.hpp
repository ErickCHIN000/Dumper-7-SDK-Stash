#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x38 (0x38 - 0x0)
// UserDefinedStruct ALS_ComponentAndTransform.ALS_ComponentAndTransform
struct FALS_ComponentAndTransform
{
public:
	struct FTransform                            Transform_8_5A922B8141278287C6E895A0DBC17B89;      // 0x0(0x30)(Edit, BlueprintVisible, IsPlainOldData, NoDestructor)
	class UPrimitiveComponent*                   Component_11_74DA46FC4578E87978977783DBA2F302;     // 0x30(0x8)(Edit, BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}


