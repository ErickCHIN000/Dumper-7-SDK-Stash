#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x320 - 0x320)
// BlueprintGeneratedClass Ability_Player_HealthBuff.Ability_Player_HealthBuff_C
class AAbility_Player_HealthBuff_C : public AAbility_Player_BaseBuff_C
{
public:

	static class UClass* StaticClass();
	static class AAbility_Player_HealthBuff_C* GetDefaultObj();

};

}


