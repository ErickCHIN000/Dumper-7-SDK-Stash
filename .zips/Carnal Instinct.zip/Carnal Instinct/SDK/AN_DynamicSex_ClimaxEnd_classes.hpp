#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x38 - 0x38)
// BlueprintGeneratedClass AN_DynamicSex_ClimaxEnd.AN_DynamicSex_ClimaxEnd_C
class UAN_DynamicSex_ClimaxEnd_C : public UAnimNotify
{
public:

	static class UClass* StaticClass();
	static class UAN_DynamicSex_ClimaxEnd_C* GetDefaultObj();

	bool Received_Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation, class ABP_DynamicSex_Base_C* CallFunc_GetActorOfClass_ReturnValue, class UAnimInstance* CallFunc_GetAnimInstance_ReturnValue, bool CallFunc_IsValid_ReturnValue, class AActor* CallFunc_GetOwner_ReturnValue, bool CallFunc_IsValid_ReturnValue_1);
};

}


