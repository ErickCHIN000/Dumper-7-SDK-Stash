#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x310 - 0x310)
// BlueprintGeneratedClass Ability_Player_InfernoRank3.Ability_Player_InfernoRank3_C
class AAbility_Player_InfernoRank3_C : public AAbility_Player_Inferno_C
{
public:

	static class UClass* StaticClass();
	static class AAbility_Player_InfernoRank3_C* GetDefaultObj();

};

}


