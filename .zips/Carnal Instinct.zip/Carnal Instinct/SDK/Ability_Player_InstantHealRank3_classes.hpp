#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x310 - 0x310)
// BlueprintGeneratedClass Ability_Player_InstantHealRank3.Ability_Player_InstantHealRank3_C
class AAbility_Player_InstantHealRank3_C : public AAbility_Player_InstantHeal_C
{
public:

	static class UClass* StaticClass();
	static class AAbility_Player_InstantHealRank3_C* GetDefaultObj();

};

}


