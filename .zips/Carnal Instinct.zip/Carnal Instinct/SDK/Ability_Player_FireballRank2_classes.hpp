#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x2FC - 0x2FC)
// BlueprintGeneratedClass Ability_Player_FireballRank2.Ability_Player_FireballRank2_C
class AAbility_Player_FireballRank2_C : public AAbility_Player_Fireball_C
{
public:

	static class UClass* StaticClass();
	static class AAbility_Player_FireballRank2_C* GetDefaultObj();

};

}


