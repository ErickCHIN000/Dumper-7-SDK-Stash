#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x328 - 0x328)
// BlueprintGeneratedClass Ability_Player_LightingSparksRank2.Ability_Player_LightingSparksRank2_C
class AAbility_Player_LightingSparksRank2_C : public AAbility_Player_LightingSparks_C
{
public:

	static class UClass* StaticClass();
	static class AAbility_Player_LightingSparksRank2_C* GetDefaultObj();

};

}


