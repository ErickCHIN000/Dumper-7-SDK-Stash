#pragma once

// Definitions for missing Properties

class FMulticastInlineDelegateProperty_
{
	unsigned __int8 Pad[0x10];
};

class FMulticastSparseDelegateProperty_
{
	unsigned __int8 Pad[0x1];
};

class FDelegateProperty_
{
	unsigned __int8 Pad[0x10];
};

class FFieldPathProperty_
{
	unsigned __int8 Pad[0x20];
};

