#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x4B9 - 0x4B9)
// BlueprintGeneratedClass ba_aa_HeavyArmor_00.ba_aa_HeavyArmor_00_C
class Aba_aa_HeavyArmor_00_C : public Aba_aa_Armor_Template_C
{
public:

	static class UClass* StaticClass();
	static class Aba_aa_HeavyArmor_00_C* GetDefaultObj();

};

}


