#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x48 - 0x48)
// BlueprintGeneratedClass an_AkAudioNotify_Fall_Soldier_01.an_AkAudioNotify_Fall_Soldier_01_C
class UAn_AkAudioNotify_Fall_Soldier_01_C : public UAn_AkAudioNotify_Footstep_Base_C
{
public:

	static class UClass* StaticClass();
	static class UAn_AkAudioNotify_Fall_Soldier_01_C* GetDefaultObj();

};

}


