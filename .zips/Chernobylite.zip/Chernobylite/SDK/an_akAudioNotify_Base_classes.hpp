#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x40 - 0x38)
// BlueprintGeneratedClass an_akAudioNotify_Base.an_akAudioNotify_Base_C
class UAn_akAudioNotify_Base_C : public UAnimNotify
{
public:
	class AActor*                                OwnerActor;                                        // 0x38(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, IsPlainOldData, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class UAn_akAudioNotify_Base_C* GetDefaultObj();

};

}


