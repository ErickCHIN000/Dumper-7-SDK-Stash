#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x4C5 - 0x4C5)
// BlueprintGeneratedClass ba_aa_Alcohol_00.ba_aa_Alcohol_00_C
class Aba_aa_Alcohol_00_C : public Aba_aa_HealingTemplate_C
{
public:

	static class UClass* StaticClass();
	static class Aba_aa_Alcohol_00_C* GetDefaultObj();

};

}


