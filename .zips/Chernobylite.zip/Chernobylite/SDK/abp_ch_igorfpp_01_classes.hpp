#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x5019 (0x52D1 - 0x2B8)
// AnimBlueprintGeneratedClass abp_ch_igorfpp_01.abp_ch_igorfpp_01_C
class UAbp_ch_igorfpp_01_C : public UAnimInstance
{
public:
	uint8                                        Pad_29F5[0x8];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FPointerToUberGraphFrame              UberGraphFrame;                                    // 0x2C0(0x8)(ZeroConstructor, Transient, DuplicateTransient, UObjectWrapper)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;             // 0x2C8(0x20)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_6;                  // 0x2E8(0xC0)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_12;                             // 0x3A8(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_17;                    // 0x3F0(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_16;                    // 0x418(0x28)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_2;                   // 0x440(0xA0)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_11;                             // 0x4E0(0x48)(None)
	struct FAnimNode_ApplyMeshSpaceAdditive      AnimGraphNode_ApplyMeshSpaceAdditive_3;            // 0x528(0xD0)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_63;                 // 0x5F8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_62;                 // 0x620(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_61;                 // 0x648(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_60;                 // 0x670(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_59;                 // 0x698(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_58;                 // 0x6C0(0x28)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_24;                   // 0x6E8(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_36;                      // 0x768(0x30)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_57;                 // 0x798(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_56;                 // 0x7C0(0x28)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_6;                  // 0x7E8(0xE8)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_35;                      // 0x8D0(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_23;                   // 0x900(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_34;                      // 0x980(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine_8;                      // 0x9B0(0xB0)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_33;                      // 0xA60(0x30)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_55;                 // 0xA90(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_54;                 // 0xAB8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_53;                 // 0xAE0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_52;                 // 0xB08(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_51;                 // 0xB30(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_50;                 // 0xB58(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_49;                 // 0xB80(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_48;                 // 0xBA8(0x28)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_22;                   // 0xBD0(0x80)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool_1;                   // 0xC50(0xA0)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_5;                  // 0xCF0(0xE8)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_32;                      // 0xDD8(0x30)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_4;                  // 0xE08(0xE8)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_31;                      // 0xEF0(0x30)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_3;                  // 0xF20(0xE8)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_30;                      // 0x1008(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_21;                   // 0x1038(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_29;                      // 0x10B8(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine_7;                      // 0x10E8(0xB0)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_28;                      // 0x1198(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine_6;                      // 0x11C8(0xB0)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;             // 0x1278(0x20)(None)
	struct FAnimNode_ApplyMeshSpaceAdditive      AnimGraphNode_ApplyMeshSpaceAdditive_2;            // 0x1298(0xD0)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_47;                 // 0x1368(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_46;                 // 0x1390(0x28)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_2;                  // 0x13B8(0xE8)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_27;                      // 0x14A0(0x30)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer_1;                  // 0x14D0(0xE8)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_26;                      // 0x15B8(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine_5;                      // 0x15E8(0xB0)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_25;                      // 0x1698(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine_4;                      // 0x16C8(0xB0)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_8;                    // 0x1778(0x158)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_10;                             // 0x18D0(0x48)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_9;                              // 0x1918(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_7;                    // 0x1960(0x158)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_15;                    // 0x1AB8(0x28)(None)
	struct FAnimNode_ApplyMeshSpaceAdditive      AnimGraphNode_ApplyMeshSpaceAdditive_1;            // 0x1AE0(0xD0)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_45;                 // 0x1BB0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_44;                 // 0x1BD8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_43;                 // 0x1C00(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_42;                 // 0x1C28(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_41;                 // 0x1C50(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_40;                 // 0x1C78(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_39;                 // 0x1CA0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_38;                 // 0x1CC8(0x28)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_20;                   // 0x1CF0(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_24;                      // 0x1D70(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_19;                   // 0x1DA0(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_23;                      // 0x1E20(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_18;                   // 0x1E50(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_22;                      // 0x1ED0(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_17;                   // 0x1F00(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_21;                      // 0x1F80(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine_3;                      // 0x1FB0(0xB0)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_2;                        // 0x2060(0x108)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;             // 0x2168(0x20)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;             // 0x2188(0x20)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_14;                    // 0x21A8(0x28)(None)
	struct FAnimNode_Fabrik                      AnimGraphNode_Fabrik;                              // 0x21D0(0x190)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_1;             // 0x2360(0x20)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_8;                              // 0x2380(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_6;                    // 0x23C8(0x158)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_5;                  // 0x2520(0xC0)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_13;                    // 0x25E0(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_12;                    // 0x2608(0x28)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_1;             // 0x2630(0x20)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_11;                    // 0x2650(0x28)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_7;                              // 0x2678(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_5;                    // 0x26C0(0x158)(None)
	struct FAnimNode_Root                        AnimGraphNode_Root;                                // 0x2818(0x30)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_6;                              // 0x2848(0x48)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_5;                              // 0x2890(0x48)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_4;                              // 0x28D8(0x48)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_4;                    // 0x2920(0x158)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_10;                    // 0x2A78(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_9;                     // 0x2AA0(0x28)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_4;                  // 0x2AC8(0xC0)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_3;                    // 0x2B88(0x158)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_8;                     // 0x2CE0(0x28)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_3;                  // 0x2D08(0xC0)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_3;                              // 0x2DC8(0x48)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_7;                     // 0x2E10(0x28)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone_1;                        // 0x2E38(0x108)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_2;                  // 0x2F40(0xC0)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_37;                 // 0x3000(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_36;                 // 0x3028(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_35;                 // 0x3050(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_34;                 // 0x3078(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_33;                 // 0x30A0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_32;                 // 0x30C8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_31;                 // 0x30F0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_30;                 // 0x3118(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_29;                 // 0x3140(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_28;                 // 0x3168(0x28)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_16;                   // 0x3190(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_20;                      // 0x3210(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_15;                   // 0x3240(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_19;                      // 0x32C0(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_14;                   // 0x32F0(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_18;                      // 0x3370(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_13;                   // 0x33A0(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_17;                      // 0x3420(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_12;                   // 0x3450(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_16;                      // 0x34D0(0x30)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_27;                 // 0x3500(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_26;                 // 0x3528(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_25;                 // 0x3550(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_24;                 // 0x3578(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_23;                 // 0x35A0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_22;                 // 0x35C8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_21;                 // 0x35F0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_20;                 // 0x3618(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_19;                 // 0x3640(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_18;                 // 0x3668(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_17;                 // 0x3690(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_16;                 // 0x36B8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_15;                 // 0x36E0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_14;                 // 0x3708(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_13;                 // 0x3730(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_12;                 // 0x3758(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_11;                 // 0x3780(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_10;                 // 0x37A8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_9;                  // 0x37D0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_8;                  // 0x37F8(0x28)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_11;                   // 0x3820(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_15;                      // 0x38A0(0x30)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_14;                      // 0x38D0(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_10;                   // 0x3900(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_13;                      // 0x3980(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_9;                    // 0x39B0(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_12;                      // 0x3A30(0x30)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_11;                      // 0x3A60(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_8;                    // 0x3A90(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_10;                      // 0x3B10(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_7;                    // 0x3B40(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_9;                       // 0x3BC0(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_6;                    // 0x3BF0(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_8;                       // 0x3C70(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_5;                    // 0x3CA0(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_7;                       // 0x3D20(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_4;                    // 0x3D50(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_6;                       // 0x3DD0(0x30)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_7;                  // 0x3E00(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_6;                  // 0x3E28(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_5;                  // 0x3E50(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_4;                  // 0x3E78(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_3;                  // 0x3EA0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_2;                  // 0x3EC8(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult_1;                  // 0x3EF0(0x28)(None)
	struct FAnimNode_TransitionResult            AnimGraphNode_TransitionResult;                    // 0x3F18(0x28)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_3;                    // 0x3F40(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_5;                       // 0x3FC0(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_2;                    // 0x3FF0(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_4;                       // 0x4070(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer_1;                    // 0x40A0(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_3;                       // 0x4120(0x30)(None)
	struct FAnimNode_SequencePlayer              AnimGraphNode_SequencePlayer;                      // 0x4150(0x80)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_2;                       // 0x41D0(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine_2;                      // 0x4200(0xB0)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult_1;                       // 0x42B0(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine_1;                      // 0x42E0(0xB0)(None)
	struct FAnimNode_StateResult                 AnimGraphNode_StateResult;                         // 0x4390(0x30)(None)
	struct FAnimNode_StateMachine                AnimGraphNode_StateMachine;                        // 0x43C0(0xB0)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_6;                     // 0x4470(0x28)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_2;                    // 0x4498(0x158)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_5;                     // 0x45F0(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_4;                     // 0x4618(0x28)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend_1;                  // 0x4640(0xC0)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_2;                              // 0x4700(0x48)(None)
	struct FAnimNode_ModifyBone                  AnimGraphNode_ModifyBone;                          // 0x4748(0x108)(None)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;               // 0x4850(0x20)(None)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;               // 0x4870(0x20)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot_1;                              // 0x4890(0x48)(None)
	struct FAnimNode_ApplyMeshSpaceAdditive      AnimGraphNode_ApplyMeshSpaceAdditive;              // 0x48D8(0xD0)(None)
	struct FAnimNode_BlendSpacePlayer            AnimGraphNode_BlendSpacePlayer;                    // 0x49A8(0xE8)(None)
	struct FAnimNode_Slot                        AnimGraphNode_Slot;                                // 0x4A90(0x48)(None)
	struct FAnimNode_LayeredBoneBlend            AnimGraphNode_LayeredBoneBlend;                    // 0x4AD8(0xC0)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose_1;                    // 0x4B98(0x158)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_3;                     // 0x4CF0(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_2;                     // 0x4D18(0x28)(None)
	struct FAnimNode_BlendListByBool             AnimGraphNode_BlendListByBool;                     // 0x4D40(0xA0)(None)
	struct FAnimNode_SaveCachedPose              AnimGraphNode_SaveCachedPose;                      // 0x4DE0(0x158)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose_1;                     // 0x4F38(0x28)(None)
	struct FAnimNode_UseCachedPose               AnimGraphNode_UseCachedPose;                       // 0x4F60(0x28)(None)
	class ACh_Hero_00_C*                         OwnerReference;                                    // 0x4F88(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        ForwardInput;                                      // 0x4F90(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        RightInput;                                        // 0x4F94(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        Speed;                                             // 0x4F98(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        TransAimProgressed;                                // 0x4F9C(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        TransNeutralProgressed;                            // 0x4FA0(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        InterceptionMapped;                                // 0x4FA4(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        ReactionScale;                                     // 0x4FA8(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        LeftHandIKAlpha;                                   // 0x4FAC(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        TransitionFraction;                                // 0x4FB0(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        AimZOffset;                                        // 0x4FB4(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        AimZOffsetAlpha;                                   // 0x4FB8(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        ForwardRecoilOffset;                               // 0x4FBC(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	struct FRotator                              RotationRecoilOffset;                              // 0x4FC0(0xC)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	struct FRotator                              OwnerControlRotation;                              // 0x4FCC(0xC)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bIsSprinting;                                      // 0x4FD8(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bIsAiming;                                         // 0x4FD9(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bIsCrouching;                                      // 0x4FDA(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bIsNeutralAiming;                                  // 0x4FDB(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bIsFalling;                                        // 0x4FDC(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bHasRecentlyJumped;                                // 0x4FDD(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bIsReloading;                                      // 0x4FDE(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bIsMelee;                                          // 0x4FDF(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bLeftHandIK;                                       // 0x4FE0(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bRecoilFullHand;                                   // 0x4FE1(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	uint8                                        Pad_2B6B[0xE];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FActiveItemAnimDatabase               AnimData;                                          // 0x4FF0(0x1F0)(Edit, BlueprintVisible, DisableEditOnInstance)
	struct FRotator                              PreviousFrameControlRotation;                      // 0x51E0(0xC)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	struct FRotator                              RotationDelta;                                     // 0x51EC(0xC)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	float                                        MappedPitchDelta;                                  // 0x51F8(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        MappedYawDelta;                                    // 0x51FC(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        MappedMaxSpeed;                                    // 0x5200(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        MovementDirection;                                 // 0x5204(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        InterceptionMappedSmooth;                          // 0x5208(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        PostprocessAlpha;                                  // 0x520C(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        YawDeltaCurve;                                     // 0x5210(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        AverageDelta;                                      // 0x5214(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        MaxAverageDelta;                                   // 0x5218(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        DeltaCurveForTransition;                           // 0x521C(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        FreezeRecoverTimer;                                // 0x5220(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        DeltaTimeX;                                        // 0x5224(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        BreakIdleTimer;                                    // 0x5228(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        BreakIdleChance;                                   // 0x522C(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        PostprocessAlphaCurve;                             // 0x5230(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        LeanRollAlphaSmooth;                               // 0x5234(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	float                                        DashRoll;                                          // 0x5238(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_2BAB[0x4];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	TArray<float>                                YawDeltas;                                         // 0x5240(0x10)(Edit, BlueprintVisible, DisableEditOnInstance)
	struct FTransform                            LeftHandIKTransform;                               // 0x5250(0x30)(Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	class UAnimMontage*                          TransitionFromToWalk;                              // 0x5280(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class UAnimMontage*                          BreakIdle;                                         // 0x5288(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	bool                                         bShouldBeHidden;                                   // 0x5290(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bShouldBeVisible;                                  // 0x5291(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bShouldBeFastHidden;                               // 0x5292(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	uint8                                        Pad_2BBB[0xD];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	struct FTransform                            LeanRollTranform;                                  // 0x52A0(0x30)(Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData, NoDestructor)
	bool                                         bIsClimb;                                          // 0x52D0(0x1)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor)

	static class UClass* StaticClass();
	static class UAbp_ch_igorfpp_01_C* GetDefaultObj();

	void AnimGraph(struct FPoseLink* AnimGraph);
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_8E08C44D40E3005B026793AEC72BC778();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_5785A18D4A231F0C3CF480BB9E3F77C8();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_BlendSpacePlayer_E4F997694E7F5697BC3D60B193161D97();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_LayeredBoneBlend_EE18C0554F98986AB51E5580254DB0D5();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_ModifyBone_DC0EF81D43547AEB219258818EDD391C();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_LayeredBoneBlend_6F7617A044A2E5538FB55AB9FD3C6E61();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_ModifyBone_83818CDD4E1F002AD688189B6C2FB650();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_LayeredBoneBlend_B6A1935341D47EA43154AD9FC93F370E();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_LayeredBoneBlend_F52595D4450048B995E41A9E30264ADF();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_LayeredBoneBlend_92A46CC7408713EE060BD1A9D7F097E7();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_Fabrik_3A09CFD94A632C67D56205913B709F4A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_ModifyBone_217F4BAF4B4D27C44D5E2CBDBCFF6B46();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_ApplyMeshSpaceAdditive_C163355C41D300CA32FA52B185171BA6();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_LayeredBoneBlend_DFF870E243E823AF62F73090B862CB88();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_4FF361A94AC1EDE7A0B3EAAA6F265402();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_62CD575940CDC5A087D3F5A9340F7600();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_SequencePlayer_E4A830374B46B37091A2F8A0C1D417AB();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_DCE612734C9FEC89B86955BAAF1F9CE1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_9B2D21DE4336FD740EFFB68483BF1275();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_7EA881B34796F77815F394963F7DD861();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_36BE6C964C3E5AA735A03C95DEF80330();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_CDBE0AEB4E2B6F8A75354AB56EB578C6();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_FE7A707041F138697B5BDDBAB22BC48F();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_F655EE3C4C8C7729EC4BF896CFF10160();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_SequencePlayer_3B6572964D03556C99186AA7CB251FA7();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_SequencePlayer_FF14618B4BB18D23AF550092A53A7D8E();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_5072DD4F4E8B072FC28335ABA9A7CCD6();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_9A4334414E961EDEC6F810B25F63996B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_E2DE34714F2E00568FA796BE87BFD42A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_5046FF904563C18CCA1C7CB164F678A4();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_32B78E474DB8C938BDFCD499361E9041();
	void BlueprintUpdateAnimation(float DeltaTimeX);
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_2015D57143B50F69DC84F0B24D2AAAD1();
	void AnimNotify_IdleToWalk();
	void AnimNotify_WalkToIdle();
	void AnimNotify_ReleaseJumped();
	void AnimNotify_FromToAim();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_0CD515B54EC029A7D872F2A0CEE6128E();
	void AnimNotify_ToAimFinished();
	void AnimNotify_ToVisibleFinish();
	void AnimNotify_ToHiddenFinish();
	void AnimNotify_ClimbHide();
	void AnimNotify_ClimbShow();
	void AnimNotify_ClimbStart();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_BD36F13B4A1F845A14FE66B73729963D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_023DA7894D87FA5B5B54838DB940FB6F();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_BlendSpacePlayer_6666E0C749E091D9B05DC4A8F6AC6649();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_BlendListByBool_BD9185C540CC8F1CDF2799A5FA29FBA1();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_BlendSpacePlayer_20894BF142C9D80D9656E988D7F9FE24();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_ED5FA47944BA204D82A0FF96261F4E6F();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_abp_ch_igorfpp_01_AnimGraphNode_TransitionResult_E364B99945851AFE3396118B5E2E864D();
	void ExecuteUbergraph_abp_ch_igorfpp_01(int32 EntryPoint, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_1, bool CallFunc_NearlyEqual_FloatFloat_ReturnValue, bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_1, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_2, bool CallFunc_Less_FloatFloat_ReturnValue, bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_2, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_3, bool CallFunc_Greater_FloatFloat_ReturnValue, bool CallFunc_Less_FloatFloat_ReturnValue_1, bool Temp_bool_Variable, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_4, bool CallFunc_Less_FloatFloat_ReturnValue_2, float CallFunc_GetAverageDelta_ReturnValue, float CallFunc_Abs_ReturnValue, float CallFunc_SignOfFloat_ReturnValue, bool CallFunc_Greater_FloatFloat_ReturnValue_1, bool CallFunc_Greater_FloatFloat_ReturnValue_2, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_5, bool CallFunc_BooleanAND_ReturnValue, bool CallFunc_Less_FloatFloat_ReturnValue_3, float CallFunc_FClamp_ReturnValue, float CallFunc_FClamp_ReturnValue_1, bool Temp_bool_Variable_1, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_6, float Temp_float_Variable, bool CallFunc_Less_FloatFloat_ReturnValue_4, float Temp_float_Variable_1, bool Temp_bool_Variable_2, bool Temp_bool_Variable_3, float Temp_float_Variable_2, bool CallFunc_IsValid_ReturnValue, float Temp_float_Variable_3, bool Temp_bool_Variable_4, bool CallFunc_Greater_FloatFloat_ReturnValue_3, bool Temp_bool_Variable_5, class UAnimSequence* Temp_object_Variable, bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_3, float Temp_float_Variable_4, bool CallFunc_BooleanOR_ReturnValue, bool CallFunc_Greater_FloatFloat_ReturnValue_4, bool CallFunc_Not_PreBool_ReturnValue, float Temp_float_Variable_5, bool CallFunc_BooleanAND_ReturnValue_1, bool Temp_bool_Variable_6, float CallFunc_Add_FloatFloat_ReturnValue, float CallFunc_Subtract_FloatFloat_ReturnValue, bool CallFunc_IsValid_ReturnValue_1, float CallFunc_MapRangeClamped_ReturnValue, float CallFunc_MapRangeClamped_ReturnValue_1, float CallFunc_FClamp_ReturnValue_2, float CallFunc_FClamp_ReturnValue_3, float CallFunc_FClamp_ReturnValue_4, float CallFunc_Subtract_FloatFloat_ReturnValue_1, float Temp_float_Variable_6, bool Temp_bool_Variable_7, float Temp_float_Variable_7, bool Temp_bool_Variable_8, const struct FVector& CallFunc_MakeVector_ReturnValue, float Temp_float_Variable_8, bool Temp_bool_Variable_9, float CallFunc_Multiply_FloatFloat_ReturnValue, float CallFunc_SelectFloat_ReturnValue, float CallFunc_Multiply_FloatFloat_ReturnValue_1, const struct FTransform& CallFunc_MakeTransform_ReturnValue, float CallFunc_SelectFloat_ReturnValue_1, float CallFunc_Abs_ReturnValue_1, bool Temp_bool_Variable_10, class UAnimSequenceBase* K2Node_Select_Default, float K2Node_Select_Default_1, float K2Node_Select_Default_2, float CallFunc_Multiply_FloatFloat_ReturnValue_2, float CallFunc_FMin_ReturnValue, const struct FVector& CallFunc_MakeVector_ReturnValue_1, float K2Node_Select_Default_3, float CallFunc_Multiply_FloatFloat_ReturnValue_3, bool Temp_bool_Variable_11, float CallFunc_SelectFloat_ReturnValue_2, class UAnimSequence* K2Node_Select_Default_4, const struct FVector& CallFunc_BreakTransform_Location, const struct FRotator& CallFunc_BreakTransform_Rotation, const struct FVector& CallFunc_BreakTransform_Scale, float CallFunc_MapRangeClamped_ReturnValue_2, float CallFunc_MapRangeClamped_ReturnValue_3, float CallFunc_FClamp_ReturnValue_5, float K2Node_Select_Default_5, float K2Node_Event_DeltaTimeX, class APawn* CallFunc_TryGetPawnOwner_ReturnValue, class ACh_Hero_00_C* K2Node_DynamicCast_AsCh_Hero_00, bool K2Node_DynamicCast_bSuccess, float CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue, bool CallFunc_LessEqual_FloatFloat_ReturnValue, bool CallFunc_IsPlayingSlotAnimation_ReturnValue, class UAnimMontage* CallFunc_PlaySlotAnimationAsDynamicMontage_ReturnValue, float CallFunc_FMax_ReturnValue, bool CallFunc_Greater_FloatFloat_ReturnValue_5, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_7, bool CallFunc_Less_FloatFloat_ReturnValue_5, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_8, bool CallFunc_Less_FloatFloat_ReturnValue_6, TScriptInterface<class Ibpi_animAdditional_C> K2Node_DynamicCast_AsBpi_Anim_Additional, bool K2Node_DynamicCast_bSuccess_1, bool CallFunc_GetFullHandRecoil_bOutFullHandRecoil, TSubclassOf<class ACGMovementState> CallFunc_GetCurrentMovementState_ReturnValue, bool CallFunc_EqualEqual_ClassClass_ReturnValue, float CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue_1, bool CallFunc_LessEqual_FloatFloat_ReturnValue_1, class ACGWeapon* K2Node_DynamicCast_AsCGWeapon, bool K2Node_DynamicCast_bSuccess_2, float CallFunc_GetCurveValue_ReturnValue, float CallFunc_GetCurveValue_ReturnValue_1, float CallFunc_Multiply_FloatFloat_ReturnValue_4, float CallFunc_FClamp_ReturnValue_6, float CallFunc_FClamp_ReturnValue_7, float CallFunc_GetCurveValue_ReturnValue_2, float CallFunc_Subtract_FloatFloat_ReturnValue_2, float CallFunc_Abs_ReturnValue_2, float CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue, bool CallFunc_Less_FloatFloat_ReturnValue_7, class ACGWeapon* K2Node_DynamicCast_AsCGWeapon_1, bool K2Node_DynamicCast_bSuccess_3, bool CallFunc_EqualEqual_ByteByte_ReturnValue, bool CallFunc_IsFalling_ReturnValue, bool CallFunc_Greater_FloatFloat_ReturnValue_6, float CallFunc_GetCurveValue_ReturnValue_3, bool CallFunc_Less_FloatFloat_ReturnValue_8, float CallFunc_GetCurveValue_ReturnValue_4, float CallFunc_GetMovementRightInput_ReturnValue, const struct FRotator& CallFunc_GetControlRotation_ReturnValue, float CallFunc_GetMovementForwardInput_ReturnValue, float CallFunc_VSize_ReturnValue, class ACGWeapon* K2Node_DynamicCast_AsCGWeapon_2, bool K2Node_DynamicCast_bSuccess_4, float CallFunc_Multiply_FloatFloat_ReturnValue_5, bool CallFunc_Not_PreBool_ReturnValue_1, float CallFunc_GetWorldDeltaSeconds_ReturnValue, float CallFunc_Conv_BoolToFloat_ReturnValue, float CallFunc_FInterpTo_ReturnValue, const struct FTransform& CallFunc_K2_GetComponentToWorld_ReturnValue, class AController* CallFunc_GetController_ReturnValue, const struct FTransform& CallFunc_MakeTransform_ReturnValue_1, bool CallFunc_IsValid_ReturnValue_2, const struct FRotator& CallFunc_GetControlRotation_ReturnValue_1, float CallFunc_BreakRotator_Roll, float CallFunc_BreakRotator_Pitch, float CallFunc_BreakRotator_Yaw, float CallFunc_Add_FloatFloat_ReturnValue_1, const struct FRotator& CallFunc_MakeRotator_ReturnValue, bool CallFunc_BooleanAND_ReturnValue_2, const struct FTransform& CallFunc_MakeTransform_ReturnValue_2, const struct FTransform& CallFunc_ComposeTransforms_ReturnValue, float CallFunc_GetCurveValue_ReturnValue_5, const struct FTransform& CallFunc_ComposeTransforms_ReturnValue_1, float CallFunc_Subtract_FloatFloat_ReturnValue_3, float CallFunc_Abs_ReturnValue_3, bool CallFunc_Not_PreBool_ReturnValue_2, bool CallFunc_BooleanAND_ReturnValue_3, float K2Node_Select_Default_6, float CallFunc_Conv_BoolToFloat_ReturnValue_1, float CallFunc_FInterpTo_ReturnValue_1, bool CallFunc_Not_PreBool_ReturnValue_3, float K2Node_Select_Default_7, int32 CallFunc_Array_Length_ReturnValue, float CallFunc_Add_FloatFloat_ReturnValue_2, int32 CallFunc_Subtract_IntInt_ReturnValue, int32 CallFunc_GetRandomIntInRangeWithExclusion_ReturnValue, int32 CallFunc_RandomIntegerInRange_ReturnValue, int32 CallFunc_Array_Length_ReturnValue_1, bool CallFunc_Greater_IntInt_ReturnValue, bool CallFunc_TryChance_ReturnValue, bool CallFunc_Greater_FloatFloat_ReturnValue_7, bool CallFunc_BooleanAND_ReturnValue_4, bool CallFunc_BooleanAND_ReturnValue_5, float CallFunc_Add_FloatFloat_ReturnValue_3, float CallFunc_Add_FloatFloat_ReturnValue_4, bool CallFunc_Greater_FloatFloat_ReturnValue_8, bool CallFunc_BooleanAND_ReturnValue_6, bool CallFunc_Greater_FloatFloat_ReturnValue_9, class UAnimSequenceBase* K2Node_Select_Default_8, class UAnimMontage* CallFunc_PlaySlotAnimationAsDynamicMontage_ReturnValue_1, float CallFunc_GetAverage_ReturnValue, float CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue_1, bool CallFunc_Less_FloatFloat_ReturnValue_9, float CallFunc_BreakRotator_Roll_1, float CallFunc_BreakRotator_Pitch_1, float CallFunc_BreakRotator_Yaw_1, float CallFunc_Abs_ReturnValue_4, TArray<float>& CallFunc_ArrayToStack_ReturnValue, bool CallFunc_BooleanOR_ReturnValue_1, bool CallFunc_Not_PreBool_ReturnValue_4, bool CallFunc_IsValid_ReturnValue_3, bool CallFunc_BooleanAND_ReturnValue_7, const struct FTransform& CallFunc_GetOtherHandIKTarget_ReturnValue, const struct FVector& CallFunc_BreakTransform_Location_1, const struct FRotator& CallFunc_BreakTransform_Rotation_1, const struct FVector& CallFunc_BreakTransform_Scale_1, const struct FVector& CallFunc_TransformToBoneSpace_OutPosition, const struct FRotator& CallFunc_TransformToBoneSpace_OutRotation, bool CallFunc_Not_PreBool_ReturnValue_5, const struct FTransform& CallFunc_MakeTransform_ReturnValue_3, bool CallFunc_BooleanAND_ReturnValue_8, float CallFunc_Conv_BoolToFloat_ReturnValue_2, float CallFunc_GetWorldDeltaSeconds_ReturnValue_1, float CallFunc_FMin_ReturnValue_1, float CallFunc_GetWorldDeltaSeconds_ReturnValue_2, float CallFunc_FInterpTo_ReturnValue_2, float CallFunc_FInterpTo_ReturnValue_3, const struct FVector& CallFunc_GetActorForwardVector_ReturnValue, const struct FRotator& CallFunc_MakeRotFromX_ReturnValue, float CallFunc_VSize_ReturnValue_1, const struct FRotator& CallFunc_MakeRotFromX_ReturnValue_1, bool CallFunc_Greater_FloatFloat_ReturnValue_10, const struct FRotator& CallFunc_NormalizedDeltaRotator_ReturnValue, float CallFunc_BreakRotator_Roll_2, float CallFunc_BreakRotator_Pitch_2, float CallFunc_BreakRotator_Yaw_2, bool CallFunc_BooleanAND_ReturnValue_9, float CallFunc_SelectFloat_ReturnValue_3, bool CallFunc_LastInputWasFromGamepad_Gamepad, float CallFunc_K2_GetModifiedMaxSpeed_ReturnValue, float CallFunc_SelectFloat_ReturnValue_4, float CallFunc_MapRangeClamped_ReturnValue_4, float CallFunc_BreakRotator_Roll_3, float CallFunc_BreakRotator_Pitch_3, float CallFunc_BreakRotator_Yaw_3, bool CallFunc_GreaterEqual_IntInt_ReturnValue, float CallFunc_Multiply_FloatFloat_ReturnValue_6, float CallFunc_MapRangeClamped_ReturnValue_5, int32 K2Node_Select_Default_9, class UAnimSequence* CallFunc_Array_Get_Item, float CallFunc_MapRangeClamped_ReturnValue_6, class UAnimMontage* CallFunc_PlaySlotAnimationAsDynamicMontage_ReturnValue_2, const struct FRotator& CallFunc_NormalizedDeltaRotator_ReturnValue_1);
};

}


