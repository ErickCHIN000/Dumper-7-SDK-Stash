#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x48 - 0x48)
// BlueprintGeneratedClass an_akAudioNotify_Shot_AK47.an_akAudioNotify_Shot_AK47_C
class UAn_akAudioNotify_Shot_AK47_C : public UAn_akAudioNotify_Shot_C
{
public:

	static class UClass* StaticClass();
	static class UAn_akAudioNotify_Shot_AK47_C* GetDefaultObj();

};

}


