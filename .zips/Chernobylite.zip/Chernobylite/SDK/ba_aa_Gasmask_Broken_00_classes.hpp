#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x4D8 - 0x4D8)
// BlueprintGeneratedClass ba_aa_Gasmask_Broken_00.ba_aa_Gasmask_Broken_00_C
class Aba_aa_Gasmask_Broken_00_C : public Aba_aa_Gasmask_00_C
{
public:

	static class UClass* StaticClass();
	static class Aba_aa_Gasmask_Broken_00_C* GetDefaultObj();

};

}


