#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// FUNCTIONS
//---------------------------------------------------------------------------------------------------------------------


// AnimBlueprintGeneratedClass abp_heroCamera_00.abp_heroCamera_00_C
// (None)

class UClass* UAbp_heroCamera_00_C::StaticClass()
{
	static class UClass* Clss = nullptr;

	if (!Clss)
		Clss = UObject::FindClassFast("abp_heroCamera_00_C");

	return Clss;
}


// abp_heroCamera_00_C abp_heroCamera_00.Default__abp_heroCamera_00_C
// (Public, ClassDefaultObject, ArchetypeObject, WasLoaded, LoadCompleted)

class UAbp_heroCamera_00_C* UAbp_heroCamera_00_C::GetDefaultObj()
{
	static class UAbp_heroCamera_00_C* Default = nullptr;

	if (!Default)
		Default = static_cast<UAbp_heroCamera_00_C*>(UAbp_heroCamera_00_C::StaticClass()->DefaultObject);

	return Default;
}


// Function abp_heroCamera_00.abp_heroCamera_00_C.AnimGraph
// (HasOutParams, BlueprintCallable, BlueprintEvent)
// Parameters:
// struct FPoseLink                   AnimGraph                                                        (Parm, OutParm, NoDestructor)

void UAbp_heroCamera_00_C::AnimGraph(struct FPoseLink* AnimGraph)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "AnimGraph");

	Params::UAbp_heroCamera_00_C_AnimGraph_Params Parms{};


	UObject::ProcessEvent(Func, &Parms);

	if (AnimGraph != nullptr)
		*AnimGraph = std::move(Parms.AnimGraph);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_133C421C4DDF861837205E8DD3A4CDB5
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_133C421C4DDF861837205E8DD3A4CDB5()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_133C421C4DDF861837205E8DD3A4CDB5");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_82D9E03C4670225A476B738E722B4BE1
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_82D9E03C4670225A476B738E722B4BE1()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_82D9E03C4670225A476B738E722B4BE1");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_EF0FF2EE41646A60AE4BAE965978F67D
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_EF0FF2EE41646A60AE4BAE965978F67D()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_EF0FF2EE41646A60AE4BAE965978F67D");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_35284AD54C2038BF9100B3993E893A30
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_35284AD54C2038BF9100B3993E893A30()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_35284AD54C2038BF9100B3993E893A30");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_C0B2B8EE4A60EDA774A274827326C7A7
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_C0B2B8EE4A60EDA774A274827326C7A7()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_C0B2B8EE4A60EDA774A274827326C7A7");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_ECCAA916474A41E571CFF586A6A24E44
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_ECCAA916474A41E571CFF586A6A24E44()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_ECCAA916474A41E571CFF586A6A24E44");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_FEEB341F4CAD99A924952E8B85CDBF74
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_FEEB341F4CAD99A924952E8B85CDBF74()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_FEEB341F4CAD99A924952E8B85CDBF74");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_FEF9C9B24D5B979E7767498D56FBF031
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_FEF9C9B24D5B979E7767498D56FBF031()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_FEF9C9B24D5B979E7767498D56FBF031");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_CCD8661D4E7E89FCCBC337A631C7C6F1
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_CCD8661D4E7E89FCCBC337A631C7C6F1()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_CCD8661D4E7E89FCCBC337A631C7C6F1");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_ModifyBone_A17EB3434AA78C4C051DDB8B96905DAA
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_ModifyBone_A17EB3434AA78C4C051DDB8B96905DAA()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_ModifyBone_A17EB3434AA78C4C051DDB8B96905DAA");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_ApplyMeshSpaceAdditive_572832F74E660E8EC9867E88144F5A6E
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_ApplyMeshSpaceAdditive_572832F74E660E8EC9867E88144F5A6E()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_ApplyMeshSpaceAdditive_572832F74E660E8EC9867E88144F5A6E");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_6D63235740A792AE5002699E6D875438
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_6D63235740A792AE5002699E6D875438()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_LayeredBoneBlend_6D63235740A792AE5002699E6D875438");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_ApplyMeshSpaceAdditive_1769E63A44F0DF35DD962782353F9363
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_ApplyMeshSpaceAdditive_1769E63A44F0DF35DD962782353F9363()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_ApplyMeshSpaceAdditive_1769E63A44F0DF35DD962782353F9363");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_9FD0C3434ED7315908CA50BEEC0A6296
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_9FD0C3434ED7315908CA50BEEC0A6296()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_9FD0C3434ED7315908CA50BEEC0A6296");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_CB0981E24FA85A2EB5D2FBA3F76671EF
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_CB0981E24FA85A2EB5D2FBA3F76671EF()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_CB0981E24FA85A2EB5D2FBA3F76671EF");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_8E8AFAA846D464EB34B0039F88B8C6A5
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_8E8AFAA846D464EB34B0039F88B8C6A5()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_8E8AFAA846D464EB34B0039F88B8C6A5");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_08A2336547C2054725607683E13CF5AC
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_08A2336547C2054725607683E13CF5AC()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_08A2336547C2054725607683E13CF5AC");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_04C8C92A42777D3E4059FF882406AD9F
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_04C8C92A42777D3E4059FF882406AD9F()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_04C8C92A42777D3E4059FF882406AD9F");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_BlendListByBool_9C8274A44D64E142FF358CB387D2C9BA
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_BlendListByBool_9C8274A44D64E142FF358CB387D2C9BA()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_BlendListByBool_9C8274A44D64E142FF358CB387D2C9BA");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_431C81E94F4AC986AB8349BDE22CCE7B
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_431C81E94F4AC986AB8349BDE22CCE7B()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_431C81E94F4AC986AB8349BDE22CCE7B");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_751840CF4ED8D58540941C872453B62D
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_751840CF4ED8D58540941C872453B62D()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_751840CF4ED8D58540941C872453B62D");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_1A4B49ED44CACD4C8F68DF953D6E21A0
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_1A4B49ED44CACD4C8F68DF953D6E21A0()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_1A4B49ED44CACD4C8F68DF953D6E21A0");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.BlueprintUpdateAnimation
// (Event, Public, BlueprintEvent)
// Parameters:
// float                              DeltaTimeX                                                       (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)

void UAbp_heroCamera_00_C::BlueprintUpdateAnimation(float DeltaTimeX)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "BlueprintUpdateAnimation");

	Params::UAbp_heroCamera_00_C_BlueprintUpdateAnimation_Params Parms{};

	Parms.DeltaTimeX = DeltaTimeX;

	UObject::ProcessEvent(Func, &Parms);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_DC596D37428DC97F238DD9B02E40F3D6
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_DC596D37428DC97F238DD9B02E40F3D6()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_DC596D37428DC97F238DD9B02E40F3D6");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_574E886145A83026CB6DF79545076773
// (BlueprintEvent)
// Parameters:

void UAbp_heroCamera_00_C::EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_574E886145A83026CB6DF79545076773()
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "EvaluateGraphExposedInputs_ExecuteUbergraph_abp_heroCamera_00_AnimGraphNode_TransitionResult_574E886145A83026CB6DF79545076773");



	UObject::ProcessEvent(Func, nullptr);

}


// Function abp_heroCamera_00.abp_heroCamera_00_C.ExecuteUbergraph_abp_heroCamera_00
// (Final, UbergraphFunction)
// Parameters:
// int32                              EntryPoint                                                       (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class UGameUserSettings*           CallFunc_GetGameUserSettings_ReturnValue                         (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_GetIsHeadBobbingEnabled_ReturnValue                     (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Not_PreBool_ReturnValue                                 (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue        (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_Less_FloatFloat_ReturnValue                             (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Greater_FloatFloat_ReturnValue                          (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Not_PreBool_ReturnValue_1                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_BooleanOR_ReturnValue                                   (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Not_PreBool_ReturnValue_2                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue_1      (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_BooleanOR_ReturnValue_1                                 (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Less_FloatFloat_ReturnValue_1                           (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Not_PreBool_ReturnValue_3                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_IsValid_ReturnValue                                     (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_BooleanAND_ReturnValue                                  (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Not_PreBool_ReturnValue_4                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_BooleanAND_ReturnValue_1                                (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Not_PreBool_ReturnValue_5                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_BooleanAND_ReturnValue_2                                (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_BooleanAND_ReturnValue_3                                (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Not_PreBool_ReturnValue_6                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// TSubclassOf<class ACGMovementState>CallFunc_GetCurrentMovementState_ReturnValue                     (ZeroConstructor, IsPlainOldData, NoDestructor, UObjectWrapper, HasGetValueTypeHash)
// bool                               CallFunc_BooleanOR_ReturnValue_2                                 (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_EqualEqual_ClassClass_ReturnValue                       (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              Temp_float_Variable                                              (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_BooleanAND_ReturnValue_4                                (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               Temp_bool_Variable                                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Greater_FloatFloat_ReturnValue_1                        (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_GetRelevantAnimTimeRemaining_ReturnValue                (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_Not_PreBool_ReturnValue_7                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Less_FloatFloat_ReturnValue_2                           (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_Conv_BoolToFloat_ReturnValue                            (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_Conv_BoolToFloat_ReturnValue_1                          (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_SelectFloat_ReturnValue                                 (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_Multiply_FloatFloat_ReturnValue                         (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              Temp_float_Variable_1                                            (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              Temp_float_Variable_2                                            (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               Temp_bool_Variable_1                                             (ZeroConstructor, IsPlainOldData, NoDestructor)
// struct FRotator                    CallFunc_Multiply_RotatorFloat_ReturnValue                       (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              K2Node_Select_Default                                            (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_SelectFloat_ReturnValue_1                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_FMax_ReturnValue                                        (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_SelectFloat_ReturnValue_2                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_SelectFloat_ReturnValue_3                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_SelectFloat_ReturnValue_4                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_SelectFloat_ReturnValue_5                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              K2Node_Event_DeltaTimeX                                          (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_SelectFloat_ReturnValue_6                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class APawn*                       CallFunc_TryGetPawnOwner_ReturnValue                             (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class ACh_Hero_00_C*               K2Node_DynamicCast_AsCh_Hero_00                                  (ZeroConstructor, IsPlainOldData, NoDestructor, UObjectWrapper, HasGetValueTypeHash)
// bool                               K2Node_DynamicCast_bSuccess                                      (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue   (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_Less_FloatFloat_ReturnValue_3                           (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_IsFalling_ReturnValue                                   (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Greater_FloatFloat_ReturnValue_2                        (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_BooleanAND_ReturnValue_5                                (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_VSize_ReturnValue                                       (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_IsMovingOnGround_ReturnValue                            (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Not_PreBool_ReturnValue_8                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_K2_GetModifiedMaxSpeed_ReturnValue                      (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_BooleanOR_ReturnValue_3                                 (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_MapRangeClamped_ReturnValue                             (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_Not_PreBool_ReturnValue_9                               (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_GetCurveValue_ReturnValue                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue_1 (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_Less_FloatFloat_ReturnValue_4                           (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_BooleanAND_ReturnValue_6                                (ZeroConstructor, IsPlainOldData, NoDestructor)
// struct FRotator                    CallFunc_K2_GetActorRotation_ReturnValue                         (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_BooleanOR_ReturnValue_4                                 (ZeroConstructor, IsPlainOldData, NoDestructor)
// struct FRotator                    CallFunc_MakeRotFromX_ReturnValue                                (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_MapRangeClamped_ReturnValue_1                           (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FRotator                    CallFunc_NormalizedDeltaRotator_ReturnValue                      (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_BreakRotator_Roll                                       (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_BreakRotator_Pitch                                      (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_BreakRotator_Yaw                                        (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_Add_FloatFloat_ReturnValue                              (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_FClamp_ReturnValue                                      (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_GetWorldDeltaSeconds_ReturnValue                        (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FRotator                    CallFunc_NormalizedDeltaRotator_ReturnValue_1                    (ZeroConstructor, IsPlainOldData, NoDestructor)
// class AController*                 CallFunc_GetController_ReturnValue                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_BreakRotator_Roll_1                                     (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_BreakRotator_Pitch_1                                    (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_BreakRotator_Yaw_1                                      (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_IsValid_ReturnValue_1                                   (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_MapRangeClamped_ReturnValue_2                           (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_SignOfFloat_ReturnValue                                 (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_Divide_FloatFloat_ReturnValue                           (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_MapRangeClamped_ReturnValue_3                           (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// struct FRotator                    CallFunc_GetControlRotation_ReturnValue                          (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_Less_FloatFloat_ReturnValue_5                           (ZeroConstructor, IsPlainOldData, NoDestructor)
// bool                               CallFunc_BooleanAND_ReturnValue_7                                (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_SelectFloat_ReturnValue_7                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_Multiply_FloatFloat_ReturnValue_1                       (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_FClamp_ReturnValue_1                                    (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// bool                               CallFunc_Greater_FloatFloat_ReturnValue_3                        (ZeroConstructor, IsPlainOldData, NoDestructor)
// float                              CallFunc_SelectFloat_ReturnValue_8                               (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_GetWorldDeltaSeconds_ReturnValue_1                      (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_FInterpTo_ReturnValue                                   (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_Abs_ReturnValue                                         (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_FMax_ReturnValue_1                                      (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              K2Node_Select_Default_1                                          (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// float                              CallFunc_FInterpTo_ReturnValue_1                                 (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// TSubclassOf<class ACGMovementState>CallFunc_GetCurrentMovementState_ReturnValue_1                   (ZeroConstructor, IsPlainOldData, NoDestructor, UObjectWrapper, HasGetValueTypeHash)
// bool                               CallFunc_EqualEqual_ClassClass_ReturnValue_1                     (ZeroConstructor, IsPlainOldData, NoDestructor)
// class ACh_Hero_00_C*               CallFunc_GetCGPlayerCharacter_CGPlayerCharacter                  (ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
// class ACGWeapon*                   K2Node_DynamicCast_AsCGWeapon                                    (ZeroConstructor, IsPlainOldData, NoDestructor, UObjectWrapper, HasGetValueTypeHash)
// bool                               K2Node_DynamicCast_bSuccess_1                                    (ZeroConstructor, IsPlainOldData, NoDestructor)

void UAbp_heroCamera_00_C::ExecuteUbergraph_abp_heroCamera_00(int32 EntryPoint, class UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue, bool CallFunc_GetIsHeadBobbingEnabled_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue, float CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue, bool CallFunc_Less_FloatFloat_ReturnValue, bool CallFunc_Greater_FloatFloat_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_1, bool CallFunc_BooleanOR_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_2, float CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue_1, bool CallFunc_BooleanOR_ReturnValue_1, bool CallFunc_Less_FloatFloat_ReturnValue_1, bool CallFunc_Not_PreBool_ReturnValue_3, bool CallFunc_IsValid_ReturnValue, bool CallFunc_BooleanAND_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_4, bool CallFunc_BooleanAND_ReturnValue_1, bool CallFunc_Not_PreBool_ReturnValue_5, bool CallFunc_BooleanAND_ReturnValue_2, bool CallFunc_BooleanAND_ReturnValue_3, bool CallFunc_Not_PreBool_ReturnValue_6, TSubclassOf<class ACGMovementState> CallFunc_GetCurrentMovementState_ReturnValue, bool CallFunc_BooleanOR_ReturnValue_2, bool CallFunc_EqualEqual_ClassClass_ReturnValue, float Temp_float_Variable, bool CallFunc_BooleanAND_ReturnValue_4, bool Temp_bool_Variable, bool CallFunc_Greater_FloatFloat_ReturnValue_1, float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_7, bool CallFunc_Less_FloatFloat_ReturnValue_2, float CallFunc_Conv_BoolToFloat_ReturnValue, float CallFunc_Conv_BoolToFloat_ReturnValue_1, float CallFunc_SelectFloat_ReturnValue, float CallFunc_Multiply_FloatFloat_ReturnValue, float Temp_float_Variable_1, float Temp_float_Variable_2, bool Temp_bool_Variable_1, const struct FRotator& CallFunc_Multiply_RotatorFloat_ReturnValue, float K2Node_Select_Default, float CallFunc_SelectFloat_ReturnValue_1, float CallFunc_FMax_ReturnValue, float CallFunc_SelectFloat_ReturnValue_2, float CallFunc_SelectFloat_ReturnValue_3, float CallFunc_SelectFloat_ReturnValue_4, float CallFunc_SelectFloat_ReturnValue_5, float K2Node_Event_DeltaTimeX, float CallFunc_SelectFloat_ReturnValue_6, class APawn* CallFunc_TryGetPawnOwner_ReturnValue, class ACh_Hero_00_C* K2Node_DynamicCast_AsCh_Hero_00, bool K2Node_DynamicCast_bSuccess, float CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue, bool CallFunc_Less_FloatFloat_ReturnValue_3, bool CallFunc_IsFalling_ReturnValue, bool CallFunc_Greater_FloatFloat_ReturnValue_2, bool CallFunc_BooleanAND_ReturnValue_5, float CallFunc_VSize_ReturnValue, bool CallFunc_IsMovingOnGround_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_8, float CallFunc_K2_GetModifiedMaxSpeed_ReturnValue, bool CallFunc_BooleanOR_ReturnValue_3, float CallFunc_MapRangeClamped_ReturnValue, bool CallFunc_Not_PreBool_ReturnValue_9, float CallFunc_GetCurveValue_ReturnValue, float CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue_1, bool CallFunc_Less_FloatFloat_ReturnValue_4, bool CallFunc_BooleanAND_ReturnValue_6, const struct FRotator& CallFunc_K2_GetActorRotation_ReturnValue, bool CallFunc_BooleanOR_ReturnValue_4, const struct FRotator& CallFunc_MakeRotFromX_ReturnValue, float CallFunc_MapRangeClamped_ReturnValue_1, const struct FRotator& CallFunc_NormalizedDeltaRotator_ReturnValue, float CallFunc_BreakRotator_Roll, float CallFunc_BreakRotator_Pitch, float CallFunc_BreakRotator_Yaw, float CallFunc_Add_FloatFloat_ReturnValue, float CallFunc_FClamp_ReturnValue, float CallFunc_GetWorldDeltaSeconds_ReturnValue, const struct FRotator& CallFunc_NormalizedDeltaRotator_ReturnValue_1, class AController* CallFunc_GetController_ReturnValue, float CallFunc_BreakRotator_Roll_1, float CallFunc_BreakRotator_Pitch_1, float CallFunc_BreakRotator_Yaw_1, bool CallFunc_IsValid_ReturnValue_1, float CallFunc_MapRangeClamped_ReturnValue_2, float CallFunc_SignOfFloat_ReturnValue, float CallFunc_Divide_FloatFloat_ReturnValue, float CallFunc_MapRangeClamped_ReturnValue_3, const struct FRotator& CallFunc_GetControlRotation_ReturnValue, bool CallFunc_Less_FloatFloat_ReturnValue_5, bool CallFunc_BooleanAND_ReturnValue_7, float CallFunc_SelectFloat_ReturnValue_7, float CallFunc_Multiply_FloatFloat_ReturnValue_1, float CallFunc_FClamp_ReturnValue_1, bool CallFunc_Greater_FloatFloat_ReturnValue_3, float CallFunc_SelectFloat_ReturnValue_8, float CallFunc_GetWorldDeltaSeconds_ReturnValue_1, float CallFunc_FInterpTo_ReturnValue, float CallFunc_Abs_ReturnValue, float CallFunc_FMax_ReturnValue_1, float K2Node_Select_Default_1, float CallFunc_FInterpTo_ReturnValue_1, TSubclassOf<class ACGMovementState> CallFunc_GetCurrentMovementState_ReturnValue_1, bool CallFunc_EqualEqual_ClassClass_ReturnValue_1, class ACh_Hero_00_C* CallFunc_GetCGPlayerCharacter_CGPlayerCharacter, class ACGWeapon* K2Node_DynamicCast_AsCGWeapon, bool K2Node_DynamicCast_bSuccess_1)
{
	static class UFunction* Func = nullptr;

	if (!Func)
		Func = Class->GetFunction("abp_heroCamera_00_C", "ExecuteUbergraph_abp_heroCamera_00");

	Params::UAbp_heroCamera_00_C_ExecuteUbergraph_abp_heroCamera_00_Params Parms{};

	Parms.EntryPoint = EntryPoint;
	Parms.CallFunc_GetGameUserSettings_ReturnValue = CallFunc_GetGameUserSettings_ReturnValue;
	Parms.CallFunc_GetIsHeadBobbingEnabled_ReturnValue = CallFunc_GetIsHeadBobbingEnabled_ReturnValue;
	Parms.CallFunc_Not_PreBool_ReturnValue = CallFunc_Not_PreBool_ReturnValue;
	Parms.CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue = CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue;
	Parms.CallFunc_Less_FloatFloat_ReturnValue = CallFunc_Less_FloatFloat_ReturnValue;
	Parms.CallFunc_Greater_FloatFloat_ReturnValue = CallFunc_Greater_FloatFloat_ReturnValue;
	Parms.CallFunc_Not_PreBool_ReturnValue_1 = CallFunc_Not_PreBool_ReturnValue_1;
	Parms.CallFunc_BooleanOR_ReturnValue = CallFunc_BooleanOR_ReturnValue;
	Parms.CallFunc_Not_PreBool_ReturnValue_2 = CallFunc_Not_PreBool_ReturnValue_2;
	Parms.CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue_1 = CallFunc_GetRelevantAnimTimeRemainingFraction_ReturnValue_1;
	Parms.CallFunc_BooleanOR_ReturnValue_1 = CallFunc_BooleanOR_ReturnValue_1;
	Parms.CallFunc_Less_FloatFloat_ReturnValue_1 = CallFunc_Less_FloatFloat_ReturnValue_1;
	Parms.CallFunc_Not_PreBool_ReturnValue_3 = CallFunc_Not_PreBool_ReturnValue_3;
	Parms.CallFunc_IsValid_ReturnValue = CallFunc_IsValid_ReturnValue;
	Parms.CallFunc_BooleanAND_ReturnValue = CallFunc_BooleanAND_ReturnValue;
	Parms.CallFunc_Not_PreBool_ReturnValue_4 = CallFunc_Not_PreBool_ReturnValue_4;
	Parms.CallFunc_BooleanAND_ReturnValue_1 = CallFunc_BooleanAND_ReturnValue_1;
	Parms.CallFunc_Not_PreBool_ReturnValue_5 = CallFunc_Not_PreBool_ReturnValue_5;
	Parms.CallFunc_BooleanAND_ReturnValue_2 = CallFunc_BooleanAND_ReturnValue_2;
	Parms.CallFunc_BooleanAND_ReturnValue_3 = CallFunc_BooleanAND_ReturnValue_3;
	Parms.CallFunc_Not_PreBool_ReturnValue_6 = CallFunc_Not_PreBool_ReturnValue_6;
	Parms.CallFunc_GetCurrentMovementState_ReturnValue = CallFunc_GetCurrentMovementState_ReturnValue;
	Parms.CallFunc_BooleanOR_ReturnValue_2 = CallFunc_BooleanOR_ReturnValue_2;
	Parms.CallFunc_EqualEqual_ClassClass_ReturnValue = CallFunc_EqualEqual_ClassClass_ReturnValue;
	Parms.Temp_float_Variable = Temp_float_Variable;
	Parms.CallFunc_BooleanAND_ReturnValue_4 = CallFunc_BooleanAND_ReturnValue_4;
	Parms.Temp_bool_Variable = Temp_bool_Variable;
	Parms.CallFunc_Greater_FloatFloat_ReturnValue_1 = CallFunc_Greater_FloatFloat_ReturnValue_1;
	Parms.CallFunc_GetRelevantAnimTimeRemaining_ReturnValue = CallFunc_GetRelevantAnimTimeRemaining_ReturnValue;
	Parms.CallFunc_Not_PreBool_ReturnValue_7 = CallFunc_Not_PreBool_ReturnValue_7;
	Parms.CallFunc_Less_FloatFloat_ReturnValue_2 = CallFunc_Less_FloatFloat_ReturnValue_2;
	Parms.CallFunc_Conv_BoolToFloat_ReturnValue = CallFunc_Conv_BoolToFloat_ReturnValue;
	Parms.CallFunc_Conv_BoolToFloat_ReturnValue_1 = CallFunc_Conv_BoolToFloat_ReturnValue_1;
	Parms.CallFunc_SelectFloat_ReturnValue = CallFunc_SelectFloat_ReturnValue;
	Parms.CallFunc_Multiply_FloatFloat_ReturnValue = CallFunc_Multiply_FloatFloat_ReturnValue;
	Parms.Temp_float_Variable_1 = Temp_float_Variable_1;
	Parms.Temp_float_Variable_2 = Temp_float_Variable_2;
	Parms.Temp_bool_Variable_1 = Temp_bool_Variable_1;
	Parms.CallFunc_Multiply_RotatorFloat_ReturnValue = CallFunc_Multiply_RotatorFloat_ReturnValue;
	Parms.K2Node_Select_Default = K2Node_Select_Default;
	Parms.CallFunc_SelectFloat_ReturnValue_1 = CallFunc_SelectFloat_ReturnValue_1;
	Parms.CallFunc_FMax_ReturnValue = CallFunc_FMax_ReturnValue;
	Parms.CallFunc_SelectFloat_ReturnValue_2 = CallFunc_SelectFloat_ReturnValue_2;
	Parms.CallFunc_SelectFloat_ReturnValue_3 = CallFunc_SelectFloat_ReturnValue_3;
	Parms.CallFunc_SelectFloat_ReturnValue_4 = CallFunc_SelectFloat_ReturnValue_4;
	Parms.CallFunc_SelectFloat_ReturnValue_5 = CallFunc_SelectFloat_ReturnValue_5;
	Parms.K2Node_Event_DeltaTimeX = K2Node_Event_DeltaTimeX;
	Parms.CallFunc_SelectFloat_ReturnValue_6 = CallFunc_SelectFloat_ReturnValue_6;
	Parms.CallFunc_TryGetPawnOwner_ReturnValue = CallFunc_TryGetPawnOwner_ReturnValue;
	Parms.K2Node_DynamicCast_AsCh_Hero_00 = K2Node_DynamicCast_AsCh_Hero_00;
	Parms.K2Node_DynamicCast_bSuccess = K2Node_DynamicCast_bSuccess;
	Parms.CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue = CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue;
	Parms.CallFunc_Less_FloatFloat_ReturnValue_3 = CallFunc_Less_FloatFloat_ReturnValue_3;
	Parms.CallFunc_IsFalling_ReturnValue = CallFunc_IsFalling_ReturnValue;
	Parms.CallFunc_Greater_FloatFloat_ReturnValue_2 = CallFunc_Greater_FloatFloat_ReturnValue_2;
	Parms.CallFunc_BooleanAND_ReturnValue_5 = CallFunc_BooleanAND_ReturnValue_5;
	Parms.CallFunc_VSize_ReturnValue = CallFunc_VSize_ReturnValue;
	Parms.CallFunc_IsMovingOnGround_ReturnValue = CallFunc_IsMovingOnGround_ReturnValue;
	Parms.CallFunc_Not_PreBool_ReturnValue_8 = CallFunc_Not_PreBool_ReturnValue_8;
	Parms.CallFunc_K2_GetModifiedMaxSpeed_ReturnValue = CallFunc_K2_GetModifiedMaxSpeed_ReturnValue;
	Parms.CallFunc_BooleanOR_ReturnValue_3 = CallFunc_BooleanOR_ReturnValue_3;
	Parms.CallFunc_MapRangeClamped_ReturnValue = CallFunc_MapRangeClamped_ReturnValue;
	Parms.CallFunc_Not_PreBool_ReturnValue_9 = CallFunc_Not_PreBool_ReturnValue_9;
	Parms.CallFunc_GetCurveValue_ReturnValue = CallFunc_GetCurveValue_ReturnValue;
	Parms.CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue_1 = CallFunc_GetInstanceAssetPlayerTimeFromEndFraction_ReturnValue_1;
	Parms.CallFunc_Less_FloatFloat_ReturnValue_4 = CallFunc_Less_FloatFloat_ReturnValue_4;
	Parms.CallFunc_BooleanAND_ReturnValue_6 = CallFunc_BooleanAND_ReturnValue_6;
	Parms.CallFunc_K2_GetActorRotation_ReturnValue = CallFunc_K2_GetActorRotation_ReturnValue;
	Parms.CallFunc_BooleanOR_ReturnValue_4 = CallFunc_BooleanOR_ReturnValue_4;
	Parms.CallFunc_MakeRotFromX_ReturnValue = CallFunc_MakeRotFromX_ReturnValue;
	Parms.CallFunc_MapRangeClamped_ReturnValue_1 = CallFunc_MapRangeClamped_ReturnValue_1;
	Parms.CallFunc_NormalizedDeltaRotator_ReturnValue = CallFunc_NormalizedDeltaRotator_ReturnValue;
	Parms.CallFunc_BreakRotator_Roll = CallFunc_BreakRotator_Roll;
	Parms.CallFunc_BreakRotator_Pitch = CallFunc_BreakRotator_Pitch;
	Parms.CallFunc_BreakRotator_Yaw = CallFunc_BreakRotator_Yaw;
	Parms.CallFunc_Add_FloatFloat_ReturnValue = CallFunc_Add_FloatFloat_ReturnValue;
	Parms.CallFunc_FClamp_ReturnValue = CallFunc_FClamp_ReturnValue;
	Parms.CallFunc_GetWorldDeltaSeconds_ReturnValue = CallFunc_GetWorldDeltaSeconds_ReturnValue;
	Parms.CallFunc_NormalizedDeltaRotator_ReturnValue_1 = CallFunc_NormalizedDeltaRotator_ReturnValue_1;
	Parms.CallFunc_GetController_ReturnValue = CallFunc_GetController_ReturnValue;
	Parms.CallFunc_BreakRotator_Roll_1 = CallFunc_BreakRotator_Roll_1;
	Parms.CallFunc_BreakRotator_Pitch_1 = CallFunc_BreakRotator_Pitch_1;
	Parms.CallFunc_BreakRotator_Yaw_1 = CallFunc_BreakRotator_Yaw_1;
	Parms.CallFunc_IsValid_ReturnValue_1 = CallFunc_IsValid_ReturnValue_1;
	Parms.CallFunc_MapRangeClamped_ReturnValue_2 = CallFunc_MapRangeClamped_ReturnValue_2;
	Parms.CallFunc_SignOfFloat_ReturnValue = CallFunc_SignOfFloat_ReturnValue;
	Parms.CallFunc_Divide_FloatFloat_ReturnValue = CallFunc_Divide_FloatFloat_ReturnValue;
	Parms.CallFunc_MapRangeClamped_ReturnValue_3 = CallFunc_MapRangeClamped_ReturnValue_3;
	Parms.CallFunc_GetControlRotation_ReturnValue = CallFunc_GetControlRotation_ReturnValue;
	Parms.CallFunc_Less_FloatFloat_ReturnValue_5 = CallFunc_Less_FloatFloat_ReturnValue_5;
	Parms.CallFunc_BooleanAND_ReturnValue_7 = CallFunc_BooleanAND_ReturnValue_7;
	Parms.CallFunc_SelectFloat_ReturnValue_7 = CallFunc_SelectFloat_ReturnValue_7;
	Parms.CallFunc_Multiply_FloatFloat_ReturnValue_1 = CallFunc_Multiply_FloatFloat_ReturnValue_1;
	Parms.CallFunc_FClamp_ReturnValue_1 = CallFunc_FClamp_ReturnValue_1;
	Parms.CallFunc_Greater_FloatFloat_ReturnValue_3 = CallFunc_Greater_FloatFloat_ReturnValue_3;
	Parms.CallFunc_SelectFloat_ReturnValue_8 = CallFunc_SelectFloat_ReturnValue_8;
	Parms.CallFunc_GetWorldDeltaSeconds_ReturnValue_1 = CallFunc_GetWorldDeltaSeconds_ReturnValue_1;
	Parms.CallFunc_FInterpTo_ReturnValue = CallFunc_FInterpTo_ReturnValue;
	Parms.CallFunc_Abs_ReturnValue = CallFunc_Abs_ReturnValue;
	Parms.CallFunc_FMax_ReturnValue_1 = CallFunc_FMax_ReturnValue_1;
	Parms.K2Node_Select_Default_1 = K2Node_Select_Default_1;
	Parms.CallFunc_FInterpTo_ReturnValue_1 = CallFunc_FInterpTo_ReturnValue_1;
	Parms.CallFunc_GetCurrentMovementState_ReturnValue_1 = CallFunc_GetCurrentMovementState_ReturnValue_1;
	Parms.CallFunc_EqualEqual_ClassClass_ReturnValue_1 = CallFunc_EqualEqual_ClassClass_ReturnValue_1;
	Parms.CallFunc_GetCGPlayerCharacter_CGPlayerCharacter = CallFunc_GetCGPlayerCharacter_CGPlayerCharacter;
	Parms.K2Node_DynamicCast_AsCGWeapon = K2Node_DynamicCast_AsCGWeapon;
	Parms.K2Node_DynamicCast_bSuccess_1 = K2Node_DynamicCast_bSuccess_1;

	UObject::ProcessEvent(Func, &Parms);

}

}


