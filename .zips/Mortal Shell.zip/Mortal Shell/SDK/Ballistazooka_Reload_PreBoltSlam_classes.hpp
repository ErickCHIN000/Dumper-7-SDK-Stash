#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x160 - 0x160)
// BlueprintGeneratedClass Ballistazooka_Reload_PreBoltSlam.Ballistazooka_Reload_PreBoltSlam_C
class UBallistazooka_Reload_PreBoltSlam_C : public UCameraShake
{
public:

	static class UClass* StaticClass();
	static class UBallistazooka_Reload_PreBoltSlam_C* GetDefaultObj();

};

}


