#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x160 - 0x160)
// BlueprintGeneratedClass BalistzookaEquip.BalistzookaEquip_C
class UBalistzookaEquip_C : public UCameraShake
{
public:

	static class UClass* StaticClass();
	static class UBalistzookaEquip_C* GetDefaultObj();

};

}


