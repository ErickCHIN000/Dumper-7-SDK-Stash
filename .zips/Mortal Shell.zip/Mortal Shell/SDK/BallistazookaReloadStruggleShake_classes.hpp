#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x160 - 0x160)
// BlueprintGeneratedClass BallistazookaReloadStruggleShake.BallistazookaReloadStruggleShake_C
class UBallistazookaReloadStruggleShake_C : public UCameraShake
{
public:

	static class UClass* StaticClass();
	static class UBallistazookaReloadStruggleShake_C* GetDefaultObj();

};

}


