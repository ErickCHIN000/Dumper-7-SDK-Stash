#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x230 - 0x230)
// BlueprintGeneratedClass BP_Core_Forcefield_Door.BP_Core_Forcefield_Door_C
class ABP_Core_Forcefield_Door_C : public AStaticMeshActor
{
public:

	static class UClass* StaticClass();
	static class ABP_Core_Forcefield_Door_C* GetDefaultObj();

};

}


