#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x160 - 0x160)
// BlueprintGeneratedClass AxatanaShake.AxatanaShake_C
class UAxatanaShake_C : public UCameraShake
{
public:

	static class UClass* StaticClass();
	static class UAxatanaShake_C* GetDefaultObj();

};

}


