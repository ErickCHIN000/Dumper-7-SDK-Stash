#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x160 - 0x160)
// BlueprintGeneratedClass BackwardsDashSHake.BackwardsDashSHake_C
class UBackwardsDashSHake_C : public UCameraShake
{
public:

	static class UClass* StaticClass();
	static class UBackwardsDashSHake_C* GetDefaultObj();

};

}


