#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x40 (0x40 - 0x0)
// UserDefinedStruct BottomRightNotificationStruct.BottomRightNotificationStruct
struct FBottomRightNotificationStruct
{
public:
	class FName                                  NotificationName_2_181C6FD948A8B66BFEDF9AA14811BCA4; // 0x0(0x8)(Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	class FText                                  NotificationText_5_8C2421D4419D5F9B5E15379F4CEF6C34; // 0x8(0x18)(Edit, BlueprintVisible)
	enum class EControllerButton                 NotificationButtonToDisplay_14_BE351C6B43503ED5201DF2979A37B924; // 0x20(0x1)(Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
	uint8                                        Pad_995[0x7];                                      // Fixing Size After Last Property  [ Dumper-7 ]
	class FText                                  KeyboardText_12_444C15B14D51F073B940A9A6CE6193AA;  // 0x28(0x18)(Edit, BlueprintVisible)
};

}


