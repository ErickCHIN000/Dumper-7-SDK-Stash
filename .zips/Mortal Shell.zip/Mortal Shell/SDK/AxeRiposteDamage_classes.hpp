#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x40 - 0x40)
// BlueprintGeneratedClass AxeRiposteDamage.AxeRiposteDamage_C
class UAxeRiposteDamage_C : public UDamageType
{
public:

	static class UClass* StaticClass();
	static class UAxeRiposteDamage_C* GetDefaultObj();

};

}


