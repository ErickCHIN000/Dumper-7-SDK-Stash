#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x160 - 0x160)
// BlueprintGeneratedClass BalistzookaFire.BalistzookaFire_C
class UBalistzookaFire_C : public UCameraShake
{
public:

	static class UClass* StaticClass();
	static class UBalistzookaFire_C* GetDefaultObj();

};

}


