#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x468 - 0x468)
// BlueprintGeneratedClass BP_GA_Baa.BP_GA_Baa_C
class UBP_GA_Baa_C : public UGGGoatAbility_Baa
{
public:

	static class UClass* StaticClass();
	static class UBP_GA_Baa_C* GetDefaultObj();

};

}


