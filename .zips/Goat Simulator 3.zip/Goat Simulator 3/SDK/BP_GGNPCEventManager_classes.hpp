#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xF8 - 0xF8)
// BlueprintGeneratedClass BP_GGNPCEventManager.BP_GGNPCEventManager_C
class UBP_GGNPCEventManager_C : public UGGNPCEventManager
{
public:

	static class UClass* StaticClass();
	static class UBP_GGNPCEventManager_C* GetDefaultObj();

};

}


