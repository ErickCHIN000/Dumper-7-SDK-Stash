#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x4D8 - 0x4D8)
// BlueprintGeneratedClass BP_GA_PigSlide.BP_GA_PigSlide_C
class UBP_GA_PigSlide_C : public UGGGearAbility_PigSlide
{
public:

	static class UClass* StaticClass();
	static class UBP_GA_PigSlide_C* GetDefaultObj();

};

}


