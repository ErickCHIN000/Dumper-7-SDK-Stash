#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x588 - 0x588)
// BlueprintGeneratedClass BP_GA_Steve_BackLunge.BP_GA_Steve_BackLunge_C
class UBP_GA_Steve_BackLunge_C : public UGGGoatAbility_BackLunge
{
public:

	static class UClass* StaticClass();
	static class UBP_GA_Steve_BackLunge_C* GetDefaultObj();

};

}


