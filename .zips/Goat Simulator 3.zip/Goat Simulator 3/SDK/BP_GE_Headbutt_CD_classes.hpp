#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x800 - 0x800)
// BlueprintGeneratedClass BP_GE_Headbutt_CD.BP_GE_Headbutt_CD_C
class UBP_GE_Headbutt_CD_C : public UGameplayEffect
{
public:

	static class UClass* StaticClass();
	static class UBP_GE_Headbutt_CD_C* GetDefaultObj();

};

}


