#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x12D1 - 0x12D1)
// BlueprintGeneratedClass BP_GGNPC_Civilian.BP_GGNPC_Civilian_C
class ABP_GGNPC_Civilian_C : public ABP_GGNPC_Humanoid_C
{
public:

	static class UClass* StaticClass();
	static class ABP_GGNPC_Civilian_C* GetDefaultObj();

};

}


