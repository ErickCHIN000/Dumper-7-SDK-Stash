#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x588 - 0x588)
// BlueprintGeneratedClass BP_GA_Steve_Lunge.BP_GA_Steve_Lunge_C
class UBP_GA_Steve_Lunge_C : public UGGGoatAbility_Lunge
{
public:

	static class UClass* StaticClass();
	static class UBP_GA_Steve_Lunge_C* GetDefaultObj();

};

}


