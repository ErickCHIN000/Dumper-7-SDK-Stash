#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x288 - 0x288)
// BlueprintGeneratedClass BP_GGPlayerCamera.BP_GGPlayerCamera_C
class ABP_GGPlayerCamera_C : public AGGPlayerCamera
{
public:

	static class UClass* StaticClass();
	static class ABP_GGPlayerCamera_C* GetDefaultObj();

};

}


