#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x5D8 - 0x5D8)
// BlueprintGeneratedClass BP_GA_ChargeHeadbutt.BP_GA_ChargeHeadbutt_C
class UBP_GA_ChargeHeadbutt_C : public UGGGoatAbility_ChargeHeadbutt
{
public:

	static class UClass* StaticClass();
	static class UBP_GA_ChargeHeadbutt_C* GetDefaultObj();

};

}


