#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xD0 - 0xD0)
// BlueprintGeneratedClass BP_GGMusicManager.BP_GGMusicManager_C
class UBP_GGMusicManager_C : public UGGMusicManager
{
public:

	static class UClass* StaticClass();
	static class UBP_GGMusicManager_C* GetDefaultObj();

};

}


