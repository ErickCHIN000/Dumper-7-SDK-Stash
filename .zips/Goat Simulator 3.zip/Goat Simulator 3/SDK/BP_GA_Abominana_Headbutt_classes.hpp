#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x558 - 0x558)
// BlueprintGeneratedClass BP_GA_Abominana_Headbutt.BP_GA_Abominana_Headbutt_C
class UBP_GA_Abominana_Headbutt_C : public UGGGoatAbility_Headbutt
{
public:

	static class UClass* StaticClass();
	static class UBP_GA_Abominana_Headbutt_C* GetDefaultObj();

};

}


