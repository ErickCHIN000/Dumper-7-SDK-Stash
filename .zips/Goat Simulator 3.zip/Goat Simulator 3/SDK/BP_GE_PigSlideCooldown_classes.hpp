#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x800 - 0x800)
// BlueprintGeneratedClass BP_GE_PigSlideCooldown.BP_GE_PigSlideCooldown_C
class UBP_GE_PigSlideCooldown_C : public UGameplayEffect
{
public:

	static class UClass* StaticClass();
	static class UBP_GE_PigSlideCooldown_C* GetDefaultObj();

};

}


