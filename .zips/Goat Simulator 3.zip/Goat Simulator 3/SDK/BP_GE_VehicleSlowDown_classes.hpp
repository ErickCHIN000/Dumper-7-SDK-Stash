#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x800 - 0x800)
// BlueprintGeneratedClass BP_GE_VehicleSlowDown.BP_GE_VehicleSlowDown_C
class UBP_GE_VehicleSlowDown_C : public UGameplayEffect
{
public:

	static class UClass* StaticClass();
	static class UBP_GE_VehicleSlowDown_C* GetDefaultObj();

};

}


