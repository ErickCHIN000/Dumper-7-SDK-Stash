#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x310 - 0x310)
// BlueprintGeneratedClass BP_GGNPCManager.BP_GGNPCManager_C
class UBP_GGNPCManager_C : public UGGNPCManager
{
public:

	static class UClass* StaticClass();
	static class UBP_GGNPCManager_C* GetDefaultObj();

};

}


