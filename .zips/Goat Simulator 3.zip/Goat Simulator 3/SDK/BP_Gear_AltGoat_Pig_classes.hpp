#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x340 - 0x338)
// BlueprintGeneratedClass BP_Gear_AltGoat_Pig.BP_Gear_AltGoat_Pig_C
class UBP_Gear_AltGoat_Pig_C : public UGGGoatGear_Scene_AltGoat
{
public:
	uint8                                        Pad_149[0x8];                                      // Fixing Size Of Struct [ Dumper-7 ]

	static class UClass* StaticClass();
	static class UBP_Gear_AltGoat_Pig_C* GetDefaultObj();

};

}


