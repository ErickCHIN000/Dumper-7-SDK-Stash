#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1B0 - 0x1B0)
// BlueprintGeneratedClass BouncyJump_CameraShake.BouncyJump_CameraShake_C
class UBouncyJump_CameraShake_C : public UMatineeCameraShake
{
public:

	static class UClass* StaticClass();
	static class UBouncyJump_CameraShake_C* GetDefaultObj();

};

}


