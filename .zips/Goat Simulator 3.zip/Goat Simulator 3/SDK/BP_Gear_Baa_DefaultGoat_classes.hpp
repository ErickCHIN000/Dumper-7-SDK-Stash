#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x330 - 0x330)
// BlueprintGeneratedClass BP_Gear_Baa_DefaultGoat.BP_Gear_Baa_DefaultGoat_C
class UBP_Gear_Baa_DefaultGoat_C : public UGGGoatGear_Scene_Baa
{
public:

	static class UClass* StaticClass();
	static class UBP_Gear_Baa_DefaultGoat_C* GetDefaultObj();

};

}


