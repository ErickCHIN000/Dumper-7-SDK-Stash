#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xD0 - 0xD0)
// BlueprintGeneratedClass BP_GGSEPoolManager.BP_GGSEPoolManager_C
class UBP_GGSEPoolManager_C : public UGGStatusEffectPoolManager
{
public:

	static class UClass* StaticClass();
	static class UBP_GGSEPoolManager_C* GetDefaultObj();

};

}


