#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x2D0 - 0x2D0)
// BlueprintGeneratedClass BP_GGSlipperyTrail.BP_GGSlipperyTrail_C
class ABP_GGSlipperyTrail_C : public AGGSlipperyTrail
{
public:

	static class UClass* StaticClass();
	static class ABP_GGSlipperyTrail_C* GetDefaultObj();

};

}


