#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x210 - 0x210)
// BlueprintGeneratedClass BP_FootstepComponent.BP_FootstepComponent_C
class UBP_FootstepComponent_C : public UGGFootstepComponent
{
public:

	static class UClass* StaticClass();
	static class UBP_FootstepComponent_C* GetDefaultObj();

	class USoundBase* GetSoundForSurface(enum class EPhysicalSurface SurfaceType, struct FSurfaceSounds& Sounds, enum class EPhysicalSurface Temp_byte_Variable, class USoundBase* Temp_object_Variable, class USoundBase* Temp_object_Variable_1, class USoundBase* K2Node_Select_Default);
};

}


