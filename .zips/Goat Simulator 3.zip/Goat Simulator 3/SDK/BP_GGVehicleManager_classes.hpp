#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x240 - 0x240)
// BlueprintGeneratedClass BP_GGVehicleManager.BP_GGVehicleManager_C
class UBP_GGVehicleManager_C : public UGGVehicleManager
{
public:

	static class UClass* StaticClass();
	static class UBP_GGVehicleManager_C* GetDefaultObj();

};

}


