#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x558 - 0x558)
// BlueprintGeneratedClass BP_GA_Pig_BackKick.BP_GA_Pig_BackKick_C
class UBP_GA_Pig_BackKick_C : public UGGGoatAbility_BackKick
{
public:

	static class UClass* StaticClass();
	static class UBP_GA_Pig_BackKick_C* GetDefaultObj();

};

}


