#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x490 - 0x490)
// BlueprintGeneratedClass BP_GA_Lick.BP_GA_Lick_C
class UBP_GA_Lick_C : public UGGGoatAbility_Lick
{
public:

	static class UClass* StaticClass();
	static class UBP_GA_Lick_C* GetDefaultObj();

};

}


