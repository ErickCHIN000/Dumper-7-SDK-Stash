#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x800 - 0x800)
// BlueprintGeneratedClass BP_GE_NPCVehSpeed.BP_GE_NPCVehSpeed_C
class UBP_GE_NPCVehSpeed_C : public UGameplayEffect
{
public:

	static class UClass* StaticClass();
	static class UBP_GE_NPCVehSpeed_C* GetDefaultObj();

};

}


