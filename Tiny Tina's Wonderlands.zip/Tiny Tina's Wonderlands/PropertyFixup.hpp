#pragma once

// Definitions for missing Properties

class UMulticastDelegateProperty_
{
	unsigned __int8 Pad[0x10];
};

class UDelegateProperty_
{
	unsigned __int8 Pad[0x10];
};

