#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x228 - 0x220)
// BlueprintGeneratedClass A_MushroomCompanion_Spawn.A_MushroomCompanion_Spawn_C
class UA_MushroomCompanion_Spawn_C : public UOakAction_Anim
{
public:
	class AActor*                                Actor;                                             // 0x220(0x8)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnTemplate, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class UA_MushroomCompanion_Spawn_C* GetDefaultObj();

};

}


