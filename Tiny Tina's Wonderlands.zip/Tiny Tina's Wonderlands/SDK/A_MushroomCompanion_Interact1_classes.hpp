#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x228 - 0x228)
// BlueprintGeneratedClass A_MushroomCompanion_Interact1.A_MushroomCompanion_Interact1_C
class UA_MushroomCompanion_Interact1_C : public UA_MushroomCompanion_Interact_Base_C
{
public:

	static class UClass* StaticClass();
	static class UA_MushroomCompanion_Interact1_C* GetDefaultObj();

};

}


