#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x4 (0x4 - 0x0)
// Function A_Hydra_Multi_Fidget_V2.A_Hydra_Multi_Fidget_V2_C.ExecuteUbergraph_A_Hydra_Multi_Fidget_V2
struct UA_Hydra_Multi_Fidget_V2_C_ExecuteUbergraph_A_Hydra_Multi_Fidget_V2_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


