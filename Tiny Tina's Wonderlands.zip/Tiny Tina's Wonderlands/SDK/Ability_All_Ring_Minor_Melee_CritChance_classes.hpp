#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x132 - 0x132)
// BlueprintGeneratedClass Ability_All_Ring_Minor_Melee_CritChance.Ability_All_Ring_Minor_Melee_CritChance_C
class UAbility_All_Ring_Minor_Melee_CritChance_C : public UBP_InventoryAbility_C
{
public:

	static class UClass* StaticClass();
	static class UAbility_All_Ring_Minor_Melee_CritChance_C* GetDefaultObj();

};

}


