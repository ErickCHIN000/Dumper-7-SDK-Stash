#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x228 - 0x228)
// BlueprintGeneratedClass A_Hydra_Slam_V2.A_Hydra_Slam_V2_C
class UA_Hydra_Slam_V2_C : public UA_Hydra_Slam_V1_C
{
public:

	static class UClass* StaticClass();
	static class UA_Hydra_Slam_V2_C* GetDefaultObj();

};

}


