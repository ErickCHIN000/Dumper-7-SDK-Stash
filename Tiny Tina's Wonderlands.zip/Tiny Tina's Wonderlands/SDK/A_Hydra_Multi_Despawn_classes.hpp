#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x228 - 0x228)
// BlueprintGeneratedClass A_Hydra_Multi_Despawn.A_Hydra_Multi_Despawn_C
class UA_Hydra_Multi_Despawn_C : public UA_Hydra_Despawn_C
{
public:

	static class UClass* StaticClass();
	static class UA_Hydra_Multi_Despawn_C* GetDefaultObj();

};

}


