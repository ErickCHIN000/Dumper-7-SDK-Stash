#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x229 - 0x229)
// BlueprintGeneratedClass A_Hydra_FireWeapon_V2.A_Hydra_FireWeapon_V2_C
class UA_Hydra_FireWeapon_V2_C : public UA_Hydra_FireWeapon_V1_C
{
public:

	static class UClass* StaticClass();
	static class UA_Hydra_FireWeapon_V2_C* GetDefaultObj();

};

}


