#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x2D8 - 0x2D8)
// BlueprintGeneratedClass A_Ranger_Cryonado_Start_02.A_Ranger_Cryonado_Start_02_C
class UA_Ranger_Cryonado_Start_02_C : public UA_Ranger_Cryonado_Start_C
{
public:

	static class UClass* StaticClass();
	static class UA_Ranger_Cryonado_Start_02_C* GetDefaultObj();

};

}


