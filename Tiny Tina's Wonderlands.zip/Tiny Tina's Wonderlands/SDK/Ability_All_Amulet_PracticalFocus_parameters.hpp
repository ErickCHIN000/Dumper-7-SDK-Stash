#pragma once

// Dumped with Dumper-7!


#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x4 (0x4 - 0x0)
// Function Ability_All_Amulet_PracticalFocus.Ability_All_Amulet_PracticalFocus_C.ExecuteUbergraph_Ability_All_Amulet_PracticalFocus
struct UAbility_All_Amulet_PracticalFocus_C_ExecuteUbergraph_Ability_All_Amulet_PracticalFocus_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}


