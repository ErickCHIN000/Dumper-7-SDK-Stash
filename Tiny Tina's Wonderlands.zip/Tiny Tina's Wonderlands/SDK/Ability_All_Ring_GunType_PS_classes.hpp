#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x132 - 0x132)
// BlueprintGeneratedClass Ability_All_Ring_GunType_PS.Ability_All_Ring_GunType_PS_C
class UAbility_All_Ring_GunType_PS_C : public UAbility_All_Ring_GunType_AR_C
{
public:

	static class UClass* StaticClass();
	static class UAbility_All_Ring_GunType_PS_C* GetDefaultObj();

};

}


