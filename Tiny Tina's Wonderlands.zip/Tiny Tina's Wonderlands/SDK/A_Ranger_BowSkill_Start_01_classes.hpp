#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x2C0 - 0x2C0)
// BlueprintGeneratedClass A_Ranger_BowSkill_Start_01.A_Ranger_BowSkill_Start_01_C
class UA_Ranger_BowSkill_Start_01_C : public UA_Ranger_BowSkill_Base_C
{
public:

	static class UClass* StaticClass();
	static class UA_Ranger_BowSkill_Start_01_C* GetDefaultObj();

};

}


