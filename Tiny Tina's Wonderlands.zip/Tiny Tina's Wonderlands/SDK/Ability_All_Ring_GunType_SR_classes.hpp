#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x132 - 0x132)
// BlueprintGeneratedClass Ability_All_Ring_GunType_SR.Ability_All_Ring_GunType_SR_C
class UAbility_All_Ring_GunType_SR_C : public UAbility_All_Ring_GunType_AR_C
{
public:

	static class UClass* StaticClass();
	static class UAbility_All_Ring_GunType_SR_C* GetDefaultObj();

};

}


