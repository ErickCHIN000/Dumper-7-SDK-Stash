#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1A0 - 0x1A0)
// BlueprintGeneratedClass Ability_All_Shared_SkillActive_LightningDamage.Ability_All_Shared_SkillActive_LightningDamage_C
class UAbility_All_Shared_SkillActive_LightningDamage_C : public UAbility_All_Shared_SkillActive_Base_C
{
public:

	static class UClass* StaticClass();
	static class UAbility_All_Shared_SkillActive_LightningDamage_C* GetDefaultObj();

};

}


