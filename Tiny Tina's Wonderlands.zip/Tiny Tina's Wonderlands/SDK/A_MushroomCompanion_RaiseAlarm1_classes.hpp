#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x220 - 0x220)
// BlueprintGeneratedClass A_MushroomCompanion_RaiseAlarm1.A_MushroomCompanion_RaiseAlarm1_C
class UA_MushroomCompanion_RaiseAlarm1_C : public UOakAction_Anim
{
public:

	static class UClass* StaticClass();
	static class UA_MushroomCompanion_RaiseAlarm1_C* GetDefaultObj();

};

}


