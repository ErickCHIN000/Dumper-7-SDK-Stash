#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x228 - 0x228)
// BlueprintGeneratedClass A_Hydra_Multi_Spawn.A_Hydra_Multi_Spawn_C
class UA_Hydra_Multi_Spawn_C : public UA_Hydra_Spawn_C
{
public:

	static class UClass* StaticClass();
	static class UA_Hydra_Multi_Spawn_C* GetDefaultObj();

};

}


