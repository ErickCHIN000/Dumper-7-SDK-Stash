#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x220 - 0x220)
// BlueprintGeneratedClass A_Hydra_Drone_Spawn.A_Hydra_Drone_Spawn_C
class UA_Hydra_Drone_Spawn_C : public UOakAction_Anim
{
public:

	static class UClass* StaticClass();
	static class UA_Hydra_Drone_Spawn_C* GetDefaultObj();

};

}


