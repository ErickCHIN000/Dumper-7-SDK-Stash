#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x228 - 0x228)
// BlueprintGeneratedClass A_Hydra_Multi_Fidget_V1.A_Hydra_Multi_Fidget_V1_C
class UA_Hydra_Multi_Fidget_V1_C : public UA_Hydra_Fidget_v1_C
{
public:

	static class UClass* StaticClass();
	static class UA_Hydra_Multi_Fidget_V1_C* GetDefaultObj();

};

}


