#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x220 - 0x220)
// BlueprintGeneratedClass A_MushroomCompanion_Injured.A_MushroomCompanion_Injured_C
class UA_MushroomCompanion_Injured_C : public UOakAction_Anim
{
public:

	static class UClass* StaticClass();
	static class UA_MushroomCompanion_Injured_C* GetDefaultObj();

};

}


