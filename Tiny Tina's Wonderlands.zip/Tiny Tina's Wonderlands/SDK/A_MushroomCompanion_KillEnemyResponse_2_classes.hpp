#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x220 - 0x220)
// BlueprintGeneratedClass A_MushroomCompanion_KillEnemyResponse_2.A_MushroomCompanion_KillEnemyResponse_2_C
class UA_MushroomCompanion_KillEnemyResponse_2_C : public UOakAction_Anim
{
public:

	static class UClass* StaticClass();
	static class UA_MushroomCompanion_KillEnemyResponse_2_C* GetDefaultObj();

};

}


