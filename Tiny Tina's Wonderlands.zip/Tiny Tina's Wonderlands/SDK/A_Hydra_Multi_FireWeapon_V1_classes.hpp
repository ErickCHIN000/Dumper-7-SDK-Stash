#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x7 (0x230 - 0x229)
// BlueprintGeneratedClass A_Hydra_Multi_FireWeapon_V1.A_Hydra_Multi_FireWeapon_V1_C
class UA_Hydra_Multi_FireWeapon_V1_C : public UA_Hydra_FireWeapon_V1_C
{
public:
	uint8                                        Pad_2B65[0x3];                                     // Fixing Size After Last Property  [ Dumper-7 ]
	int32                                        Count;                                             // 0x22C(0x4)(Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class UA_Hydra_Multi_FireWeapon_V1_C* GetDefaultObj();

};

}


