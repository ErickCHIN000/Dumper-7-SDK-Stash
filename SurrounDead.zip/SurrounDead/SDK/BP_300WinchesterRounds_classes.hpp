#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x5C8 - 0x5C8)
// BlueprintGeneratedClass BP_300WinchesterRounds.BP_300WinchesterRounds_C
class ABP_300WinchesterRounds_C : public ABP_StaticMeshClass_C
{
public:

	static class UClass* StaticClass();
	static class ABP_300WinchesterRounds_C* GetDefaultObj();

};

}


