#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x80 (0x80 - 0x0)
// UserDefinedStruct BodyPartSettings.BodyPartSettings
struct FBodyPartSettings
{
public:
	class USkeletalMesh*                         MaleTorsoMesh_37_C39419A54F846168C8ACC7B8047249B8; // 0x0(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         MaleArmsMesh_38_E3992D3D4D3FC15857DCCA96943DF404;  // 0x8(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         MaleBicepsMesh_58_A5C488CE417D90B275C89D85A579F848; // 0x10(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         MaleHandsMesh_39_62A6D44C46074AB07761FD8486836B1E; // 0x18(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         MaleLegsMesh_40_D743A1EA4C0458D9DB7686B580B34B55;  // 0x20(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         MaleLowerThighsMesh_60_1BB76DBD438060796E0670BACC379CFB; // 0x28(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         MaleLowerLegsMesh_41_C71508734756C346F2E4E5B00E2D7D7A; // 0x30(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         MaleFeetMesh_42_052101B64D2CB0C9572A4AAD3997D93B;  // 0x38(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         FemaleTorsoMesh_49_66B3BA484F8278F2133583B2677358EA; // 0x40(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         FemaleArmsMesh_50_5D08A0FA4B92C459DDDD8E8043029F2F; // 0x48(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         FemaleBicepsMesh_63_742947C24722CA2991518EA18DF1C2EC; // 0x50(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         FemaleHandsMesh_51_994CCC674C6D50AFD49448941EA98F9F; // 0x58(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         FemaleLegsMesh_52_7AE6631D44A06557F6DCB28A267ABCF0; // 0x60(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         FemaleLowerThighsMesh_64_6FC37310431BCF7E935A9A80E8A8CEFD; // 0x68(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         FemaleLowerLegsMesh_53_0981B7444A0C7933ABE436BAE54E9BC8; // 0x70(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
	class USkeletalMesh*                         FemaleFeetMesh_54_759E5B484609B6B259ECB5ACB9BFA58A; // 0x78(0x8)(Edit, BlueprintVisible, ZeroConstructor, NoDestructor, HasGetValueTypeHash)
};

}


