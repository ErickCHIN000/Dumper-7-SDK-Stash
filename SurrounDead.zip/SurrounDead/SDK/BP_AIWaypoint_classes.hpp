#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x8 (0x2A8 - 0x2A0)
// BlueprintGeneratedClass BP_AIWaypoint.BP_AIWaypoint_C
class ABP_AIWaypoint_C : public ABP_MasterObject_C
{
public:
	class UBillboardComponent*                   Billboard;                                         // 0x2A0(0x8)(BlueprintVisible, ZeroConstructor, InstancedReference, NonTransactional, NoDestructor, HasGetValueTypeHash)

	static class UClass* StaticClass();
	static class ABP_AIWaypoint_C* GetDefaultObj();

};

}


