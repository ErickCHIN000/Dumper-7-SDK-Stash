#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x5C8 - 0x5C8)
// BlueprintGeneratedClass BP_308Rounds.BP_308Rounds_C
class ABP_308Rounds_C : public ABP_StaticMeshClass_C
{
public:

	static class UClass* StaticClass();
	static class ABP_308Rounds_C* GetDefaultObj();

};

}


