#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x5C8 - 0x5C8)
// BlueprintGeneratedClass BP_Antiseptic.BP_Antiseptic_C
class ABP_Antiseptic_C : public ABP_ScrapMetal_C
{
public:

	static class UClass* StaticClass();
	static class ABP_Antiseptic_C* GetDefaultObj();

};

}


