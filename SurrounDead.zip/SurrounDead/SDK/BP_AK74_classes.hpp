#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x7D2 - 0x7D2)
// BlueprintGeneratedClass BP_AK74.BP_AK74_C
class ABP_AK74_C : public ABP_MainFirearmClass_C
{
public:

	static class UClass* StaticClass();
	static class ABP_AK74_C* GetDefaultObj();

};

}


