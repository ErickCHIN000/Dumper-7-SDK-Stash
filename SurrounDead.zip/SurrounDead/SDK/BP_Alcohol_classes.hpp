#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x5C8 - 0x5C8)
// BlueprintGeneratedClass BP_Alcohol.BP_Alcohol_C
class ABP_Alcohol_C : public ABP_ScrapMetal_C
{
public:

	static class UClass* StaticClass();
	static class ABP_Alcohol_C* GetDefaultObj();

};

}


