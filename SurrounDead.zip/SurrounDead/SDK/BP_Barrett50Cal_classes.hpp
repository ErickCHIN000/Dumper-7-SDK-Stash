#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x7D2 - 0x7D2)
// BlueprintGeneratedClass BP_Barrett50Cal.BP_Barrett50Cal_C
class ABP_Barrett50Cal_C : public ABP_MainFirearmClass_C
{
public:

	static class UClass* StaticClass();
	static class ABP_Barrett50Cal_C* GetDefaultObj();

};

}


