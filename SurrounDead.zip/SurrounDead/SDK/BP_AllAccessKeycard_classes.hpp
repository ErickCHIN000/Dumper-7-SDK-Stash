#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x5C8 - 0x5C8)
// BlueprintGeneratedClass BP_AllAccessKeycard.BP_AllAccessKeycard_C
class ABP_AllAccessKeycard_C : public ABP_StaticMeshClass_C
{
public:

	static class UClass* StaticClass();
	static class ABP_AllAccessKeycard_C* GetDefaultObj();

};

}


