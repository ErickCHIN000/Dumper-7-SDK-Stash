#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x5C8 - 0x5C8)
// BlueprintGeneratedClass BP_50CalRounds.BP_50CalRounds_C
class ABP_50CalRounds_C : public ABP_StaticMeshClass_C
{
public:

	static class UClass* StaticClass();
	static class ABP_50CalRounds_C* GetDefaultObj();

};

}


