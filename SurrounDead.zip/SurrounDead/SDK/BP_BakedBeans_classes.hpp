#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x5C8 - 0x5C8)
// BlueprintGeneratedClass BP_BakedBeans.BP_BakedBeans_C
class ABP_BakedBeans_C : public ABP_ConsumablesClass_C
{
public:

	static class UClass* StaticClass();
	static class ABP_BakedBeans_C* GetDefaultObj();

};

}


