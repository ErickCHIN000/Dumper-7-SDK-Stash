#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x86A - 0x86A)
// BlueprintGeneratedClass BP_AICivilian.BP_AICivilian_C
class ABP_AICivilian_C : public ABP_MasterAICharacter_C
{
public:

	static class UClass* StaticClass();
	static class ABP_AICivilian_C* GetDefaultObj();

};

}


