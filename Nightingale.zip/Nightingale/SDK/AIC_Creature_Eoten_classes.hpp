#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x658 - 0x658)
// BlueprintGeneratedClass AIC_Creature_Eoten.AIC_Creature_Eoten_C
class AAIC_Creature_Eoten_C : public AAIC_Creature_Wildlife_C
{
public:

	static class UClass* StaticClass();
	static class AAIC_Creature_Eoten_C* GetDefaultObj();

};

}


