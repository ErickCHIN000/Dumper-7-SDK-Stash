#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x50 - 0x50)
// BlueprintGeneratedClass AIAC_02Ambient.AIAC_02Ambient_C
class UAIAC_02Ambient_C : public UAIActionCategory
{
public:

	static class UClass* StaticClass();
	static class UAIAC_02Ambient_C* GetDefaultObj();

};

}


