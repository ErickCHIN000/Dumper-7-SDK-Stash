#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x50 - 0x50)
// BlueprintGeneratedClass AIAC_08Fear.AIAC_08Fear_C
class UAIAC_08Fear_C : public UAIActionCategory
{
public:

	static class UClass* StaticClass();
	static class UAIAC_08Fear_C* GetDefaultObj();

};

}


