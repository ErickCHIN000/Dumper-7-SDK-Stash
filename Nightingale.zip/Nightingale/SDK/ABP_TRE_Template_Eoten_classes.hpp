#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1B01 - 0x1B01)
// AnimBlueprintGeneratedClass ABP_TRE_Template_Eoten.ABP_TRE_Template_Eoten_C
class UABP_TRE_Template_Eoten_C : public UABP_TRE_Template_C
{
public:

	static class UClass* StaticClass();
	static class UABP_TRE_Template_Eoten_C* GetDefaultObj();

};

}


