#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x178 - 0x178)
// BlueprintGeneratedClass AIA_Creature_Eoten_Melee_Combat.AIA_Creature_Eoten_Melee_Combat_C
class UAIA_Creature_Eoten_Melee_Combat_C : public UAIA_Creature_Combat_Wildlife_Melee_C
{
public:

	static class UClass* StaticClass();
	static class UAIA_Creature_Eoten_Melee_Combat_C* GetDefaultObj();

};

}


