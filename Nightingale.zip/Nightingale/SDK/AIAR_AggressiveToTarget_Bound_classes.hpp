#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1A0 - 0x1A0)
// BlueprintGeneratedClass AIAR_AggressiveToTarget_Bound.AIAR_AggressiveToTarget_Bound_C
class UAIAR_AggressiveToTarget_Bound_C : public UAIAR_AggressiveToTarget
{
public:

	static class UClass* StaticClass();
	static class UAIAR_AggressiveToTarget_Bound_C* GetDefaultObj();

};

}


