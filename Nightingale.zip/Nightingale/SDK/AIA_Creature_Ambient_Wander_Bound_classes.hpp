#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xB8 - 0xB8)
// BlueprintGeneratedClass AIA_Creature_Ambient_Wander_Bound.AIA_Creature_Ambient_Wander_Bound_C
class UAIA_Creature_Ambient_Wander_Bound_C : public UAIA_Creature_Ambient_Wander_C
{
public:

	static class UClass* StaticClass();
	static class UAIA_Creature_Ambient_Wander_Bound_C* GetDefaultObj();

};

}


