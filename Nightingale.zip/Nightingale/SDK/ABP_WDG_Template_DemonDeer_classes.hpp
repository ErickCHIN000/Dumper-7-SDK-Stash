#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x176C - 0x176C)
// AnimBlueprintGeneratedClass ABP_WDG_Template_DemonDeer.ABP_WDG_Template_DemonDeer_C
class UABP_WDG_Template_DemonDeer_C : public UABP_WDG_Template_C
{
public:

	static class UClass* StaticClass();
	static class UABP_WDG_Template_DemonDeer_C* GetDefaultObj();

};

}


