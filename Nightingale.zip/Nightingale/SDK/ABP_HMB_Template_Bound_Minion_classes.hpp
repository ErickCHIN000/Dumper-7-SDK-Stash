#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x1E50 - 0x1E50)
// AnimBlueprintGeneratedClass ABP_HMB_Template_Bound_Minion.ABP_HMB_Template_Bound_Minion_C
class UABP_HMB_Template_Bound_Minion_C : public UABP_HMB_Template_C
{
public:

	static class UClass* StaticClass();
	static class UABP_HMB_Template_Bound_Minion_C* GetDefaultObj();

};

}


