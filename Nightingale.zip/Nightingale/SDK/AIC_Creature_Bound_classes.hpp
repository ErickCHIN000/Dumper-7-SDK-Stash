#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x650 - 0x650)
// BlueprintGeneratedClass AIC_Creature_Bound.AIC_Creature_Bound_C
class AAIC_Creature_Bound_C : public AAIC_CreatureBase_C
{
public:

	static class UClass* StaticClass();
	static class AAIC_Creature_Bound_C* GetDefaultObj();

};

}


