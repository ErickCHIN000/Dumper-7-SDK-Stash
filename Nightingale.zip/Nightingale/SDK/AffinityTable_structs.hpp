#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// ENUMS
//---------------------------------------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------------------------------------------
// STRUCTS
//---------------------------------------------------------------------------------------------------------------------

// 0x10 (0x10 - 0x0)
// ScriptStruct AffinityTable.CellDataArrayWrapper
struct FCellDataArrayWrapper
{
public:
	uint8                                        Pad_EFE[0x10];                                     // Fixing Size Of Struct [ Dumper-7 ]
};

// 0x8 (0x8 - 0x0)
// ScriptStruct AffinityTable.AffinityTableCellDataWrapper
struct FAffinityTableCellDataWrapper
{
public:
	uint8                                        Pad_F03[0x8];                                      // Fixing Size Of Struct [ Dumper-7 ]
};

}


