#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x16C - 0x16C)
// BlueprintGeneratedClass AIA_Creature_Combat_Wildlife.AIA_Creature_Combat_Wildlife_C
class UAIA_Creature_Combat_Wildlife_C : public UAIA_Creature_Combat_C
{
public:

	static class UClass* StaticClass();
	static class UAIA_Creature_Combat_Wildlife_C* GetDefaultObj();

};

}


