#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xE0 - 0xE0)
// BlueprintGeneratedClass AIA_Creature_NPCFreelance_GhostStructureConstruction_Composite.AIA_Creature_NPCFreelance_GhostStructureConstruction_Composite_C
class UAIA_Creature_NPCFreelance_GhostStructureConstruction_Composite_C : public UAIA_Creature_NPCFreelance_GhostStructureConstruction_C
{
public:

	static class UClass* StaticClass();
	static class UAIA_Creature_NPCFreelance_GhostStructureConstruction_Composite_C* GetDefaultObj();

};

}


