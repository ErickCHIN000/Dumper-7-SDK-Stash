#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x50 - 0x50)
// BlueprintGeneratedClass AIAC_09Charmed.AIAC_09Charmed_C
class UAIAC_09Charmed_C : public UAIActionCategory
{
public:

	static class UClass* StaticClass();
	static class UAIAC_09Charmed_C* GetDefaultObj();

};

}


