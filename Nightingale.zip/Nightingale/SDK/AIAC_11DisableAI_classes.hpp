#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x50 - 0x50)
// BlueprintGeneratedClass AIAC_11DisableAI.AIAC_11DisableAI_C
class UAIAC_11DisableAI_C : public UAIActionCategory
{
public:

	static class UClass* StaticClass();
	static class UAIAC_11DisableAI_C* GetDefaultObj();

};

}


