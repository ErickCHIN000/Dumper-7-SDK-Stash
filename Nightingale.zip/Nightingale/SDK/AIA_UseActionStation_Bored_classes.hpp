#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xE0 - 0xE0)
// BlueprintGeneratedClass AIA_UseActionStation_Bored.AIA_UseActionStation_Bored_C
class UAIA_UseActionStation_Bored_C : public UAIA_UseActionStation_C
{
public:

	static class UClass* StaticClass();
	static class UAIA_UseActionStation_Bored_C* GetDefaultObj();

	bool CheckOwnerRequirements(bool CallFunc_CheckOwnerRequirements_ReturnValue, class FName CallFunc_GetBBVar_ReturnValue, bool CallFunc_GetValueAsBool_ReturnValue);
};

}


