#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x50 - 0x50)
// BlueprintGeneratedClass AIAC_06CombatEnemy.AIAC_06CombatEnemy_C
class UAIAC_06CombatEnemy_C : public UAIActionCategory
{
public:

	static class UClass* StaticClass();
	static class UAIAC_06CombatEnemy_C* GetDefaultObj();

};

}


