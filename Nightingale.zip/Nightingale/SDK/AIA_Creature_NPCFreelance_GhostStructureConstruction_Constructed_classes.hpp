#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0xE0 - 0xE0)
// BlueprintGeneratedClass AIA_Creature_NPCFreelance_GhostStructureConstruction_Constructed.AIA_Creature_NPCFreelance_GhostStructureConstruction_Constructed_C
class UAIA_Creature_NPCFreelance_GhostStructureConstruction_Constructed_C : public UAIA_Creature_NPCFreelance_GhostStructureConstruction_C
{
public:

	static class UClass* StaticClass();
	static class UAIA_Creature_NPCFreelance_GhostStructureConstruction_Constructed_C* GetDefaultObj();

};

}


