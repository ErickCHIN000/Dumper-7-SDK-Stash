#pragma once

// Dumped with Dumper-7!


namespace SDK
{
//---------------------------------------------------------------------------------------------------------------------
// CLASSES
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x50 - 0x50)
// BlueprintGeneratedClass AIAC_07Squad.AIAC_07Squad_C
class UAIAC_07Squad_C : public UAIActionCategory
{
public:

	static class UClass* StaticClass();
	static class UAIAC_07Squad_C* GetDefaultObj();

};

}


